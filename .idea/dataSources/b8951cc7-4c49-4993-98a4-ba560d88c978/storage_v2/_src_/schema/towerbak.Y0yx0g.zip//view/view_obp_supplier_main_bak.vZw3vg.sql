create view view_obp_supplier_main_bak as
  select distinct concat('S', `a`.`org_code`)                             AS `user_id`,
                  `a`.`org_code`                                          AS `org_code`,
                  `a`.`org_name`                                          AS `org_name`,
                  `b`.`link_name`                                         AS `NAME`,
                  `a`.`contacter_Tel`                                     AS `contacter_Tel`,
                  `b`.`link_phone`                                        AS `phone`,
                  `a`.`remark`                                            AS `remark`,
                  `a`.`supplier_email`                                    AS `supplier_email`,
                  `a`.`address`                                           AS `address`,
                  `c`.`bank`                                              AS `bankName`,
                  `c`.`account_name`                                      AS `bankUser`,
                  `c`.`num`                                               AS `bankNo`,
                  ''                                                      AS `lead_time`,
                  `a`.`supplier_code`                                     AS `supplier_code`,
                  `a`.`pay_taxes_type`                                    AS `pay_taxes_type`,
                  `a`.`taxes_num`                                         AS `taxes_num`,
                  `a`.`status`                                            AS `STATUS`,
                  `a`.`province_code`                                     AS `province_code`,
                  `a`.`city_code`                                         AS `city_code`,
                  concat(
                    'http://www.tower.com.cn/default/supplier/obpSupplierBaseInfo/ObpSupplierBaseInfoDetails1.jsp?userid=',
                    `a`.`supplier_code`, '&orgcode=', `a`.`org_code`, '') AS `Provider_url`,
                  `a`.`LEVEL`                                             AS `level`,
                  ''                                                      AS `parent_supplier_code`
  from ((`tower`.`obp_supplier_base_info` `a`
      join `tower`.`obp_supplier_linkman_info` `b`) join `tower`.`obp_supplier_bank_info` `c`)
  where ((`b`.`supplier_id` = `a`.`id`) and (`c`.`supplier_id` = `a`.`id`) and
         (`b`.`supplier_id` = `c`.`supplier_id`) and (`b`.`status` = '1') and (`c`.`status` = '1') and
         (`a`.`status` = '1') and (`a`.`LEVEL` <> 2));

