create function f_settle_tcstatus_check(cd_status varchar(1), c_proc_inst_status varchar(1))
  returns varchar(1)
  BEGIN
DECLARE v_value VARCHAR(1);

IF (cd_status = '1' AND (c_proc_inst_status = '1' OR c_proc_inst_status='2')) THEN
	SET v_value = '1';
ELSEIF (cd_status = '2' AND (c_proc_inst_status = '1' OR c_proc_inst_status='2')) THEN
	SET v_value = '2';
ELSE
	SET v_value = '0';
END IF;

RETURN v_value;   
END;

