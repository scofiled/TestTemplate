create view view_org_area_201908 as
  select `view_org_area`.`c_orgcode`  AS `c_orgcode`,
         `view_org_area`.`p_orgcode`  AS `p_orgcode`,
         `view_org_area`.`p_orgname`  AS `p_orgname`,
         `view_org_area`.`c_orgname`  AS `c_orgname`,
         `view_org_area`.`p_area`     AS `p_area`,
         `view_org_area`.`p_areaName` AS `p_areaName`,
         `view_org_area`.`c_orgId`    AS `c_orgId`,
         `view_org_area`.`p_orgId`    AS `p_orgId`,
         `view_org_area`.`orgLevel`   AS `orgLevel`
  from `tower`.`view_org_area`;

