create function f_getsupplier_cerinfo_all(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                          v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  set cer_info_html='';

  IF(v_product_big_type='10' or v_product_big_type='11')then 
  
	  set	 cer_info_html=CONCAT(f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_tower_10_11
                              (v_supplier_id ,v_product_big_type,v_base_info_code),
														IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
  ELSEIF (v_product_big_type='20')THEN
		  set	 cer_info_html=CONCAT(
															f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_20
                              (v_supplier_id ,v_product_big_type,v_base_info_code),
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
  
 ELSEIF (v_product_big_type='30' or v_product_big_type='31' or v_product_big_type='32' 
             or v_product_big_type='33'  or v_product_big_type='34' 
              or   v_product_big_type='55')
	THEN
	 set	 cer_info_html=CONCAT(
															f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_battery_30_31_32_33_34_55
                              (v_supplier_id ,v_product_big_type,v_base_info_code),
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
 ELSEIF (v_product_big_type='35' or v_product_big_type='37' 
         or v_product_big_type='36' or v_product_big_type='51' )
	THEN
	 set	 cer_info_html=CONCAT(
															f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
															f_getsupplier_cerinfo_oilengine_35_36_37_51
                              (v_supplier_id ,v_product_big_type,v_base_info_code),
																IFNULL(f_getsupplier_cerinfo_oil_test 
																(v_supplier_id ,v_product_big_type,v_base_info_code),''),
													IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
													
						
		);
	 ELSEIF (v_product_big_type='46' or v_product_big_type='49'  or v_product_big_type='47' or v_product_big_type='48'
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_46_49
																(v_supplier_id ,v_product_big_type,v_base_info_code),
																	f_getsupplier_cerinfo_das_zizhi 
																(v_supplier_id ,v_product_big_type,v_base_info_code),
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
 ELSEIF (v_product_big_type='38' 
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_38_53
																(v_supplier_id ,v_product_big_type,v_base_info_code),
																	
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);

ELSEIF ( v_product_big_type='53' 
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_38_53
																(v_supplier_id ,v_product_big_type,v_base_info_code),
																	
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);


ELSEIF ( v_product_big_type='98' 
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																
																f_getsupplier_cerinfo_98
																(v_supplier_id ,v_product_big_type,v_base_info_code),
																	
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);

ELSEIF ( v_product_big_type='40' or v_product_big_type='41'  or v_product_big_type='42' or v_product_big_type='43' or v_product_big_type='44' or v_product_big_type='45' 
or v_product_big_type='39' 			or v_product_big_type='52'
  or v_product_big_type='60'
or v_product_big_type='50'
 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),
																f_getsupplier_cerinfo_other
																(v_supplier_id ,v_product_big_type,v_base_info_code),
															IFNULL(f_getsupplier_cerinfo_oil_test 
																(v_supplier_id ,v_product_big_type,v_base_info_code),''),
															IFNULL(f_getsupplier_cerinfo_ser (v_supplier_id ,v_product_big_type,v_base_info_code),''),
															
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
ELSEIF ( v_product_big_type='97'  
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																
																f_getsupplier_cerinfo_98
																(v_supplier_id ,v_product_big_type,v_base_info_code),
																	
														
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
ELSEIF ( v_product_big_type='64'  or  v_product_big_type='54' 
			 )
		THEN
		 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																
													
																	
														
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
  ELSE
  
 set	 cer_info_html=CONCAT(
																	f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),
																
												
																	
														
															f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code)
						
		);
  END if;

  RETURN cer_info_html;
END;

