create view view_report_settle_supplier_checkall as
  select `c`.`prdcodes`       AS `prdcodes`,
         `c`.`prdnames`       AS `prdnames`,
         `c`.`SupplyCode`     AS `SupplyCode`,
         `c`.`SupplyName`     AS `SupplyName`,
         sum(`d`.`PayAmount`) AS `amount`
  from (`tower`.`obp_settle_check` `c`
      join `tower`.`obp_settle_check_detail` `d`)
  where ((`c`.`prdcodes` <> '1') and (`c`.`prdcodes` <> '2') and (`c`.`CheckCode` = `d`.`CheckCode`))
  group by `c`.`prdcodes`, `c`.`SupplyCode`;

