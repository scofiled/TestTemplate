create view v_role as
  select `r`.`ROLE_CODE` AS `ROLE_ID`, `r`.`ROLE_NAME` AS `ROLE_NAME`, `r`.`ROLE_LEVEL` AS `ROLE_LEVEL`
  from `tower`.`cap_role` `r`
  where (`r`.`ROLE_CODE` <> 'sysadmin');

