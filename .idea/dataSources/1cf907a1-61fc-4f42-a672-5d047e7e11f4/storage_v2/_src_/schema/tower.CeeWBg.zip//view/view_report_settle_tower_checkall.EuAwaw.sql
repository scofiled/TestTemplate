create view view_report_settle_tower_checkall as
  select `c`.`prdcodes`                      AS `prdcodes`,
         `c`.`prdnames`                      AS `prdnames`,
         (case `t`.`isTaxPay`
            when '1' then `t`.`ticketCode`
            when '0' then `t`.`mergOrg` end) AS `orgcodes`,
         sum(`d`.`PayAmount`)                AS `amount`
  from ((`tower`.`obp_settle_check` `c`
      join `tower`.`obp_settle_check_detail` `d`) join `tower`.`obp_settle_ticket_information` `t`)
  where ((`c`.`prdcodes` <> '1') and (`c`.`prdcodes` <> '2') and (`c`.`CheckCode` = `d`.`CheckCode`) and
         (`c`.`OrgCode` = `t`.`ticketCode`) and (`t`.`goods_type` = '2'))
  group by `c`.`prdcodes`, (case `t`.`isTaxPay`
                              when '1' then `t`.`ticketCode`
                              when '0' then `t`.`mergOrg` end);

