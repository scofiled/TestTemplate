create view obp_supplier_product_base_info_temp as select `zhg`.`supplier_id`           AS `supplier_id`,
                                                          `zhg`.`org_name`              AS `org_name`,
                                                          `zhg`.`product_big_type_code` AS `prd_big_type_code`,
                                                          `zhg`.`supply_province_id`    AS `supply_province_id`
                                                   from `tower`.`obp_supplier_product_base_info` `zhg`
                                                   where (`zhg`.`status` = 3)
                                                   union all select `tw`.`supplier_id`           AS `supplier_id`,
                                                                    `tw`.`org_name`              AS `org_name`,
                                                                    `tw`.`product_big_type_code` AS `prd_big_type_code`,
                                                                    `tw`.`supply_province_id`    AS `supply_province_id`
                                                             from `tower`.`obp_tower_product_base_info` `tw`
                                                             where (`tw`.`status` = 3);

