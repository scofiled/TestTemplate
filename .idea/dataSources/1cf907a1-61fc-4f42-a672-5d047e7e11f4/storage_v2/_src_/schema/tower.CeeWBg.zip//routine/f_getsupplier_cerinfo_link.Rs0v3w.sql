create function f_getsupplier_cerinfo_link(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                           v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  
  set cer_info_temp='';
	set cer_info_html='';


 SELECT CONCAT('<p>','联系人信息:','</p>','<br>'
                ,'姓名: ',a.link_name,'<br>'
								,'手机: ',a.link_phone,'<br>'
								,'邮箱: ',a.link_email,'<br>'
                ) 
  into cer_info_temp

 from obp_supplier_linkman_info a 
  
  where a.supplier_id=v_supplier_id and a.status='1'  LIMIT 1 ;

   set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';

  RETURN cer_info_html;
END;

