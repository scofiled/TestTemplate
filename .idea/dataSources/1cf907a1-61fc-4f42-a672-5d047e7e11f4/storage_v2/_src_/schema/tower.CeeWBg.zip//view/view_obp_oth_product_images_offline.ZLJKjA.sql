create view view_obp_oth_product_images_offline as
  select `p`.`material_code`                                                               AS `material_code`,
         concat(replace(`f`.`file_abs_route`, '/mnt/nfs/', 'http://192.168.2.247:10000/')) AS `path`,
         ''                                                                                AS `sort`,
         ''                                                                                AS `isPrimary`
  from (((`tower`.`obp_prd_min_info` `p`
      join `tower`.`obp_file` `f`) join `tower`.`obp_file_rel` `r`) join `tower`.`obp_prd_base_info` `q`)
  where ((`p`.`id` = `r`.`rel_id`) and (`r`.`id` = `f`.`id`) and
         (`p`.`product_base_info_code` = `q`.`product_base_info_code`) and (`p`.`status` = '1') and
         (`q`.`base_info_status` = '3') and exists(select 1
                                                   from `tower`.`obp_supplier_access_agreement` `ac`
                                                   where ((`p`.`supplier_id` = `ac`.`supplier_id`) and
                                                          (`p`.`product_big_type` = `ac`.`prod_bctg`) and
                                                          (`ac`.`state` = '1'))));

