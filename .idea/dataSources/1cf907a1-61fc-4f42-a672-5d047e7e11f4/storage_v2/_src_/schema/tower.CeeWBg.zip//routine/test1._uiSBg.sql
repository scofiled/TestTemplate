create procedure test1()
  BEGIN
	declare total int(32) default 0;
	declare number int(32) default 0;
	declare size int(32) default 10000;
	declare start int(32) default 0;
	declare pageIndex int(32) default 0;
	declare _id varchar(32);
	declare msg text;
	select count(*) into total from wfworkitem;
	select total;
	set number = total/size;
	if total%size!=0 then 
	set number = number+1;
	select number;
	end if;
	while start<number do
	begin
	declare flag INT DEFAULT 0;
	declare _processInstID varchar(32);
	declare _processInstName varchar(32);
	declare youbiao1 cursor for select processInstID,processInstName from wfworkitem limit pageIndex,size; 
	 declare continue handler for not found set flag = 1; 
	 declare continue handler for SQLEXCEPTION 
	 begin get diagnostics condition 1  msg = message_text; 
	 select msg;
	 end ;
	 open youbiao1;
	 ci: loop
	 fetch youbiao1 into _processInstID ,_processInstName;
	 if flag = 1 then 
	 leave ci;
	 end if;
	 set _id = REPLACE(uuid(),'-','');
	 start  transaction;
	 insert into b (id,process_inst_id,process_inst_name) values(_id,_processInstID,_processInstName);
	 set _id = _id +1;
	 commit;
	 end loop;
	 close youbiao1;
	 end;
	 set start = start+1;
	 set pageIndex =pageIndex+10000;
	end while;
		 	select start;
	select number;
	select pageIndex;
END;

