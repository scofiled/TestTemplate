create view view_settle_check_progress as
  select `d`.`OrderCode`     AS `orderCode`,
         `d`.`materialcode`  AS `materialCode`,
         `d`.`MaterialName`  AS `materialName`,
         `r`.`orderNo`       AS `batchNo`,
         `d`.`batch_line_id` AS `batchLineId`,
         `d`.`SettleStatus`  AS `settleStatus`,
         `t`.`checkStatus`   AS `checkStatus`,
         `t`.`checkRmStatus` AS `rmCheckStatus`
  from ((`tower`.`obp_settle_check_detail` `d`
      join `tower`.`obp_settle_check_trancation` `t`) join `tower`.`obp_settle_receiving` `r`)
  where ((`d`.`CheckCode` = `t`.`CheckCode`) and (`d`.`Receivingid` = `t`.`ReceivingId`) and
         (`d`.`ProjectStatus` = `t`.`ProjectState`) and (`d`.`SettleStatus` = `t`.`ContractState`) and
         ((`t`.`checkStatus` = '0') or ((`t`.`checkStatus` = '1') and (`t`.`checkRmStatus` = '0')) or
          ((`t`.`checkStatus` = '1') and (`t`.`checkRmStatus` = '1'))) and (`d`.`Receivingid` = `r`.`id`));

