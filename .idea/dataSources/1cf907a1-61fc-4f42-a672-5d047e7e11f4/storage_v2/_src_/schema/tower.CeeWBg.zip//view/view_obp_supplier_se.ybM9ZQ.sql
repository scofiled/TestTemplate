create view view_obp_supplier_se as
  select `e`.`USER_ID`                                                AS `user_id`,
         `a`.`org_code`                                               AS `org_code`,
         `a`.`org_name`                                               AS `org_name`,
         `b`.`link_name`                                              AS `NAME`,
         `a`.`contacter_Tel`                                          AS `contacter_Tel`,
         `b`.`link_phone`                                             AS `phone`,
         `a`.`remark`                                                 AS `remark`,
         `a`.`supplier_email`                                         AS `supplier_email`,
         `a`.`address`                                                AS `address`,
         `c`.`bank`                                                   AS `bankName`,
         `c`.`account_name`                                           AS `bankUser`,
         `c`.`num`                                                    AS `bankNo`,
         ''                                                           AS `lead_time`,
         `a`.`supplier_code`                                          AS `supplier_code`,
         `a`.`pay_taxes_type`                                         AS `pay_taxes_type`,
         `a`.`taxes_num`                                              AS `taxes_num`,
         `a`.`status`                                                 AS `STATUS`,
         `a`.`province_code`                                          AS `province_code`,
         `a`.`city_code`                                              AS `city_code`,
         concat('http://www.tower.com.cn/default/supplier/obpSupplierBaseInfo/ObpSupplierBaseInfoDetails1.jsp?userid=',
                `a`.`supplier_code`, '&orgcode=', `a`.`org_code`, '') AS `Provider_url`,
         `a`.`LEVEL`                                                  AS `level`,
         ''                                                           AS `parent_supplier_code`
  from ((((`tower`.`obp_supplier_base_info` `a`
      join `tower`.`obp_cap_user_extend` `d`) join `tower`.`cap_user` `e`) left join `tower`.`obp_supplier_linkman_info` `b` on ((
    (`b`.`supplier_id` = `a`.`id`) and (`b`.`status` = '1')))) left join `tower`.`obp_supplier_bank_info` `c` on ((
    (`c`.`supplier_id` = `a`.`id`) and (`b`.`supplier_id` = `c`.`supplier_id`) and (`c`.`status` = '1'))))
  where ((`a`.`status` in ('1', '2')) and (`a`.`id` = `d`.`supplier_id`) and (`d`.`operator_id` = `e`.`OPERATOR_ID`) and
         (`a`.`LEVEL` <> '2'));

