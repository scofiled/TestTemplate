create view view_obp_product_67_offline_new_1 as
  select `g`.`name`                                                                                                AS `NAME`,
         ''                                                                                                        AS `goods_no`,
         `b`.`supplier_code`                                                                                       AS `supplier_code`,
         `e`.`product_price`                                                                                       AS `sell_price`,
         `e`.`includ_tax_price`                                                                                    AS `market_price`,
         concat(ifnull((select `b`.`content`
                        from `tower`.`obp_comp_desc` `b`
                        where (`a`.`product_specification_id` = `b`.`comp_id`)), ''),
                `a`.`product_describe`)                                                                            AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `a`.`metering_unit`)))                                                           AS `unit_name`,
         `c`.`generic_brand`                                                                                       AS `brand_name`,
         ''                                                                                                        AS `spec_array`,
         ''                                                                                                        AS `catagory_id`,
         ''                                                                                                        AS `latest`,
         ''                                                                                                        AS `bargainPrice`,
         ''                                                                                                        AS `recommend`,
         ''                                                                                                        AS `hot`,
         `a`.`material_code`                                                                                       AS `material_code`,
         `a`.`supplier_product_code`                                                                               AS `supplier_product_code`,
         (select `q`.`rule_value`
          from `tower`.`view_obp_supplier_ghzq_value` `q`
          where ((`q`.`com_id` = `c`.`product_base_info_code`) and
                 (`q`.`supplier_id` = `c`.`supplier_id`)))                                                         AS `stock_cycle`,
         '1'                                                                                                       AS `minbuy_num`,
         '1'                                                                                                       AS `pack_num`,
         ''                                                                                                        AS `prd_model`,
         ''                                                                                                        AS `goodsType`,
         ''                                                                                                        AS `mainSku`,
         ''                                                                                                        AS `versionName`,
         if(((`a`.`product_weight` = 0) or isnull(`a`.`product_weight`)), 0,
            (`a`.`product_weight` / 1000))                                                                         AS `weight`,
         (select `d`.`code`
          from `tower`.`obp_prd_min_type` `d`
          where (`d`.`id` = `a`.`product_specification_id`))                                                       AS `prd_param`,
         ''                                                                                                        AS `wareQD`,
         ''                                                                                                        AS `company_price`,
         ''                                                                                                        AS `tax_price`,
         (select `t`.`col2`
          from `tower`.`obp_tax` `t`
          where (`t`.`tax_rate` = cast(`c`.`added_value_tax_rate` as signed)))                                     AS `tax_rate`,
         `c`.`max_supply_capacity`                                                                                 AS `max_supply_capacity`,
         ''                                                                                                        AS `alert_supply_capacity`,
         ''                                                                                                        AS `extreme_supply_capacity`,
         ''                                                                                                        AS `install_rate`,
         '0'                                                                                                       AS `use_install_rate`,
         '3'                                                                                                       AS `use_freight_rate`,
         ''                                                                                                        AS `freight_price`,
         '0'                                                                                                       AS `Price_star`,
         '0'                                                                                                       AS `Price_mark`,
         '-1'                                                                                                      AS `Service_star`,
         '-1'                                                                                                      AS `Service_mark`,
         '-1'                                                                                                      AS `Quality_star`,
         '-1'                                                                                                      AS `Quality_mark`,
         `d`.`application_no`                                                                                      AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type` `l`
          where (`l`.`id` = `c`.`product_big_type_code`))                                                          AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type` `l`
              join `tower`.`obp_prd_min_type` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `a`.`product_specification_id`)))                                                     AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type` `m`
          where (`m`.`id` = `a`.`product_specification_id`))                                                       AS `Small_code`,
         round(ifnull((select `q`.`fee`
                       from (`tower`.`obp_oth_install_price` `q`
                           join `tower`.`obp_oth_install_prd_rel` `p`)
                       where ((`e`.`supplier_id` = `q`.`supplier_id`) and (`e`.`prodbcatg_id` = `q`.`prodbcatg_id`) and
                              (`e`.`quote_id` = `q`.`quote_id`) and (`q`.`feeitem_code` = `p`.`feeitem_code`) and
                              ((`e`.`product_id` = `p`.`prd_id`) or (`e`.`prodbcatg_id` = `p`.`prd_id`)) and
                              (`p`.`type` = 'D'))), 0),
               2)                                                                                                  AS `debug_service_fee`,
         round(ifnull((select `q`.`fee`
                       from (`tower`.`obp_oth_install_price` `q`
                           join `tower`.`obp_oth_install_prd_rel` `p`)
                       where ((`e`.`supplier_id` = `q`.`supplier_id`) and (`e`.`prodbcatg_id` = `q`.`prodbcatg_id`) and
                              (`e`.`quote_id` = `q`.`quote_id`) and (`q`.`feeitem_code` = `p`.`feeitem_code`) and
                              ((`e`.`product_id` = `p`.`prd_id`) or (`e`.`prodbcatg_id` = `p`.`prd_id`)) and
                              (`p`.`type` = 'G'))), 0),
               2)                                                                                                  AS `guide_service_fee`,
         `g`.`is_comp`                                                                                             AS `comp_flag`
  from (((((`tower`.`obp_prd_min_info` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_prd_base_info` `c`) join `tower`.`obp_supplier_access_agreement` `d`) join `tower`.`obp_oth_supplier_quote` `e`) join `tower`.`obp_prd_min_type` `g`)
  where ((`a`.`supplier_id` = `b`.`id`) and (`c`.`supplier_id` = `a`.`supplier_id`) and
         (`c`.`product_big_type_code` = `a`.`product_big_type`) and
         (`c`.`product_base_info_code` = `a`.`product_base_info_code`) and (`a`.`supplier_id` = `d`.`supplier_id`) and
         (`a`.`product_big_type` = `d`.`prod_bctg`) and (`a`.`supplier_id` = `e`.`supplier_id`) and
         (`a`.`product_big_type` = `e`.`prodbcatg_id`) and (`a`.`product_specification_id` = `e`.`product_id`) and
         (`c`.`base_info_status` = '3') and (`a`.`product_big_type` = '67') and (`a`.`status` = '1') and
         (`d`.`state` = '1') and (`e`.`status` = '1') and (`a`.`product_specification_id` = `g`.`id`));

