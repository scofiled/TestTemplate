create procedure GenTowerCabinetEvalScore(IN cabinet_quaratio decimal(5, 2), IN cabinet_srvratio decimal(5, 2),
                                          IN tower_srvratio   decimal(5, 2))
  BEGIN
	
DECLARE var1 varchar(20);
declare var2 varchar(200);
declare var3 varchar(500);
declare var4 decimal(8,2);
declare initsratio decimal(8,2) DEFAULT 0.75;
declare cabinet_quarule integer default 115;
declare cabinet_srvrule integer default 208;
declare tower10_srvrule integer default 1000;
declare tower11_srvrule integer default 10000;

DECLARE c_cabinet_quaeva CURSOR for select supplier_code, protype_code, evaluation_type, 
round(AVG(evaluation_score)*cabinet_quaratio,2) quaevalscore from towereshop.view_obp_deliveryscore_cabinet 
where evaluation_type = '001' group by supplier_code,protype_code,evaluation_type;

DECLARE c_cabinet_srveva CURSOR for select supplier_code, protype_code, evaluation_type, 
round(AVG(evaluation_score)*cabinet_srvratio,2) srvevalscore from towereshop.view_obp_deliveryscore_cabinet 
where evaluation_type = '002' group by supplier_code,protype_code,evaluation_type;

DECLARE c_tower10_srveva CURSOR for select supplier_code, protype_code, evaluation_type, 
round(AVG(evaluation_score)*tower_srvratio,2) srvevalscore from towereshop.view_obp_deliveryscore_tower 
where prod_bcatg='10' group by supplier_code,protype_code;

DECLARE c_tower11_srveva CURSOR for select supplier_code, protype_code, evaluation_type, 
round(AVG(evaluation_score)*tower_srvratio,2) srvevalscore from towereshop.view_obp_deliveryscore_tower 
where prod_bcatg='11' group by supplier_code,protype_code;


OPEN c_cabinet_quaeva;
LOOP
   FETCH c_cabinet_quaeva INTO var1, var2, var3, var4;
		 select @tmpvaluescore:= value_score from  obp_cer_rule_value where rule_id = cabinet_quarule;
     select @supplier_id:= id from obp_supplier_base_info where supplier_code = var1;
     select @realscore:= qua_score from obp_cer_score_inst where supplier_id = @supplier_id
          and prod_bcatg = var2;
	   update obp_cer_score_inst_info set score = var4 where supplier_id = @supplier_id
          and prod_bcatg = var2 and rule_id = 115;
     update obp_cer_score_inst set qua_score = @realscore-@tmpvaluescore + var4 where supplier_id = @supplier_id
          and prod_bcatg = var2;
END LOOP;
CLOSE c_cabinet_quaeva; 

OPEN c_cabinet_srveva;
LOOP
   FETCH c_cabinet_srveva INTO var1, var2, var3, var4;
		 select @tmpvaluescore:= value_score from  obp_cer_rule_value where rule_id = cabinet_quarule;
     select @supplier_id:= id from obp_supplier_base_info where supplier_code = var1;
     select @realscore:= qua_score from obp_cer_score_inst where supplier_id = @supplier_id
          and prod_bcatg = var2;
	   update obp_cer_score_inst_info set score = var4 where supplier_id = @supplier_id
          and prod_bcatg = var2 and rule_id = 208;
     update obp_cer_score_inst set service_score = @realscore-@tmpvaluescore + var4 where supplier_id = @supplier_id
          and prod_bcatg = var2;
END LOOP;
CLOSE c_cabinet_srveva; 

OPEN c_tower10_srveva;
LOOP
   FETCH c_tower10_srveva INTO var1, var2, var3, var4;
		 select @tmpvaluescore:= value_score from  obp_cer_rule_value where rule_id = cabinet_quarule;
     select @supplier_id:= id from obp_supplier_base_info where supplier_code = var1;
     select @realscore:= qua_score from obp_cer_score_inst where supplier_id = @supplier_id
          and prod_bcatg = var2;
	   update obp_cer_score_inst_info set score = var4 where supplier_id = @supplier_id
          and prod_bcatg = var2 and rule_id = 1000;
     update obp_cer_score_inst set service_score = @realscore-@tmpvaluescore + var4 where supplier_id = @supplier_id
          and prod_bcatg = var2;
END LOOP;
CLOSE c_tower10_srveva; 

OPEN c_tower11_srveva;
LOOP
   FETCH c_tower11_srveva INTO var1, var2, var3, var4;
		 select @tmpvaluescore:= value_score from  obp_cer_rule_value where rule_id = cabinet_quarule;
     select @supplier_id:= id from obp_supplier_base_info where supplier_code = var1;
     select @realscore:= qua_score from obp_cer_score_inst where supplier_id = @supplier_id
          and prod_bcatg = var2;
	   update obp_cer_score_inst_info set score = var4 where supplier_id = @supplier_id
          and prod_bcatg = var2 and rule_id = 10000;
     update obp_cer_score_inst set service_score = @realscore-@tmpvaluescore + var4 where supplier_id = @supplier_id
          and prod_bcatg = var2;
END LOOP;
CLOSE c_tower11_srveva; 


update obp_cer_score_inst set qua_star = '5' where qua_score <= 100 and qua_score >= 95;
update obp_cer_score_inst set qua_star = '4' where qua_score < 95 and qua_score >= 85;
update obp_cer_score_inst set qua_star = '3' where qua_score < 85 and qua_score >= 75;
update obp_cer_score_inst set qua_star = '2' where qua_score < 75 and qua_score >= 65;
update obp_cer_score_inst set qua_star = '1' where qua_score < 65 and qua_score >= 60;
update obp_cer_score_inst set qua_star = '0' where qua_star is null;

update obp_cer_score_inst set service_star = '5' where service_score <= 100 and service_score >= 95;
update obp_cer_score_inst set service_star = '4' where service_score < 95 and service_score >= 85;
update obp_cer_score_inst set service_star = '3' where service_score < 85 and service_score >= 75;
update obp_cer_score_inst set service_star = '2' where service_score < 75 and service_score >= 65;
update obp_cer_score_inst set service_star = '1' where service_score < 65 and service_score >= 60;
update obp_cer_score_inst set service_star = '0' where service_star is null;
END;

