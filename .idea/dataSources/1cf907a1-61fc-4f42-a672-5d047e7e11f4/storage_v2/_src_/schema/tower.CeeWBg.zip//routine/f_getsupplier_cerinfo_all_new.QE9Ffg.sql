create function f_getsupplier_cerinfo_all_new(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                              v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN
  DECLARE cer_info_html VARCHAR (10240);

  set cer_info_html='';
  
  set  cer_info_html=CONCAT(IFNULL(f_getsupplier_cerinfo_base(v_supplier_id ,v_product_big_type,v_base_info_code),''),
                            IFNULL(f_getsupplier_cerinfo_iso(v_supplier_id ,v_product_big_type,v_base_info_code),''),
                            IFNULL(f_getsupplier_cerinfo_new(v_supplier_id ,v_product_big_type,v_base_info_code),''),
                            IFNULL(f_getsupplier_cerinfo_ser_new (v_supplier_id ,v_product_big_type,v_base_info_code),''),
                            IFNULL(f_getsupplier_cerinfo_link  (v_supplier_id ,v_product_big_type,v_base_info_code),'')
            
    );

  RETURN cer_info_html;
END;

