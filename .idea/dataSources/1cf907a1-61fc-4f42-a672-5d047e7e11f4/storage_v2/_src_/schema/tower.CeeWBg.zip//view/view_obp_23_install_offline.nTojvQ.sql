create view view_obp_23_install_offline as
  select `a`.`province_code`    AS `province_code`,
         `a`.`prodbcatg_id`     AS `protype_code`,
         `a`.`scheme_id`        AS `scheme_id`,
         `b`.`supplier_code`    AS `supplier_code`,
         (`a`.`fee_rate` / 100) AS `Install_fee_rate`,
         `a`.`fee`              AS `Install_min_fee`
  from (`tower`.`obp_oth_ba_exchange_price` `a`
      join `tower`.`obp_supplier_base_info` `b`)
  where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = '1') and (`a`.`prodbcatg_id` in ('12', '23')));

