create function f_getsupplier_cerinfo_iso(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                          v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  
  set cer_info_temp='';
	set cer_info_html='';


 SELECT CONCAT('<br>','质量管理体系（ISO9000系列）认证信息:','<br>'
                ,'质量管理体系证书编号: ',q.certificate_code,'<br>'
								,'质量管理体系有效期至: ',q.certificate_valid_data,'<br>'
                ) 
  into cer_info_temp
from (
SELECT  certificate_code,certificate_valid_data
 from obp_supplier_qms_info a 
  
  where a.supplier_id=v_supplier_id  and a.certificate_type='quality' limit 1)q;

   set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';

 SELECT CONCAT('<br>','环境管理体系（ISO14000系列）认证信息:','<br>'
                ,'环境管理体系证书编号: ',q.certificate_code,'<br>'
								,'环境管理体系有效期至: ',q.certificate_valid_data,'<br>'
                ) 
  into cer_info_temp from (
SELECT  certificate_code,certificate_valid_data
 from obp_supplier_qms_info a 
  
  where a.supplier_id=v_supplier_id  and a.certificate_type='environment' limit 1)q;

   set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';

 SELECT CONCAT('<br>','职业健康安全管理体系（ISO18000系列）认证信息:','<br>'
                ,'职业健康安全管理体系证书编号: ',q.certificate_code,'<br>'
								,'职业健康安全管理体系有效期至: ',q.certificate_valid_data,'<br>'
                ) 
  into cer_info_temp
from (
SELECT  certificate_code,certificate_valid_data
 from obp_supplier_qms_info a 
  
  where a.supplier_id=v_supplier_id  and a.certificate_type='occupationalHealth' limit 1)q;

   set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';

 


  RETURN cer_info_html;
END;

