create view view_obp_product_images_a_offline as
  select `p`.`material_code`                                                               AS `material_code`,
         concat(replace(`f`.`file_abs_route`, '/mnt/nfs/', 'http://192.168.2.247:10000/')) AS `path`,
         ''                                                                                AS `sort`,
         ''                                                                                AS `isPrimary`
  from (((`tower`.`obp_prd_min_info_new` `p`
      join `tower`.`obp_file` `f`) join `tower`.`obp_file_rel` `r`) join `tower`.`obp_prd_base_info` `q`)
  where ((`p`.`id` = `r`.`rel_id`) and (`r`.`id` = `f`.`id`) and
         (`p`.`product_base_info_code` = `q`.`product_base_info_code`) and (`q`.`base_info_status` = '3') and
         (`p`.`status` = '1'));

