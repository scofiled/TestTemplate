create view view_obp_trans_dispri_h as
  select `a`.`quote_id`           AS `quote_id`,
         `a`.`supplier_id`        AS `supplier_id`,
         `a`.`province_code`      AS `province_code`,
         avg(`a`.`transport_fee`) AS `freight`,
         avg(`a`.`freight_rate`)  AS `freight_rate`,
         `c`.`prodbcatg_id`       AS `prodbcatg_id`,
         `a`.`batch_number`       AS `batch_number`
  from (`tower`.`obp_trans_dispri_h` `a`
      join `tower`.`view_obp_quote_rule` `c`)
  where (`a`.`quote_id` = `c`.`quote_id`)
  group by `a`.`batch_number`, `a`.`quote_id`, `a`.`supplier_id`, `a`.`province_code`;

