create view view_obp_cer_score_inst_prov_column as
  select max(if((`h`.`score_type` = 'A01'), `h`.`star`, '-999'))  AS `Service_star`,
         max(if((`h`.`score_type` = 'A01'), `h`.`score`, '-999')) AS `Service_mark`,
         max(if((`h`.`score_type` = 'B01'), `h`.`star`, '-999'))  AS `Quality_star`,
         max(if((`h`.`score_type` = 'B01'), `h`.`score`, '-999')) AS `Quality_mark`,
         `h`.`supplier_id`                                        AS `supplier_id`,
         `h`.`supplier_name`                                      AS `supplier_name`,
         `h`.`com_id`                                             AS `com_id`,
         `h`.`inst_status`                                        AS `inst_status`
  from `tower`.`obp_cer_score_inst_prov` `h`
  group by `h`.`supplier_id`;

