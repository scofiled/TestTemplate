create function f_getsupplier_cerinfo_ser_new(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                              v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN
  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  
  set cer_info_temp='';
  set cer_info_html='';

SELECT '<br>服务要素：' into cer_info_temp;
 set cer_info_html=CONCAT(cer_info_html,REPLACE(cer_info_temp,',',''));
   set cer_info_temp='';

    select GROUP_CONCAT('<br>',q.rule_name,':',q.element_value)into cer_info_temp from  (
SELECT
  rr.root_catg_item,r.rule_name,pe.element_value
FROM
  obp_supplier_prod_element pe,
  obp_prod_aut_element e,
  obp_cer_rule r,
  obp_cer_rule_catg rc,
  obp_cer_rule_rootcatg rr
WHERE
  pe.supplier_id = v_supplier_id
AND pe.scheme_id = v_product_big_type
AND pe.base_code = v_base_info_code
AND pe.state = '1'
AND pe.element_id=e.id
AND e.if_edit='1'
AND e.state='1'
AND e.rule_id=r.rule_id
AND r.is_use='1'
AND rc.catg_id=r.catg_id
AND rc.is_use='1'
AND rr.root_catg_id=rc.root_catg_id
AND rr.is_use='1'
AND rr.prod_bcatg='999999')q;


   set cer_info_html=CONCAT(cer_info_html,REPLACE(cer_info_temp,',',''));
   set cer_info_temp='';

  RETURN cer_info_html;
END;

