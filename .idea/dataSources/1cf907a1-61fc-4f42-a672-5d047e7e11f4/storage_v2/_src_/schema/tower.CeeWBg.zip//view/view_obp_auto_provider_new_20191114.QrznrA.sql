create view view_obp_auto_provider_new_20191114 as
  select `a`.`province_code` AS `province_code`,
         `a`.`org_code`      AS `city_code`,
         `a`.`area_code`     AS `country_code`,
         `a`.`scheme_id`     AS `scheme_id`,
         `b`.`supplier_code` AS `supplier_code`,
         `a`.`is_checked`    AS `is_checked`,
         `a`.`sort`          AS `sort`,
         `a`.`task_state`    AS `STATUS`,
         `a`.`task_id`       AS `rel_id`,
         `a`.`org_name`      AS `city_name`,
         `c`.`name`          AS `country_name`
  from ((`tower`.`obp_city_choose_result_online` `a`
      join `tower`.`obp_supplier_base_info` `b`) left join `tower`.`obp_mana_area` `c` on ((`a`.`area_code` =
                                                                                            `c`.`code`)))
  where (`a`.`supplier_id` = `b`.`id`);

