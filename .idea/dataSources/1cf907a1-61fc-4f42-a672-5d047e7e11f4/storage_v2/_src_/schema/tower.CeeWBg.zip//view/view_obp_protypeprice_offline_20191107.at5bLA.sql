create view view_obp_protypeprice_offline_20191107 as select `r`.`province_code`             AS `province_code`,
                                                             ifnull(`r`.`city_code`, '')     AS `city_code`,
                                                             ifnull(`r`.`product_btype`, '') AS `protype_code`,
                                                             `b`.`supplier_code`             AS `supplier_code`,
                                                             `r`.`product_score`             AS `Price_mark`,
                                                             `r`.`product_level`             AS `Price_star`,
                                                             (select ifnull(`s`.`score`, 0)
                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                     (`s`.`score_type` = 'A01') and
                                                                     (`s`.`status` = '1'))
                                                              order by `s`.`create_time` desc
                                                              limit 1)                       AS `Quality_mark`,
                                                             (select ifnull(`s`.`star`, 0)
                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                     (`s`.`score_type` = 'A01') and
                                                                     (`s`.`status` = '1'))
                                                              order by `s`.`create_time` desc
                                                              limit 1)                       AS `Quality_star`,
                                                             (select ifnull(`s`.`score`, 0)
                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                     (`s`.`score_type` = 'B01') and
                                                                     (`s`.`status` = '1'))
                                                              order by `s`.`create_time` desc
                                                              limit 1)                       AS `Service_mark`,
                                                             (select ifnull(`s`.`star`, 0)
                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                     (`s`.`score_type` = 'B01') and
                                                                     (`s`.`status` = '1'))
                                                              order by `s`.`create_time` desc
                                                              limit 1)                       AS `Service_star`,
                                                             `r`.`scheme_id`                 AS `scheme_id`
                                                      from ((`tower`.`obp_product_score_result` `r`
                                                          join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_prod_aut_scheme` `s`)
                                                      where ((`r`.`supplier_id` = `b`.`id`) and
                                                             (`r`.`scheme_id` = `s`.`id`) and
                                                             (`s`.`centralized_purchase_mode` = '1'))
                                                      union select '100000'                           AS `province_code`,
                                                                   ifnull(`r`.`city_code`, '')        AS `city_code`,
                                                                   `r`.`product_btype`                AS `protype_code`,
                                                                   `b`.`supplier_code`                AS `supplier_code`,
                                                                   round(avg(`r`.`product_score`), 2) AS `Price_mark`,
                                                                   round(avg(`r`.`product_level`), 0) AS `Price_star`,
                                                                   round(avg((select ifnull(`s`.`score`, 0)
                                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                                     (`s`.`score_type` = 'A01') and
                                                                                     (`s`.`status` = '1'))
                                                                              order by `s`.`create_time` desc
                                                                              limit 1)), 2)           AS `Quality_mark`,
                                                                   round(avg((select ifnull(`s`.`star`, 0)
                                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                                     (`s`.`score_type` = 'A01') and
                                                                                     (`s`.`status` = '1'))
                                                                              order by `s`.`create_time` desc
                                                                              limit 1)), 0)           AS `Quality_star`,
                                                                   round(avg((select ifnull(`s`.`score`, 0)
                                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                                     (`s`.`score_type` = 'B01') and
                                                                                     (`s`.`status` = '1'))
                                                                              order by `s`.`create_time` desc
                                                                              limit 1)), 2)           AS `Service_mark`,
                                                                   round(avg((select ifnull(`s`.`star`, 0)
                                                                              from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                              where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                                     (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                                     (`s`.`score_type` = 'B01') and
                                                                                     (`s`.`status` = '1'))
                                                                              order by `s`.`create_time` desc
                                                                              limit 1)), 0)           AS `Service_star`,
                                                                   `r`.`scheme_id`                    AS `scheme_id`
                                                            from (`tower`.`obp_product_score_result` `r`
                                                                join `tower`.`obp_supplier_base_info` `b`)
                                                            where (`r`.`supplier_id` = `b`.`id`)
                                                            group by `r`.`supplier_id`, `r`.`scheme_id`
                                                      union select `p`.`code`                      AS `province_code`,
                                                                   ifnull(`r`.`city_code`, '')     AS `city_code`,
                                                                   ifnull(`r`.`product_btype`, '') AS `protype_code`,
                                                                   `b`.`supplier_code`             AS `supplier_code`,
                                                                   `r`.`product_score`             AS `Price_mark`,
                                                                   `r`.`product_level`             AS `Price_star`,
                                                                   (select ifnull(`s`.`score`, 0)
                                                                    from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                    where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                           (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                           (`s`.`score_type` = 'A01') and
                                                                           (`s`.`status` = '1'))
                                                                    order by `s`.`create_time` desc
                                                                    limit 1)                       AS `Quality_mark`,
                                                                   (select ifnull(`s`.`star`, 0)
                                                                    from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                    where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                           (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                           (`s`.`score_type` = 'A01') and
                                                                           (`s`.`status` = '1'))
                                                                    order by `s`.`create_time` desc
                                                                    limit 1)                       AS `Quality_star`,
                                                                   (select ifnull(`s`.`score`, 0)
                                                                    from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                    where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                           (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                           (`s`.`score_type` = 'B01') and
                                                                           (`s`.`status` = '1'))
                                                                    order by `s`.`create_time` desc
                                                                    limit 1)                       AS `Service_mark`,
                                                                   (select ifnull(`s`.`star`, 0)
                                                                    from `tower`.`obp_cer_rule_rootcatg_score` `s`
                                                                    where ((`s`.`scheme_id` = `r`.`scheme_id`) and
                                                                           (`s`.`supplier_id` = `r`.`supplier_id`) and
                                                                           (`s`.`score_type` = 'B01') and
                                                                           (`s`.`status` = '1'))
                                                                    order by `s`.`create_time` desc
                                                                    limit 1)                       AS `Service_star`,
                                                                   `r`.`scheme_id`                 AS `scheme_id`
                                                            from (((`tower`.`obp_product_score_result` `r`
                                                                join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_prod_aut_scheme` `s`) join `tower`.`obp_province` `p`)
                                                            where ((`r`.`supplier_id` = `b`.`id`) and
                                                                   (`r`.`scheme_id` = `s`.`id`) and
                                                                   (`s`.`centralized_purchase_mode` = '0') and
                                                                   (`p`.`code` <> '100000'));

