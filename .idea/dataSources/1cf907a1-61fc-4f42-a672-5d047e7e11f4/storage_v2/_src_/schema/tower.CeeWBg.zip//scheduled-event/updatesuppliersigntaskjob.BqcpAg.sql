create definer = obp@`%` event updateSupplierSignTaskJob
  on schedule
    every '1' SECOND
      starts '2019-12-11 11:02:25'
  on completion preserve
  enable
do
  call updateSuppliSignTask();

