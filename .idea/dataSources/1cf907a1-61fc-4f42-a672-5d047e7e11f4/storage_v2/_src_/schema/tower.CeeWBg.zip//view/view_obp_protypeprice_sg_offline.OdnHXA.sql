create view view_obp_protypeprice_sg_offline as
  select `r`.`province_code`                                           AS `province_code`,
         ifnull(`r`.`city_code`, '')                                   AS `city_code`,
         `r`.`product_btype`                                           AS `protype_code`,
         `b`.`supplier_code`                                           AS `supplier_code`,
         `r`.`product_score`                                           AS `Price_mark`,
         `r`.`product_level`                                           AS `Price_star`,
         (select `s`.`score`
          from `tower`.`obp_cer_rule_rootcatg_score` `s`
          where ((`s`.`scheme_id` = `r`.`scheme_id`) and (`s`.`supplier_id` = `r`.`supplier_id`) and
                 (`s`.`score_type` = 'A01') and (`s`.`status` = '1'))) AS `Quality_mark`,
         (select `s`.`star`
          from `tower`.`obp_cer_rule_rootcatg_score` `s`
          where ((`s`.`scheme_id` = `r`.`scheme_id`) and (`s`.`supplier_id` = `r`.`supplier_id`) and
                 (`s`.`score_type` = 'A01') and (`s`.`status` = '1'))) AS `Quality_star`,
         (select `s`.`score`
          from `tower`.`obp_cer_rule_rootcatg_score` `s`
          where ((`s`.`scheme_id` = `r`.`scheme_id`) and (`s`.`supplier_id` = `r`.`supplier_id`) and
                 (`s`.`score_type` = 'B01') and (`s`.`status` = '1'))) AS `Service_mark`,
         (select `s`.`star`
          from `tower`.`obp_cer_rule_rootcatg_score` `s`
          where ((`s`.`scheme_id` = `r`.`scheme_id`) and (`s`.`supplier_id` = `r`.`supplier_id`) and
                 (`s`.`score_type` = 'B01') and (`s`.`status` = '1'))) AS `Service_star`,
         `r`.`scheme_id`                                               AS `scheme_id`
  from `tower`.`obp_product_score_result` `r`
         join `tower`.`obp_supplier_base_info` `b`
         join `tower`.`obp_prod_aut_scheme` `c`
  where ((`r`.`supplier_id` = `b`.`id`) and (`r`.`scheme_id` = `c`.`id`) and (`c`.`aut_type` = 'SERVICE') and
         (`c`.`org_code` <> '100001'));

