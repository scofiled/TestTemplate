create procedure p_updateSupplierName(IN supplier_id varchar(32), IN supplier_name varchar(100))
  BEGIN


DECLARE v_supplier_id VARCHAR (32) DEFAULT '';


DECLARE v_supplier_name VARCHAR (100) DEFAULT '';


SET v_supplier_id = supplier_id;


SET v_supplier_name = supplier_name;

START TRANSACTION;

UPDATE     obp_cap_user_extend a,cap_user b set b.USER_NAME = v_supplier_name where a.operator_id = b.OPERATOR_ID and a.supplier_id = v_supplier_id;
update   obp_prd_base_info              a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;

update  obp_prd_factory_info a ,obp_prd_base_info b set a.org_name=v_supplier_name
where a.product_base_info_code=b.product_base_info_code and b.supplier_id= v_supplier_id;
update  obp_prd_storeroom_info a ,obp_prd_base_info b set a.org_name=v_supplier_name
where a.product_base_info_code=b.product_base_info_code and b.supplier_id= v_supplier_id;

update   obp_prd_min_info               a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_supplier_factory_info      a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_supplier_product_base_info a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_supplier_product_info      a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_supplier_storeroom_info    a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_supplier_test_info         a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_tower_product_base_info    a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_tower_product_info         a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;
update   obp_tw_supplier_factory_info   a set a.org_name=v_supplier_name where a.supplier_id=v_supplier_id;

COMMIT;


END;

