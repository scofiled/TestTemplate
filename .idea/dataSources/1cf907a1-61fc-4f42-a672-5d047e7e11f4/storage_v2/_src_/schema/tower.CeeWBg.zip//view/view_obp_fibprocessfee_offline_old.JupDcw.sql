create view view_obp_fibprocessfee_offline_old as
  select `view_obp_fibprocessfee_offline`.`supplier_code` AS `supplier_code`,
         `view_obp_fibprocessfee_offline`.`product_type`  AS `product_type`,
         `view_obp_fibprocessfee_offline`.`product_spec`  AS `product_spec`,
         `view_obp_fibprocessfee_offline`.`protype_code`  AS `protype_code`,
         `view_obp_fibprocessfee_offline`.`process_fee`   AS `process_fee`
  from `tower`.`view_obp_fibprocessfee_offline`;

