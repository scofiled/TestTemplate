create view obp_prd_min_type as
  select `a`.`id`             AS `id`,
         `a`.`parent_code`    AS `parent_code`,
         `a`.`code`           AS `code`,
         `a`.`name`           AS `name`,
         `a`.`sort_no`        AS `sort_no`,
         `a`.`is_use`         AS `is_use`,
         `a`.`col1`           AS `col1`,
         `a`.`col2`           AS `col2`,
         `a`.`col3`           AS `col3`,
         `a`.`col4`           AS `col4`,
         `a`.`col5`           AS `col5`,
         `a`.`unit`           AS `unit`,
         `a`.`is_comp`        AS `is_comp`,
         `a`.`prd_desc`       AS `prd_desc`,
         `a`.`is_electricity` AS `is_electricity`,
         `a`.`is_pmscode`     AS `is_pmscode`,
         `a`.`prov_code`      AS `prov_code`
  from `tower`.`obp_prd_min_type_new` `a`
  where (`a`.`is_electricity` = '1');

