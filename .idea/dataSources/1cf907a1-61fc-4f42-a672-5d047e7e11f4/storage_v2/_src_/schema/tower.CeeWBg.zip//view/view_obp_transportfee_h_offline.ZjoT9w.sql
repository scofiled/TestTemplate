create view view_obp_transportfee_h_offline as select `a`.`province_code` AS `province_code`,
                                                      `b`.`supplier_code` AS `supplier_code`,
                                                      `a`.`from_addr`     AS `from_addr`,
                                                      `a`.`to_addr`       AS `to_addr`,
                                                      `a`.`transport_fee` AS `transport_fee`,
                                                      `a`.`mileage`       AS `mileage`,
                                                      `c`.`product_id`    AS `protype_code`,
                                                      `a`.`batch_number`  AS `batch_number`
                                               from ((`tower`.`obp_trans_dispri_h` `a`
                                                   join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_parity_model` `c`)
                                               where ((`a`.`quote_id` = `c`.`id`) and (`a`.`supplier_id` = `b`.`id`) and
                                                      (`a`.`to_addr` not in ('110000', '120000', '310000', '500000')))
                                               union all select `a`.`province_code` AS `province_code`,
                                                                `b`.`supplier_code` AS `supplier_code`,
                                                                `a`.`from_addr`     AS `from_addr`,
                                                                `d`.`code`          AS `to_addr`,
                                                                `a`.`transport_fee` AS `transport_fee`,
                                                                `a`.`mileage`       AS `mileage`,
                                                                `c`.`product_id`    AS `protype_code`,
                                                                `a`.`batch_number`  AS `batch_number`
                                                         from (((`tower`.`obp_trans_dispri_h` `a`
                                                             join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_parity_model` `c`) join `tower`.`obp_city` `d`)
                                                         where ((`a`.`quote_id` = `c`.`id`) and
                                                                (`a`.`supplier_id` = `b`.`id`) and
                                                                (`a`.`to_addr` = `d`.`p_code`) and (`a`.`to_addr` in (
                                                             '110000',
                                                             '120000',
                                                             '310000',
                                                             '500000')));

