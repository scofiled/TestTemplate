create procedure p_update_aut_construct_quote_view(IN quoteId varchar(32), OUT flag int)
  BEGIN

/***********************************************************
* 存储过程名    : P_UPDATE_AUT_CONSTRUCT_QUOTE_VIEW
* 参数列表      : 
                    IN  quoteId varchar(32),     -- 报价规则编码
                    OUT flag    int              -- 输出代码 (1:成功；<0 失败)
* 建立日期      : 2019/1/24
* 作者          : 梁冰
* 模块          : 施工服务报价管理
* 描述          : 施工服务报价管理中价格公示按钮触发调用该过程
                                  
*------------------------------------------------------------
* 修改历史
* 序号   日期           修改人        修改原因
* 01     2019/1/24      梁冰          在 P_UPDATE_CONSTRUCT_QUOTE_VIEW 基础上改造，
                                      原产品和服务报价业务逻辑去产品大类改造，改为按【obp_prod_aut_scheme】认证方案关联。 
* 02     2019/1/29      梁冰          导入表变更
                                      obp_cer_score_inst_temp -> obp_cer_rule_rootcatg_score_temp
                                      obp_cer_score_inst -> obp_cer_rule_rootcatg_score
                               
*************************************************************/

    DECLARE vsSchemeId      VARCHAR(32);    -- 认证方案编码
    DECLARE vsProvCode      VARCHAR(128);   -- 省分编码
    DECLARE vsOrgCode       VARCHAR(128);   -- 组织编码
    DECLARE vsProdBcatg     VARCHAR(32);    -- 产品大类编码
    
    -- 事务开始
    START TRANSACTION;

    -- 获取认证方案编码
    SELECT scheme_id, prodbcatg_id 
    INTO vsSchemeId, vsProdBcatg
    FROM obp_oth_quote_rule
    WHERE quote_id = quoteId;
    
    -- 获取认证方案归属省分编码
    SELECT prov_org_code, org_code
    INTO vsProvCode, vsOrgCode
    FROM obp_prod_aut_scheme
    WHERE id = vsSchemeId;

    DELETE a.*
    FROM obp_oth_construct_quote_use a
    WHERE  a.quote_id = quoteId;

    INSERT into obp_oth_construct_quote_use (
        id,
        quote_id,
        scheme_id,
        supplier_id,
        group_id,
        prodbcatg_id,
        prov_code,
        city_code,
        discount,
        status,
        col1,
        col2,
        col3,
        col4,
        create_emp,
        create_time
    )
    SELECT
        id,
        quote_id,
        scheme_id,
        supplier_id,
        group_id,
        prodbcatg_id,
        prov_code,
        city_code,
        discount,
        status,
        col1,
        col2,
        col3,
        col4,
        create_emp,
        create_time    
    FROM obp_oth_construct_quote a
    WHERE  a.quote_id = quoteId;

    DELETE a.*
    FROM obp_oth_construct_product_quote_use a
    WHERE  a.quote_id = quoteId;

    INSERT into obp_oth_construct_product_quote_use
    SELECT *
    FROM obp_oth_construct_product_quote a
    WHERE  a.quote_id = quoteId;

    DELETE a.*
    FROM obp_cer_rule_rootcatg_score a
    WHERE  a.scheme_id = vsSchemeId;

    INSERT into obp_cer_rule_rootcatg_score (
        id,
        supplier_id,
        base_code,
        scheme_id,
        org_code,
        score_type,
        score_name,
        score,
        star,
        status,
        create_emp,
        create_time,
        update_emp,
        update_time,
        col1,
        col2,
        col3,
        col4,
        col5
    )
    SELECT 
        id,
        supplier_id,
        base_code,
        scheme_id,
        org_code,
        score_type,
        score_name,
        score,
        star,
        status,
        create_emp,
        create_time,
        update_emp,
        update_time,
        col1,
        col2,
        col3,
        col4,
        col5  
    FROM obp_cer_rule_rootcatg_score_temp a
    WHERE  a.scheme_id = vsSchemeId;

    DELETE a.*
    FROM obp_product_score_result a
    WHERE  a.scheme_id = vsSchemeId;

    INSERT into obp_product_score_result (
        supplier_id,
        product_btype,
        province_code,
        product_total_price,
        best_price,
        product_score,
        product_level,
        create_time,
        col1,
        col2,
        col3,
        col4,
        city_code,
        scheme_id,
        quote_id
    )
    SELECT 
        supplier_id,
        product_btype,
        province_code,
        product_total_price,
        best_price,
        product_score,
        product_level,
        create_time,
        col1,
        col2,
        col3,
        col4,
        city_code,
        scheme_id,
        quote_id
    FROM obp_product_score_result_temp a
    WHERE  a.scheme_id = vsSchemeId;

    COMMIT;
    SET flag=1;

END;

