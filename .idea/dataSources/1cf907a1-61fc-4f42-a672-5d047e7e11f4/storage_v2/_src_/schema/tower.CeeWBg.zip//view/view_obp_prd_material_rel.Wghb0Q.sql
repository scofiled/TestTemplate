create view view_obp_prd_material_rel as
  select `r`.`product_id`           AS `materail_class`,
         `r`.`material_code`        AS `category_code`,
         `r`.`fib_process_fee_type` AS `fibLineProcessFeeType`,
         `r`.`fib_core_number`      AS `fibCoreNumber`,
         (case
            when (`r`.`sys_code` = 'TOP_JY') then 1
            else 0 end)             AS `is_electricity`,
         `r`.`is_block`             AS `is_block`,
         `o`.`accounting_item`      AS `budget_usage`,
         `r`.`prov_org_code`        AS `province_code`,
         `r`.`status`               AS `status`
  from ((`tower`.`obp_prd_material_rel` `r`
      join `tower`.`obp_prd_min_type_new` `m`) join `tower`.`obp_pur_material_code_offline` `o`)
  where ((`r`.`product_id` = `m`.`id`) and (`r`.`material_code` = `o`.`material_code`));

