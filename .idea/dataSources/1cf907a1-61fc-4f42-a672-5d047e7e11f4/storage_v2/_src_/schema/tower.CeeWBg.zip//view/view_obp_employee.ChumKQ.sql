create view view_obp_employee as
  select `e`.`USERID`                                                                                       AS `uid`,
         `e`.`EMPNAME`                                                                                      AS `cn`,
         `e`.`OEMAIL`                                                                                       AS `cumail`,
         `o`.`ORGCODE`                                                                                      AS `ou`,
         (select concat(`p`.`ORGNAME`, '-', `o`.`ORGNAME`)
          from `tower`.`org_organization` `p`
          where (`o`.`PARENTORGID` = `p`.`ORGID`))                                                          AS `OrgFullName`,
         ''                                                                                                 AS `site`,
         (select `p`.`ORGCODE`
          from `tower`.`org_organization` `p`
          where (`o`.`PARENTORGID` = `p`.`ORGID`))                                                          AS `cuCompanyNumber`
  from ((`tower`.`org_employee` `e`
      join `tower`.`org_emporg` `g`) join `tower`.`org_organization` `o`)
  where ((`e`.`EMPID` = `g`.`EMPID`) and (`o`.`ORGID` = `g`.`ORGID`) and (`e`.`USERID` not in
                                                                          ('gytt', 'chengxbsc', 'gss-cxbsc', 'gss-hxbscbsc', 'gongsld', 'wangyp', 'gongsldms', 'hqs-gnws', 'monitor_one', 'monitor_three', 'monitor_two', 'postmaster', 'tangsan', 'tangsi', 'tangwu', 'zhanger', 'zhangliu', 'zhangsan', 'zhangsi', 'zhangwu', 'zongbdgsy', 'zongbdj', 'zongbfb', 'zongbffgd', 'zongbfh', 'zongbhg', 'zongbpbcqy', 'zongbzhbld', 'zongbzhbpy', 'zongbzlgd', 'kefbbmfzjl', 'kefbbmwjgly', 'kefbbmzjl', 'kefbcsjl', 'kefbyg', 'zhangba', 'zhangqi', 'huangqx', 'mayi', 'mayi', 'jianswhbbmfzjl', 'jianswhbbmwjgly', 'jianswhbbmzjl', 'jianswhbcsjl', 'jianswhbyg', 'zgttjswhb', 'zhangjiu', 'zhangshi', 'zongbucmd', 'guoxk', 'hr', 'hr-zhaopin', 'lier', 'zhaopin', 'buzk', 'caiwbbmfzjl', 'caiwbbmwjgly', 'caiwbbmzjl', 'caiwbcsjl', 'caiwbyg', 'lisan', 'lisi', 'chinatop', 'liwu', 'jiaoyh', 'gongchengshenji', 'liqi', 'wanger', 'alitest3', 'alitest5', 'alitest6', 'eshop_support', 'ITsupport', 'OAsupport', 'renlzp', 'xiejg', 'yang', 'ceszh', 'zhaopin-bj', 'tjtthr', 'tjtttr', 'zhaopin-tj', 'cuiyan', 'hbxp', 'zhaopin-hb', 'xush3', 'guwk', 'guwk', 'cuipx', 'cuipx3', 'wangfy', 'xingqj', 'xingqj', 'zhaopin-nmg', 'zhaopin-jl', 'zhaopin-hlj', 'qinhao3', 'shs-zhb', 'shs-zjl', 'xxtd', 'zhaopin-sh', 'yunyfzb', 'caiwb', 'nanqfgs3', 'xiqfgs', 'beiqfgs3', 'minxqfgs', 'baosqfgs3', 'jiadqfgs', 'pudxmgl', 'pudxqfgs', 'jinsqfgs', 'songjqfgs', 'qingpqfgs', 'fengxqfgs', 'chongmxfgs3', 'jss-cg', 'jss-cgfk', 'jss-cgxd', 'zhaopin-js', 'zhaopin-zj', 'zjttjj', 'zhaopin-ah', 'luyong3', 'fj-linxl3', 'fjtower', 'zhaopin-fj', 'zhaopin-jx', 'zhaopin-sd', 'zhaopin-hen', 'zhaopin-hun', 'wangyj6', 'yuwyb', 'hb-hubttwy', 'hb-hubtdztb', 'hb-hubttls', 'hb-matao', 'zhaopin-hub', 'yanchao', 'anxh', 'lizhou', 'wulq3', 'wulq3', 'wulq3', 'lijp6', 'gds-wldyj', 'gdtower', 'zhaopin-gd', 'gds-gdyfbgg', 'tangxq', 'tangxq3', 'gzjijian', 'gzrenli', 'sztower', 'wangsc5', 'cengxm3', 'gds-zqtt', 'hzzjlyx', 'swtower', 'tanzq3', 'gds-zgttyjsfgs', 'zsjijian', 'zsrenli', 'zszhb', 'zsyf', 'zsjw', 'zscw', 'fuming', 'gxzhb', 'zhaopin-gx', 'chenxj3', 'nongjun', 'nongjun', 'huangsm', 'heyang3', 'zhaopin-hn', 'wangwei', 'zhaopin-cq', 'zhaopin-sc', 'geyf3', 'geyf3', 'lizl11', 'zhaopin-gz', 'zhoucl3', 'guizhouga', 'gzgy', 'gzlp', 'gzzy', 'gzas', 'gzbj', 'gztr', 'gzqx', 'gzqd', 'gzqn', 'zhaopin-yn', 'zhaopin-xz', 'szzm', 'zhaopin-shanx', 'gsttcgts', 'zhaopin-gs', 'gsttyyfzb', 'liucheng3', 'zhaopin-qh', 'ningxjc', 'zhaopin-nx', 'zhaopin-xj', 'tianjincmd', 'tjcg', 'hebeicmd', 'shanxijcmd', 'neimenggucmd', 'liaoningcmd', 'jilincmd', 'fuyu', 'heilongjiangcmd', 'shanghaicmd', 'jiangsucmd', 'zhejiangcmd', 'anhuicmd', 'fujiancmd', 'jiangxicmd', 'shandongcmd', 'wanglh', 'henancmd', 'henqc', 'henxt', 'hubeicmd', 'hunancmd', 'guangdongcmd', 'guangxicmd', 'oucheng', 'hainancmd', 'chongqingcmd', 'sichuancmd', 'guizhoucmd', 'yunnancmd', 'xizangcmd', 'shanxiscmd', 'gansucmd', 'qinghaicmd', 'ningxiacmd', 'xinjiangcmd', 'beijingcmd', 'beijjwb')) and
         (not((`e`.`EMPNAME` like '%招聘%'))) and (not((`e`.`EMPNAME` like '%支撑%'))) and
         (not((`e`.`EMPNAME` like '%邮箱%'))) and (not((`e`.`EMPNAME` like '%清查%'))) and
         (not((`e`.`EMPNAME` like '%公司%'))) and (not((`e`.`EMPNAME` like '%采购%'))) and
         (not((`e`.`EMPNAME` like '%下单%'))) and (not((`e`.`EMPNAME` like '%账号%'))) and
         (not((`e`.`EMPNAME` like '%测试%'))) and (not((`e`.`EMPNAME` like '%办事%'))) and
         (not((`e`.`EMPNAME` like '%投诉%'))) and (not((`e`.`EMPNAME` like '%审计%'))) and
         (not((`e`.`EMPNAME` like '%工程%'))) and (not((`e`.`EMPNAME` like '%领导%'))) and
         (not((`e`.`EMPNAME` like '%秘书%'))) and (not((`e`.`EMPNAME` like '%公文%'))) and
         (not((`e`.`EMPNAME` like '%完善%'))) and (not((`e`.`EMPNAME` like '%功能%'))) and
         (not((`e`.`EMPNAME` like '%监察%'))) and (not((`e`.`EMPNAME` like '%纪检%'))) and
         (not((`e`.`EMPNAME` like '%人力资源%'))) and (not((`e`.`EMPNAME` like '%选聘%'))) and
         (not((`e`.`EMPNAME` like '%协同%'))) and (not((`e`.`EMPNAME` like '%律师%'))) and
         (not((`e`.`EMPNAME` like '%物业%'))) and (not((`e`.`EMPNAME` like '%招投标%'))) and
         (not((`e`.`EMPNAME` like '%管理%'))) and (not((`e`.`EMPNAME` like '%经理%'))) and
         (not((`e`.`EMPNAME` like '%员工%'))) and (not((`e`.`EMPNAME` like '%人力招聘%'))) and
         (not((`e`.`EMPNAME` like '%培训%'))) and (not((`e`.`EMPNAME` like '%综合%'))) and
         (not((`e`.`EMPNAME` like '%商务%'))) and (not((`e`.`EMPNAME` like '%网络%'))) and
         (not((`e`.`EMPNAME` like '%打印%'))) and (not((`e`.`EMPNAME` like '%信息%'))) and
         (not((`e`.`EMPNAME` like '%投递%'))) and (not((`e`.`EMPNAME` like '%监控%'))) and
         (not((`e`.`EMPNAME` like '%月报%'))) and (not((`e`.`EMPNAME` like '%发展部%'))) and
         (not((`e`.`EMPNAME` like '%运营%'))) and (not((`e`.`EMPNAME` like '%作废%'))) and
         (not((`e`.`EMPNAME` like '%维护部%'))) and (not((`e`.`EMPNAME` like '%财务部%'))) and
         (not((`e`.`EMPNAME` like '%综合部%'))) and (not((`e`.`EMPNAME` like '%总部%'))) and
         (not((`e`.`EMPNAME` like '%登记%'))) and (not((`e`.`EMPNAME` like '%定稿%'))) and
         (not((`e`.`EMPNAME` like '%分办%'))) and (not((`e`.`EMPNAME` like '%归档%'))) and
         (not((`e`.`EMPNAME` like '%复核%'))) and (not((`e`.`EMPNAME` like '%核稿%'))) and
         (not((`e`.`EMPNAME` like '%排板%'))) and (not((`e`.`EMPNAME` like '%批阅%'))));

