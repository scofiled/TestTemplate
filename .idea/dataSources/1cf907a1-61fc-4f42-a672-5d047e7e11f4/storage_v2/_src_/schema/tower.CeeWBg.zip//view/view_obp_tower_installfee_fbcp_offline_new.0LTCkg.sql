create view view_obp_tower_installfee_fbcp_offline_new as
  select `e`.`AREA`                            AS `province_code`,
         `a`.`province_id`                     AS `city_code`,
         ''                                    AS `protype_code`,
         `d`.`scheme_id`                       AS `scheme_id`,
         `b`.`supplier_code`                   AS `supplier_code`,
         format((`a`.`install_rate` / 100), 4) AS `Install_fee_rate`
  from `tower`.`obp_tower_install_quote` `a`
         join `tower`.`obp_supplier_base_info` `b`
         join `tower`.`org_organization` `c`
         join `tower`.`org_organization` `e`
         join `tower`.`obp_oth_quote_rule` `d`
  where ((`a`.`province_id` = `c`.`ORGCODE`) and (`a`.`supplier_id` = `b`.`id`) and (`c`.`ORGLEVEL` = '3') and
         (`c`.`PARENTORGID` = `e`.`ORGID`) and (`e`.`ORGLEVEL` = '2') and (`a`.`quote_id` = `d`.`quote_id`));

