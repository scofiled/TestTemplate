create view view_obp_product_file_offline as select `b`.`material_code`                         AS `material_code`,
                                                    `b`.`product_describe`                      AS `pro_explain`,
                                                    '1'                                         AS `type`,
                                                    concat(replace(`c`.`file_abs_route`, '/mnt/nfs/',
                                                                   'http://www.tower.com.cn/')) AS `path`,
                                                    `c`.`file_name`                             AS `filename`
                                             from (((`tower`.`obp_prd_base_info` `a`
                                                 join `tower`.`obp_prd_min_info_new` `b`) left join `tower`.`obp_file_rel` `d` on ((
                                               concat(`b`.`id`, 'productDescribeFile') =
                                               `d`.`rel_id`))) left join `tower`.`obp_file` `c` on ((`c`.`id` =
                                                                                                     `d`.`id`)))
                                             where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and
                                                    (`a`.`base_info_status` = '3') and (`b`.`status` = '1'))
                                             union all select `b`.`material_code`                         AS `material_code`,
                                                              `b`.`product_describe`                      AS `pro_explain`,
                                                              '2'                                         AS `type`,
                                                              concat(replace(`c`.`file_abs_route`, '/mnt/nfs/',
                                                                             'http://www.tower.com.cn/')) AS `path`,
                                                              `c`.`file_name`                             AS `filename`
                                                       from (((`tower`.`obp_prd_base_info` `a`
                                                           join `tower`.`obp_prd_min_info_new` `b`) left join `tower`.`obp_file_rel` `d` on ((
                                                         concat(`b`.`id`, 'functionFeaturesFile') =
                                                         `d`.`rel_id`))) left join `tower`.`obp_file` `c` on ((`c`.`id`
                                                                                                               =
                                                                                                               `d`.`id`)))
                                                       where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and
                                                              (`a`.`base_info_status` = '3') and (`b`.`status` = '1'))
                                             union all select `b`.`material_code`                         AS `material_code`,
                                                              `b`.`product_describe`                      AS `pro_explain`,
                                                              '3'                                         AS `type`,
                                                              concat(replace(`c`.`file_abs_route`, '/mnt/nfs/',
                                                                             'http://www.tower.com.cn/')) AS `path`,
                                                              `c`.`file_name`                             AS `filename`
                                                       from (((`tower`.`obp_prd_base_info` `a`
                                                           join `tower`.`obp_prd_min_info_new` `b`) left join `tower`.`obp_file_rel` `d` on ((
                                                         concat(`b`.`id`, 'fitSceneFile') =
                                                         `d`.`rel_id`))) left join `tower`.`obp_file` `c` on ((`c`.`id`
                                                                                                               =
                                                                                                               `d`.`id`)))
                                                       where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and
                                                              (`a`.`base_info_status` = '3') and (`b`.`status` = '1'))
                                             union all select `b`.`material_code`                         AS `material_code`,
                                                              `b`.`product_describe`                      AS `pro_explain`,
                                                              '4'                                         AS `type`,
                                                              concat(replace(`c`.`file_abs_route`, '/mnt/nfs/',
                                                                             'http://www.tower.com.cn/')) AS `path`,
                                                              `c`.`file_name`                             AS `filename`
                                                       from (((`tower`.`obp_prd_base_info` `a`
                                                           join `tower`.`obp_prd_min_info_new` `b`) left join `tower`.`obp_file_rel` `d` on ((
                                                         concat(`b`.`id`, 'installConditionFile') =
                                                         `d`.`rel_id`))) left join `tower`.`obp_file` `c` on ((`c`.`id`
                                                                                                               =
                                                                                                               `d`.`id`)))
                                                       where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and
                                                              (`a`.`base_info_status` = '3') and (`b`.`status` = '1'))
                                             union all select `b`.`material_code`                         AS `material_code`,
                                                              `b`.`product_describe`                      AS `pro_explain`,
                                                              '5'                                         AS `type`,
                                                              concat(replace(`c`.`file_abs_route`, '/mnt/nfs/',
                                                                             'http://www.tower.com.cn/')) AS `path`,
                                                              `c`.`file_name`                             AS `filename`
                                                       from (((`tower`.`obp_prd_base_info` `a`
                                                           join `tower`.`obp_prd_min_info_new` `b`) left join `tower`.`obp_file_rel` `d` on ((
                                                         concat(`b`.`id`, 'mainTechnicalIndexFile') =
                                                         `d`.`rel_id`))) left join `tower`.`obp_file` `c` on ((`c`.`id`
                                                                                                               =
                                                                                                               `d`.`id`)))
                                                       where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and
                                                              (`a`.`base_info_status` = '3') and (`b`.`status` = '1'));

