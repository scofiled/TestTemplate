create view view_obp_quote_rule as select `kk`.`quote_id`     AS `quote_id`,
                                          `kk`.`prodbcatg_id` AS `prodbcatg_id`,
                                          `kk`.`scheme_id`    AS `scheme_id`
                                   from `tower`.`obp_oth_quote_rule` `kk`
                                   union all select `jj`.`id`         AS `quote_id`,
                                                    `jj`.`product_id` AS `prodbcatg_id`,
                                                    `jj`.`scheme_id`  AS `scheme_id`
                                             from `tower`.`obp_parity_model` `jj`;

