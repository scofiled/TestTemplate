create procedure p_batch_create_obp_pur_demand()
  BEGIN
    DECLARE done boolean default 0;
    DECLARE temp VARCHAR(64);
    DECLARE fromDemand varchar(64);
    DECLARE demandDetailsId varchar(64);
    DECLARE demandDetailsRelId varchar(64);
    DECLARE whileDemandDetailsId varchar(64);
    DECLARE whileDemandDetailsRelId varchar(64);
    DECLARE demandCode VARCHAR(64);
    DECLARE demandName VARCHAR(256);
    DECLARE count int DEFAULT 0;
    DECLARE loopCount int DEFAULT 0;
    
    #声明游标
    DECLARE c_demand_details CURSOR FOR 
        SELECT 
            id 
        FROM obp_pur_demand_details 
        WHERE pur_demand_code = fromDemand;
        
    DECLARE c_demand_details_rel CURSOR FOR 
        SELECT 
            id
        FROM obp_pur_demand_details_rel WHERE pur_rel_id = demandDetailsId;

    # 当 SQLSTATE '02000'出现时，SET done=1。
    # SQLSTATE '02000'是一个未找到条件
    DECLARE continue handler for sqlstate '02000' SET done = 1;

    set fromDemand = 'XQ-469002-20200116163321';
    # select id into demandDetailsId from obp_pur_demand_details where pur_demand_code = fromDemand;

    myWhile:
    WHILE count < 10
    DO
      set count = count + 1;
      set temp = LPAD(count, 3, '0');

      -- 设置需求编号
      set demandCode = concat(concat('XQ-469002-', date_format(now() , '%Y%m%d%H%i%s')), temp);
      -- select demandCode;

      -- 设置需求名称
      set demandName = concat(concat('梁冰测试使用', DATE_FORMAT(now(), '%i%s')), temp);
      -- select demandName;

      -- 插入需求表
      insert into obp_pur_demand_header
      select
      @x:=REPLACE(uuid(), '-', '') AS 'id',
      t.data_sources,
      t.data_id,
      t.data_param,
      t.dept_code,
      t.dept_name,
      t.org_code,
      t.org_name,
      t.prov_org_code,
      t.prov_org_name,
      t.pur_type,
      demandCode as pur_demand_code,
      demandName as pur_project_name,
      t.pur_project_type,
      t.pur_large_project_type,
      t.pur_use_type,
      t.pur_data_type,
      t.pur_details_type,
      t.pur_basis,
      t.pur_basis_number,
      t.pur_validity,
      t.pur_total_number,
      t.pur_total_amount,
      t.pur_capital_source_workable,
      t.pur_we_pay,
      t.pur_mode,
      t.pur_mode_desc,
      t.pur_basic_describe,
      t.demand_contractor_code,
      t.demand_contractor_name,
      t.demand_contractor_audit_opinion,
      t.demand_contractor_phone,
      t.dept_lead_code,
      t.dept_lead_name,
      t.dept_lead_audit_opinion,
      t.dept_lead_submit_time,
      t.co_lead_agree,
      t.co_lead_code,
      t.co_lead_name,
      t.co_lead_audit_opinion,
      t.co_lead_submit_time,
      t.entrust_superior_handle,
      t.co_manager_code,
      t.co_manager_name,
      t.co_manager_audit_opinion,
      t.co_manager_submit_time,
      t.imp_dept_lead_code,
      t.imp_dept_lead_name,
      t.imp_dept_lead_audit_opinion,
      t.imp_dept_lead_submit_time,
      t.pur_contractor_code,
      t.pur_contractor_name,
      t.pur_contractor_audit_opinion,
      t.pur_contractor_submit_time,
      t.process_step,
      t.process_inst_id,
      t.process_inst_status,
      t.process_start_emp,
      t.process_start_time,
      t.create_emp,
      now(),
      t.update_emp,
      t.update_time,
      t.pur_change_flag,
      t.pur_change_desc,
      t.pur_nullify_reason_describe,
      t.col1,
      t.col2,
      t.col3,
      t.col4,
      t.col5,
      t.pur_nullify_emp,
      t.pur_nullify_time,
      t.pur_we_pay_way,
      t.pur_majorleader_approval,
      t.pur_manager_approval,
      t.imp_co_lead_code,
      t.imp_co_lead_name,
      t.imp_co_lead_audit_opinion,
      t.imp_co_lead_submit_time,
      t.enterp_type,
      t.sign_enterp_type
      from (select * from obp_pur_demand_header where pur_demand_code = fromDemand) t;


      #使用游标前打开游标
      OPEN c_demand_details; 
      
      # 开始循环 loop_c1
      loop_c_demand_details : LOOP
          # 遍历游标
          FETCH c_demand_details INTO demandDetailsId;
          
          IF done THEN
            set done = 0;
            LEAVE loop_c_demand_details;
          END IF;

          set whileDemandDetailsId = REPLACE(uuid(), '-', '');
          
          -- select whileDemandDetailsId;
          set loopCount = loopCount + 1;
          
          -- 插入需求明细表
          INSERT INTO obp_pur_demand_details
          SELECT
          whileDemandDetailsId AS 'id',
          demandCode AS pur_demand_code,
          t.pur_prd_type_code,
          t.pur_prd_type_name,
          t.pur_prd_subtype_code,
          t.pur_prd_subtype_name,
          t.pur_prd_mintype_code,
          t.pur_prd_mintype_name,
          t.pur_material_code,
          t.pur_material_name,
          t.pur_number,
          t.pur_amount,
          t.remark,
          t.status,
          t.col1,
          t.col2,
          t.col3,
          t.col4,
          t.col5
          FROM (SELECT * FROM obp_pur_demand_details WHERE id = demandDetailsId) t;

          OPEN c_demand_details_rel;          
          loop_c_demand_details_rel : LOOP
              # 遍历游标
              FETCH c_demand_details_rel INTO demandDetailsRelId;
              
              IF done THEN
                set done = 0;
                LEAVE loop_c_demand_details_rel;
              END IF;
              
              set whileDemandDetailsRelId = REPLACE(uuid(), '-', '');
              
              -- 插入采购需求明细对应的采购清单
              INSERT INTO obp_pur_demand_details_rel
              SELECT
              whileDemandDetailsRelId AS 'id',
              whileDemandDetailsId AS 'pur_rel_id',
              pur_demand_code,
              pur_prd_type_code,
              pur_prd_type_name,
              pur_prd_subtype_code,
              pur_prd_subtype_name,
              pur_prd_mintype_code,
              pur_prd_mintype_name,
              pur_material_code,
              pur_material_name,
              unit,
              pur_number,
              pur_amount,
              remark,
              status,
              now(),
              col1,
              col2,
              col3,
              col4,
              col5
              FROM obp_pur_demand_details_rel 
              WHERE pur_rel_id = demandDetailsId
              AND id = demandDetailsRelId;
          
          END LOOP loop_c_demand_details_rel;
          CLOSE c_demand_details_rel;
      
      # 结束遍历 loop_c_demand_details
      END LOOP loop_c_demand_details;        
      CLOSE c_demand_details; #使用游标后关闭游标

    END WHILE ;
  END;

