create view obp_prdbigtype_base_info_pbt as select `a`.`id`                                              AS `id`,
                                                   `a`.`org_name`                                        AS `orgName`,
                                                   `a`.`supplier_id`                                     AS `supplierId`,
                                                   `a`.`supplier_code`                                   AS `supplierCode`,
                                                   `a`.`product_base_info_code`                          AS `productBaseInfoCode`,
                                                   `a`.`product_big_type_code`                           AS `productBigTypeCode`,
                                                   `a`.`product_big_type_name`                           AS `productBigType_name`,
                                                   `a`.`sales_performance_total`                         AS `salesPerformanceTotal`,
                                                   `a`.`added_value_tax_rate`                            AS `addedValueTaxRate`,
                                                   `a`.`create_time`                                     AS `createTime`,
                                                   `a`.`generic_brand`                                   AS `genericBrand`,
                                                   `a`.`status`                                          AS `status`,
                                                   `a`.`tax_name`                                        AS `taxName`,
                                                   `a`.`col1`                                            AS `modifySteps`,
                                                   `a`.`process_inst_id`                                 AS `processInstId`,
                                                   (select `p`.`party_id`
                                                    from `tower`.`obp_sys_partyauth` `p`
                                                    where ((`p`.`func_mod` = 'QUOTE') and (`p`.`party_type` = 'emp') and
                                                           (`p`.`operate_type` = 'Audit') and
                                                           (`p`.`prod_bcatg` = `a`.`product_big_type`))) AS `prdManager`,
                                                   '100001'                                              AS `provOrgCode`
                                            from `tower`.`obp_supplier_product_base_info` `a`
                                            union all select `b`.`id`                                              AS `id`,
                                                             `b`.`org_name`                                        AS `orgName`,
                                                             `b`.`supplier_id`                                     AS `supplierId`,
                                                             `b`.`supplier_code`                                   AS `supplierCode`,
                                                             `b`.`product_base_info_code`                          AS `productBaseInfoCode`,
                                                             `b`.`product_big_type_code`                           AS `productBigTypeCode`,
                                                             `b`.`product_big_type_name`                           AS `productBigType_name`,
                                                             `b`.`sales_performance_total`                         AS `salesPerformanceTotal`,
                                                             `b`.`added_value_tax_rate`                            AS `addedValueTaxRate`,
                                                             `b`.`create_time`                                     AS `createTime`,
                                                             `b`.`gm_brand`                                        AS `genericBrand`,
                                                             `b`.`status`                                          AS `status`,
                                                             `b`.`tax_name`                                        AS `taxName`,
                                                             `b`.`col1`                                            AS `modifySteps`,
                                                             `b`.`process_inst_id`                                 AS `processInstId`,
                                                             (select `p`.`party_id`
                                                              from `tower`.`obp_sys_partyauth` `p`
                                                              where ((`p`.`func_mod` = 'QUOTE') and
                                                                     (`p`.`party_type` = 'emp') and
                                                                     (`p`.`operate_type` = 'Audit') and
                                                                     (`p`.`prod_bcatg` = `b`.`product_big_type`))) AS `prdManager`,
                                                             '100001'                                              AS `provOrgCode`
                                                      from `tower`.`obp_tower_product_base_info` `b`
                                            union all select `c`.`id`                                              AS `id`,
                                                             `c`.`org_name`                                        AS `orgName`,
                                                             `c`.`supplier_id`                                     AS `supplierId`,
                                                             `c`.`supplier_code`                                   AS `supplierCode`,
                                                             `c`.`product_base_info_code`                          AS `productBaseInfoCode`,
                                                             `c`.`product_big_type_code`                           AS `productBigTypeCode`,
                                                             `c`.`product_big_type_name`                           AS `productBigType_name`,
                                                             `c`.`sales_performance_total`                         AS `salesPerformanceTotal`,
                                                             `c`.`added_value_tax_rate`                            AS `addedValueTaxRate`,
                                                             `c`.`create_time`                                     AS `createTime`,
                                                             `c`.`generic_brand`                                   AS `genericBrand`,
                                                             `c`.`base_info_status`                                AS `status`,
                                                             `c`.`tax_name`                                        AS `taxName`,
                                                             `c`.`col1`                                            AS `modifySteps`,
                                                             `c`.`process_inst_id`                                 AS `processInstId`,
                                                             (select `p`.`party_id`
                                                              from `tower`.`obp_sys_partyauth` `p`
                                                              where ((`p`.`func_mod` = 'QUOTE') and
                                                                     (`p`.`party_type` = 'emp') and
                                                                     (`p`.`operate_type` = 'Audit') and
                                                                     (`p`.`prod_bcatg` = `c`.`product_big_type`))) AS `prdManager`,
                                                             '100001'                                              AS `provOrgCode`
                                                      from `tower`.`obp_prd_base_info` `c`
                                                      where (not((`c`.`product_big_type` like '8%')))
                                            union all select `c`.`id`                                              AS `id`,
                                                             `c`.`org_name`                                        AS `orgName`,
                                                             `c`.`supplier_id`                                     AS `supplierId`,
                                                             `c`.`supplier_code`                                   AS `supplierCode`,
                                                             `c`.`product_base_info_code`                          AS `productBaseInfoCode`,
                                                             `c`.`product_big_type_code`                           AS `productBigTypeCode`,
                                                             `c`.`product_big_type_name`                           AS `productBigType_name`,
                                                             `c`.`sales_performance_total`                         AS `salesPerformanceTotal`,
                                                             `c`.`added_value_tax_rate`                            AS `addedValueTaxRate`,
                                                             `c`.`create_time`                                     AS `createTime`,
                                                             `c`.`generic_brand`                                   AS `genericBrand`,
                                                             '3'                                                   AS `status`,
                                                             `c`.`tax_name`                                        AS `taxName`,
                                                             `c`.`col1`                                            AS `modifySteps`,
                                                             `c`.`process_inst_id`                                 AS `processInstId`,
                                                             (select `p`.`party_id`
                                                              from `tower`.`obp_sys_partyauth` `p`
                                                              where ((`p`.`func_mod` = 'QUOTE') and
                                                                     (`p`.`party_type` = 'emp') and
                                                                     (`p`.`operate_type` = 'Audit') and
                                                                     (`p`.`prod_bcatg` = `c`.`product_big_type`))) AS `prdManager`,
                                                             `oa`.`p_orgcode`                                      AS `provOrgCode`
                                                      from `tower`.`obp_prd_base_info` `c`
                                                             join `tower`.`obp_prd_base_info_prov` `f`
                                                             join `tower`.`view_org_area` `oa`
                                                      where ((`c`.`product_big_type` like '8%') and
                                                             (`c`.`product_base_info_code` = `f`.`product_base_info_code`) and
                                                             (`oa`.`orgLevel` = '2') and
                                                             (`oa`.`p_area` = `f`.`province_code`));

