create view view_obp_product_fsds_offline_new_new as
  select uuid_short()                                                                                 AS `id`,
         `sb`.`supplier_code`                                                                         AS `supplier_code`,
         `t`.`code`                                                                                   AS `prod_type_code`,
         `s`.`code`                                                                                   AS `prod_sub_code`,
         `m`.`code`                                                                                   AS `prod_min_code`,
         `p`.`prod_min_type_code`                                                                     AS `prod_code`,
         `p`.`prod_min_type_name`                                                                     AS `prod_name`,
         `p`.`supplier_prod_code`                                                                     AS `supplier_prod_code`,
         `p`.`material_code`                                                                          AS `material_code`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and (`en`.`DICTID` = `p`.`metering_unit`))) AS `unit_name`,
         ''                                                                                           AS `brand_name`,
         `b`.`supply_time`                                                                            AS `stock_cycle`,
         `p`.`minimum_purchase`                                                                       AS `minbuy_num`,
         `p`.`minimum_package`                                                                        AS `pack_num`,
         ifnull(`p`.`weight`, 0)                                                                      AS `weight`,
         ifnull(`p`.`height`, 0)                                                                      AS `height`,
         `p`.`prod_desc`                                                                              AS `prod_desc`,
         `a`.`application_no`                                                                         AS `contract_code`,
         '2'                                                                                          AS `quote_type`,
         (case `r`.`quote_area`
            when 'PROV' then '2'
            when 'CITY' then '3' end)                                                                 AS `quote_level`,
         (case `r`.`quote_area`
            when 'PROV' then (select `o`.`ORGCODE`
                              from `tower`.`org_organization` `o`
                              where ((`o`.`AREA` = `q`.`area_code`) and (`o`.`ORGLEVEL` = '2') and
                                     (`auts`.`business_type` = `o`.`ENTERP_TYPE`)))
            when 'CITY'
                    then `q`.`area_code` end)                                                         AS `quote_org_code`,
         `q`.`product_price`                                                                          AS `product_price`,
         `p`.`prod_tax_rate`                                                                          AS `tax_rate`,
         (`q`.`includ_tax_price` - `q`.`product_price`)                                               AS `tax_price`,
         `q`.`includ_tax_price`                                                                       AS `includ_tax_price`,
         NULL                                                                                         AS `standard_price`,
         NULL                                                                                         AS `safety_fee`,
         NULL                                                                                         AS `discount`,
         '0'                                                                                          AS `debug_service_fee`,
         '0'                                                                                          AS `guide_service_fee`,
         (select if((`re`.`quote_id` <> ''), '1', '0')
          from `tower`.`obp_oth_quote_rule_rel` `re`
          where ((`re`.`scheme_id` = `r`.`scheme_id`) and (`re`.`quote_id` = `r`.`quote_id`) and
                 (`re`.`pkg_id` = 'C01')))                                                            AS `install_type`,
         (select if((`re`.`quote_id` <> ''), '3', '1')
          from `tower`.`obp_oth_quote_rule_rel` `re`
          where ((`re`.`scheme_id` = `r`.`scheme_id`) and (`re`.`quote_id` = `r`.`quote_id`) and
                 (`re`.`pkg_id` = 'B02')))                                                            AS `freight_type`,
         `auts`.`org_code`                                                                            AS `aut_org_code`,
         `auts`.`prov_org_code`                                                                       AS `aut_prov_org_code`,
         `auts`.`id`                                                                                  AS `aut_scheme_id`,
         `auts`.`scheme_type`                                                                         AS `aut_scheme_type`,
         now()                                                                                        AS `create_time`,
         `auts`.`business_type`                                                                       AS `business_type`
  from (((((((((`tower`.`obp_prod_aut_scheme` `auts`
      join `tower`.`obp_supplier_prod_base_info` `b`) join `tower`.`obp_supplier_prod_item` `p`) join `tower`.`obp_prd_min_type_new` `m`) join `tower`.`obp_prd_sub_type_new` `s`) join `tower`.`obp_prd_type_new` `t`) join `tower`.`obp_supplier_base_info` `sb`) join `tower`.`obp_supplier_access_agreement` `a`) join `tower`.`obp_oth_supplier_quote_use_prov` `q`) join `tower`.`obp_oth_quote_rule` `r`)
  where ((`auts`.`aut_type` = 'PRODUCT') and (`auts`.`org_code` <> '100001') and (`auts`.`id` = `b`.`scheme_id`) and
         (`b`.`process_inst_status` = 'A9') and (`b`.`scheme_id` = `p`.`scheme_id`) and
         (`b`.`supplier_id` = `p`.`supplier_id`) and (`b`.`base_code` = `p`.`base_code`) and
         (`p`.`process_inst_status` = 'A9') and (`p`.`prod_min_type_code` = `m`.`id`) and
         (`s`.`id` = `m`.`parent_code`) and (`t`.`id` = `s`.`parent_code`) and (`b`.`supplier_id` = `sb`.`id`) and
         (`b`.`supplier_id` = `a`.`supplier_id`) and (`b`.`scheme_id` = `a`.`scheme_id`) and (`a`.`state` = '1') and
         (`q`.`supplier_id` = `b`.`supplier_id`) and (`q`.`scheme_id` = `b`.`scheme_id`) and
         (`q`.`product_id` = `p`.`prod_min_type_code`) and (`q`.`status` = '1') and (`r`.`scheme_id` = `auts`.`id`));

