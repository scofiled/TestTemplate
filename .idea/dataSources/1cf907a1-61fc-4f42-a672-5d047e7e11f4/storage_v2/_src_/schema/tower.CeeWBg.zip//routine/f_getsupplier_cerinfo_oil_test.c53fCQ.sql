create function f_getsupplier_cerinfo_oil_test(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                               v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);

  set cer_info_html='';
set cer_info_temp='';


SELECT '<br>检测报告:' into cer_info_temp;
 set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';
select GROUP_CONCAT('<br>','检测报告编号：', a.test_report_code
,'检测产品型号：',a.test_version,'<br>'
,'检测机构：',a.test_org,'<br>'
,'检测报告出具时间：',test_date,'<br>') 
  into cer_info_temp
 from obp_supplier_test_info a where product_base_info_code= v_base_info_code  AND supplier_id=v_supplier_id ;
  set cer_info_html=CONCAT(cer_info_html,REPLACE(cer_info_temp,',',''),'<br>');
     set cer_info_temp='';  


  RETURN cer_info_html;
END;

