create procedure p_update_construct_prov(IN v_prov varchar(32), IN v_pra varchar(32), OUT flag varchar(32))
  BEGIN

update  view_obp_das_ratio_offline
a,view_obp_das_ratio b 
set b.discount=a.discount
where 
 a.prd_type_code like '8%'
and a.city_code=b.city_code
and a.prd_type_code=b.prd_type_code
and a.discount<>b.discount
;


INSERT into view_obp_das_ratio 
SELECT * from view_obp_das_ratio_offline  a where a.prd_type_code like '8%'
and not EXISTS (
SELECT 1 from view_obp_das_ratio  b
where a.prd_type_code=b.prd_type_code
and a.city_code=b.city_code
);
update obp_ch_city_task
a set a.task_state=500,a.selection_end_time=NOW()
where  a.prod_bcatg  = v_pra
and a.province_code = v_prov
and a.task_state='400';


update obp_citych_score_result
a set a.state=500,a.selection_end_time=NOW()
where  a.prod_bcatg = v_pra
and a.province_code =v_prov
and a.state='400';

DELETE a.* from obp_citych_score_result_online
a
where  a.prod_bcatg = v_pra
and a.province_code =v_prov;

DELETE a.* from view_obp_construct_discount
a where a.prov_code=v_prov and a.prd_type_code =v_pra;


DELETE a.* from view_obp_construct_stardardprice
a where a.prov_code= v_prov and a.prd_type_code =v_pra;


INSERT into view_obp_construct_discount
SELECT * from view_obp_construct_discount_offline a
where a.prov_code=v_prov and a.prd_type_code =v_pra;


INSERT into view_obp_construct_stardardprice
SELECT * from view_obp_construct_stardardprice_offline a
where a.prov_code=v_prov and a.prd_type_code =v_pra;


update obp_ch_city_task
a set a.task_state=400,a.selection_start_time=NOW()
where  a.prod_bcatg  = v_pra
and a.province_code = v_prov
and a.task_state='300';


update obp_citych_score_result
a set a.state=400,a.selection_start_time=NOW()
where  a.prod_bcatg = v_pra
and a.province_code =v_prov
and a.state='300';

INSERT into obp_citych_score_result_online
SELECT * from obp_citych_score_result
a where a.prod_bcatg=v_pra
and a.province_code =v_prov
and a.state='400';

DELETE a.* from view_obp_protypeprice a 
where a.province_code=v_prov
and a.protype_code=v_pra;

INSERT into view_obp_protypeprice
SELECT * from view_obp_construct_protypeprice_offline a
where a.province_code=v_prov
and a.protype_code=v_pra;

INSERT into obp_oth_construct_product_quote_h
SELECT a.*,NOW(),date_format(now(), '%Y%m') from obp_oth_construct_product_quote_use
a
where a.`status`='1'
and a.prodbcatg_id=v_pra
and a.prov_code=v_prov;

INSERT into obp_oth_construct_quote_h
SELECT a.*,NOW(),date_format(now(), '%Y%m') from obp_oth_construct_quote_use
a
where a.`status`='1'
and a.prodbcatg_id=v_pra
and a.prov_code=v_prov;

SET flag='999';
END;

