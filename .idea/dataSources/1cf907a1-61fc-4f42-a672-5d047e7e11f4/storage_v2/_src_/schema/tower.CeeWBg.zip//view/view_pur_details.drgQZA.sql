create view view_pur_details as
  select `d`.`id`                 AS `id`,
         `d`.`header_id`          AS `head_id`,
         `d`.`sys_code`           AS `sys_code`,
         `d`.`purchase_list_code` AS `purchase_list_code`,
         `d`.`purchase_type`      AS `purchase_type`,
         `d`.`category_code`      AS `category_code`,
         `d`.`category_name`      AS `category_name`,
         `d`.`mode`               AS `mode`,
         `d`.`amount`             AS `amount`,
         `d`.`unit`               AS `unit`,
         `d`.`unit_count`         AS `unit_count`,
         `d`.`status`             AS `status`,
         `d`.`remark`             AS `remark`,
         `d`.`rcvtime`            AS `rcvtime`,
         `d`.`budget_amount`      AS `budget_amount`,
         `d`.`currency_unit`      AS `currency_unit`,
         `d`.`col1`               AS `col1`,
         `d`.`col2`               AS `col2`,
         `d`.`col3`               AS `col3`,
         `d`.`col4`               AS `col4`,
         `d`.`col5`               AS `col5`
  from `tower`.`obp_pur_details` `d`;

