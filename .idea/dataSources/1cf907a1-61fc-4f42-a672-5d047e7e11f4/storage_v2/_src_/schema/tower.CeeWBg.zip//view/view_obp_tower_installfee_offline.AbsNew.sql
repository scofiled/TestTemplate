create view view_obp_tower_installfee_offline as select `c`.`code`            AS `province_code`,
                                                        `d`.`product_id`      AS `protype_code`,
                                                        `d`.`scheme_id`       AS `scheme_id`,
                                                        `b`.`supplier_code`   AS `supplier_code`,
                                                        `a`.`fee_rate`        AS `Install_fee_rate`,
                                                        `a`.`fee`             AS `install_fee`,
                                                        `h`.`standard_height` AS `standard_height`
                                                 from ((((`tower`.`obp_oth_ba_exchange_price` `a`
                                                     join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_parity_model` `d`) left join `tower`.`obp_tower_prov_standard_height` `h` on ((
                                                   (`h`.`scheme_id` = `d`.`scheme_id`) and
                                                   (`c`.`code` = `h`.`province_code`))))
                                                 where ((`a`.`supplier_id` = `b`.`id`) and
                                                        (`a`.`scheme_id` = `d`.`scheme_id`) and
                                                        (`a`.`province_code` = `c`.`code`))
                                                 union all select `a`.`province_id`                     AS `province_code`,
                                                                  `d`.`prodbcatg_id`                    AS `protype_code`,
                                                                  `d`.`scheme_id`                       AS `scheme_id`,
                                                                  `b`.`supplier_code`                   AS `supplier_code`,
                                                                  format((`a`.`install_rate` / 100), 4) AS `Install_fee_rate`,
                                                                  `a`.`install_fee`                     AS `install_fee`,
                                                                  NULL                                  AS `standard_height`
                                                           from (((`tower`.`obp_tower_install_quote` `a`
                                                               join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_oth_quote_rule` `d`)
                                                           where ((`a`.`province_id` = `c`.`code`) and
                                                                  (`a`.`supplier_id` = `b`.`id`) and
                                                                  (`a`.`quote_id` = `d`.`quote_id`));

