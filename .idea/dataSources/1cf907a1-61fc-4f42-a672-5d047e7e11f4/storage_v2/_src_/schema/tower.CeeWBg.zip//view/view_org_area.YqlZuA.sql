create view view_org_area as select `o`.`ORGCODE`     AS `c_orgcode`,
                                    `o`.`ORGCODE`     AS `p_orgcode`,
                                    `o`.`ORGNAME`     AS `p_orgname`,
                                    `o`.`ORGNAME`     AS `c_orgname`,
                                    `o`.`AREA`        AS `c_area`,
                                    '总部'              AS `c_areaName`,
                                    `o`.`AREA`        AS `p_area`,
                                    `o`.`ORGNAME`     AS `p_areaName`,
                                    `o`.`ORGID`       AS `c_orgId`,
                                    `o`.`PARENTORGID` AS `p_orgId`,
                                    `o`.`ORGLEVEL`    AS `orgLevel`,
                                    `o`.`ENTERP_TYPE` AS `enterpType`
                             from `tower`.`org_organization` `o`
                             where (`o`.`ORGLEVEL` = 1)
                             union all select `o`.`ORGCODE`     AS `c_orgcode`,
                                              `o`.`ORGCODE`     AS `p_orgcode`,
                                              `o`.`ORGNAME`     AS `p_orgname`,
                                              `o`.`ORGNAME`     AS `c_orgname`,
                                              `o`.`AREA`        AS `c_area`,
                                              `p`.`name`        AS `c_areaName`,
                                              `o`.`AREA`        AS `p_area`,
                                              `p`.`name`        AS `p_areaName`,
                                              `o`.`ORGID`       AS `c_orgId`,
                                              `o`.`PARENTORGID` AS `p_orgId`,
                                              `o`.`ORGLEVEL`    AS `orgLevel`,
                                              `o`.`ENTERP_TYPE` AS `enterpType`
                                       from (`tower`.`org_organization` `o` left join `tower`.`obp_province` `p` on ((
                                         `o`.`AREA` = `p`.`code`)))
                                       where (`o`.`ORGLEVEL` = '2')
                             union all select `o`.`ORGCODE`     AS `c_orgcode`,
                                              `po`.`ORGCODE`    AS `p_orgcode`,
                                              `po`.`ORGNAME`    AS `p_orgname`,
                                              `o`.`ORGNAME`     AS `c_orgname`,
                                              `o`.`AREA`        AS `c_area`,
                                              `c`.`name`        AS `c_areaName`,
                                              `po`.`AREA`       AS `p_area`,
                                              `p`.`name`        AS `p_areaName`,
                                              `o`.`ORGID`       AS `c_orgId`,
                                              `o`.`PARENTORGID` AS `p_orgId`,
                                              `o`.`ORGLEVEL`    AS `orgLevel`,
                                              `o`.`ENTERP_TYPE` AS `enterpType`
                                       from (((`tower`.`org_organization` `o`
                                           join `tower`.`org_organization` `po`) join `tower`.`obp_province` `p`) join `tower`.`obp_city` `c`)
                                       where ((`o`.`ORGLEVEL` = '3') and (`o`.`PARENTORGID` = `po`.`ORGID`) and
                                              (`po`.`AREA` = `p`.`code`) and (`o`.`AREA` = `c`.`code`));

