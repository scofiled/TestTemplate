create view view_obp_cabinet_fee_offline as
  select `a`.`province`                                  AS `province_code`,
         `d`.`product_id`                                AS `protype_code`,
         `b`.`supplier_code`                             AS `supplier_code`,
         format((`a`.`insurance_price_tax_lv` / 100), 4) AS `freight_fee_rate`
  from (((`tower`.`obp_insurance_price` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_parity_model` `d`)
  where ((`a`.`province` = `c`.`code`) and (`a`.`supplier_id` = `b`.`id`) and (`a`.`cabinet_id` = `d`.`id`));

