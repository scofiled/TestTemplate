create view view_obp_construct_stardardprice_offline as
  select `a`.`prov_code`                           AS `prov_code`,
         `a`.`prd_type_code`                       AS `prd_type_code`,
         `a`.`prd_min_code`                        AS `prd_min_code`,
         (`a`.`standard_price` + `a`.`safety_fee`) AS `standard_price`,
         `a`.`content`                             AS `content`,
         `a`.`safety_fee`                          AS `safety_fee`
  from `tower`.`view_obp_construct_stardardprice_offline_2` `a`
  where (1 = 1);

