create view view_obp_transportfee_sp_offline as select `b`.`supplier_code` AS `supplier_code`,
                                                       `a`.`from_addr`     AS `from_addr`,
                                                       `a`.`to_addr`       AS `to_addr`,
                                                       `a`.`transport_fee` AS `transport_fee`,
                                                       `a`.`mileage`       AS `mileage`,
                                                       `f`.`product_id`    AS `protype_code`,
                                                       `d`.`id`            AS `scheme_id`
                                                from (((`tower`.`obp_trans_dispri` `a`
                                                    join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_prod_spaut_scheme` `d`) join `tower`.`obp_parity_model` `f`)
                                                where ((`a`.`quote_id` = `f`.`id`) and
                                                       (`a`.`supplier_id` = `b`.`id`) and
                                                       (`d`.`aut_scheme_id` = `f`.`scheme_id`) and
                                                       (`a`.`to_addr` not in ('110000', '120000', '310000', '500000')))
                                                union select `b`.`supplier_code` AS `supplier_code`,
                                                             `a`.`from_addr`     AS `from_addr`,
                                                             `d`.`code`          AS `to_addr`,
                                                             `a`.`transport_fee` AS `transport_fee`,
                                                             `a`.`mileage`       AS `mileage`,
                                                             `f`.`product_id`    AS `protype_code`,
                                                             `sp`.`id`           AS `scheme_id`
                                                      from ((((`tower`.`obp_trans_dispri` `a`
                                                          join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_city` `d`) join `tower`.`obp_prod_spaut_scheme` `sp`) join `tower`.`obp_parity_model` `f`)
                                                      where ((`a`.`quote_id` = `f`.`id`) and
                                                             (`a`.`supplier_id` = `b`.`id`) and
                                                             (`a`.`to_addr` = `d`.`p_code`) and
                                                             (`sp`.`aut_scheme_id` = `f`.`scheme_id`) and
                                                             (`a`.`to_addr` in ('110000',
                                                                                '120000',
                                                                                '310000',
                                                                                '500000')));

