create function curProcOrderStatus(statusStr varchar(256))
  returns varchar(32)
  BEGIN
DECLARE v_value VARCHAR(8);

IF find_in_set('1',statusStr)>0 THEN
	SET v_value = '部分确认';
ELSEIF find_in_set('0',statusStr) > 0 AND find_in_set('2',statusStr)=0 AND find_in_set('3',statusStr)=0 THEN
	SET v_value = '未确认';
ELSEIF (find_in_set('2',statusStr) > 0 OR find_in_set('3',statusStr) > 0) AND find_in_set('0',statusStr) = 0 AND find_in_set('1',statusStr) = 0 THEN
	SET v_value = '全部确认';
ELSE 
	SET v_value = '部分确认';
END IF;
RETURN v_value;   
END;

