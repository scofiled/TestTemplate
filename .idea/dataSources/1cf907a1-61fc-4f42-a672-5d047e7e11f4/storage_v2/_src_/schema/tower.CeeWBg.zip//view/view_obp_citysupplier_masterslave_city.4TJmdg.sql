create view view_obp_citysupplier_masterslave_city as select distinct `a`.`master_supplier_code` AS `master_supplier_code`,
                                                                      `a`.`master_supplier_name` AS `master_supplier_name`,
                                                                      `a`.`protype_code`         AS `protype_code`,
                                                                      `a`.`province_code`        AS `province_code`,
                                                                      `a`.`slave_supplier_code`  AS `slave_supplier_code`,
                                                                      `a`.`slave_supplier_name`  AS `slave_supplier_name`,
                                                                      `a`.`type`                 AS `type`
                                                      from `tower`.`view_obp_citysupplier_masterslave_sup` `a`
                                                      union select distinct `b`.`master_supplier_code` AS `master_supplier_code`,
                                                                            `b`.`master_supplier_name` AS `master_supplier_name`,
                                                                            `b`.`protype_code`         AS `protype_code`,
                                                                            `b`.`province_code`        AS `province_code`,
                                                                            `b`.`slave_supplier_code`  AS `slave_supplier_code`,
                                                                            `b`.`slave_supplier_name`  AS `slave_supplier_name`,
                                                                            `b`.`type`                 AS `type`
                                                            from `tower`.`view_obp_citysupplier_masterslave_second` `b`;

