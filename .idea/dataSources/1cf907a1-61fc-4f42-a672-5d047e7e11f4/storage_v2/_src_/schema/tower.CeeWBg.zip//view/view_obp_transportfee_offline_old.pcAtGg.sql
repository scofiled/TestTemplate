create view view_obp_transportfee_offline_old as
  select `view_obp_transportfee_offline`.`supplier_code` AS `supplier_code`,
         `view_obp_transportfee_offline`.`from_addr`     AS `from_addr`,
         `view_obp_transportfee_offline`.`to_addr`       AS `to_addr`,
         `view_obp_transportfee_offline`.`transport_fee` AS `transport_fee`,
         `view_obp_transportfee_offline`.`mileage`       AS `mileage`,
         `view_obp_transportfee_offline`.`protype_code`  AS `protype_code`
  from `tower`.`view_obp_transportfee_offline`;

