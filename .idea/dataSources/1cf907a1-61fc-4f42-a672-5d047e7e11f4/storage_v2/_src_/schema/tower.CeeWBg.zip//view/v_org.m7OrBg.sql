create view v_org as
  select `o`.`ORGID` AS `ORG_ID`, `o`.`ORGNAME` AS `ORG_NAME`, `o`.`PARENTORGID` AS `PARENT_ID`
  from `tower`.`org_organization` `o`
  where (isnull(`o`.`STATUS`) or (`o`.`STATUS` = 'running'));

