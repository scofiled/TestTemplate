create procedure p_cal_chindex_linear(IN taskId varchar(32), IN ruleId varchar(32), OUT flag int)
  BEGIN

DECLARE avg_value DECIMAL(5,2) DEFAULT 0.00;

DECLARE max_value  DECIMAL(5,2) DEFAULT 0.00;

DECLARE min_value  DECIMAL(5,2) DEFAULT 0.00;

DECLARE default_value  DECIMAL(5,2) DEFAULT 0.00;

DECLARE avg_score  DECIMAL(5,2) DEFAULT 0.00;
DECLARE min_score  DECIMAL(5,2) DEFAULT 0.00;
DECLARE default_score  DECIMAL(5,2) DEFAULT 0.00;
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
 set flag=888;
END;
SELECT AVG(a.index_value),MAX(a.index_value),MIN(a.index_value)
into avg_value,max_value,min_value
 from obp_ch_task_index_detail
a where a.is_no_value='0'
and a.task_id=taskId and a.rule_id=ruleId;
SELECT avg_value;
START TRANSACTION;
IF(avg_value is NULL)THEN
update obp_ch_task_index_detail a
set a.score=75 where a.task_id=taskId and a.rule_id=ruleId;
ELSEIF (position(ruleId in '999996/999993/999992/999990/999984')>0)
THEN
update obp_ch_task_index_detail a
set a.score=ROUND((index_value)*100,2) where a.task_id=taskId and a.rule_id=ruleId
and a.is_no_value='0';

ELSEIF (position(ruleId in '999994/999995')>0)
then 
update obp_ch_task_index_detail a
set a.score=ROUND((1-(max_value-a.index_value)/max_value)*100,2) where a.task_id=taskId and a.rule_id=ruleId
and a.is_no_value='0';
ELSEIF (position(ruleId in '999989/999991')>0)
THEN
update obp_ch_task_index_detail a
set a.score=ROUND((1-a.index_value)*100,2) where a.task_id=taskId and a.rule_id=ruleId
and a.is_no_value='0';
ELSEIF (position(ruleId in '999988/999987/999986')>0)THEN
update obp_ch_task_index_detail a
set a.score=if(a.index_value>=100,0,100-a.index_value) where a.task_id=taskId and a.rule_id=ruleId
and a.is_no_value='0';
ELSE 
SELECT 2;
END if;
COMMIT;
SELECT AVG(a.score),min(score)
into avg_score,min_score
 from obp_ch_task_index_detail
a where a.is_no_value='0'
and a.task_id=taskId and a.rule_id=ruleId;
IF(avg_value is not NULL) then
IF(avg_score*0.9>=min_score)THEN
set default_score=avg_score*0.9;
ELSE
set default_score=min_score;
END IF;
SELECT CONCAT('default_value=----------',default_score,'------',min_score,'----',avg_score*0.9);
update obp_ch_task_index_detail a
set a.score=default_score where a.task_id=taskId and a.rule_id=ruleId
and a.is_no_value='1';
END if;

SET flag=999;

END;

