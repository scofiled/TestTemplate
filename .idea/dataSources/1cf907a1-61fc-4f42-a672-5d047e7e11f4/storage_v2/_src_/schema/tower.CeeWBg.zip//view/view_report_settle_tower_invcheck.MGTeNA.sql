create view view_report_settle_tower_invcheck as
  select `s`.`prdcodes`                         AS `prdcodes`,
         `s`.`prdnames`                         AS `prdnames`,
         `s`.`OrgCode`                          AS `orgcodes`,
         sum(`s`.`TaxAmount`)                   AS `amount`,
         date_format(`s`.`create_time`, '%Y%m') AS `months`
  from `tower`.`obp_settlement` `s`
  where ((`s`.`prdcodes` <> '1') and (`s`.`prdcodes` <> '2') and (`s`.`status` <> '4') and (`s`.`status` <> '5') and
         (`s`.`status` <> '6') and (`s`.`status` <> '7') and (`s`.`status` <> '8') and (`s`.`status` <> '10') and
         (`s`.`status` <> '23'))
  group by `s`.`prdcodes`, `s`.`OrgCode`, date_format(`s`.`create_time`, '%Y%m');

