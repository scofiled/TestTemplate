create view view_obp_citych_rpt_taskscoreinfo as
  select `a`.`task_id`            AS `task_id`,
         max(`b`.`total_score`)   AS `max_total_score`,
         max(`b`.`total_sort`)    AS `max_total_sort`,
         min(`b`.`total_score`)   AS `min_total_score`,
         min(`b`.`total_sort`)    AS `min_total_sort`,
         max(`b`.`price_score`)   AS `max_price_score`,
         min(`b`.`price_score`)   AS `min_price_score`,
         max(`b`.`qua_score`)     AS `max_qua_score`,
         min(`b`.`qua_score`)     AS `min_qua_score`,
         max(`b`.`service_score`) AS `max_service_score`,
         min(`b`.`service_score`) AS `min_service_score`,
         avg(`b`.`total_score`)   AS `avg_total_score`,
         avg(`b`.`price_score`)   AS `avg_price_score`,
         avg(`b`.`service_score`) AS `avg_service_score`,
         avg(`b`.`qua_score`)     AS `avg_qua_score`
  from (`tower`.`obp_ch_city_task` `a`
      join `tower`.`obp_citych_access_record` `b`)
  where (`a`.`task_id` = `b`.`task_id`)
  group by `a`.`task_id`;

