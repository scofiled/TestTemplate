create view view_obp_tower_installfee_sp_offline as
  select `a`.`province_id`                     AS `province_code`,
         `d`.`product_id`                      AS `protype_code`,
         `e`.`id`                              AS `scheme_id`,
         `b`.`supplier_code`                   AS `supplier_code`,
         format((`a`.`install_rate` / 100), 4) AS `Install_fee_rate`
  from ((((`tower`.`obp_tower_install_quote` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_prod_spaut_scheme` `e`) join `tower`.`obp_parity_model` `d`)
  where ((`a`.`province_id` = `c`.`code`) and (`a`.`supplier_id` = `b`.`id`) and (`a`.`quote_id` = `d`.`id`) and
         (`e`.`aut_scheme_id` = `d`.`scheme_id`));

