create view view_obp_supplier_all as select `a`.`protype_code`  AS `protype_code`,
                                            `a`.`province_code` AS `province_code`,
                                            `a`.`supplier_code` AS `supplier_code`,
                                            `a`.`city_code`     AS `city_code`
                                     from `tower`.`view_obp_protypeprice` `a`
                                     union all select `a`.`protype_code`  AS `protype_code`,
                                                      `a`.`prov_code`     AS `province_code`,
                                                      `a`.`supplier_code` AS `supplier_code`,
                                                      ''                  AS `city_code`
                                               from `tower`.`view_obp_provsupplier` `a`;

