create function nextval(orgSeq varchar(50))
  returns int
  begin  
    update seqMysql set current_val = current_val + increment_val  where seq_name = 'orgSeq';  
    return currval(orgSeq);  
end;

