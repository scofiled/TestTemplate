create function get_quote_model_weight(v_product_big_type varchar(64), v_quote_type varchar(10))
  returns decimal(8, 4)
  BEGIN

  DECLARE weight DECIMAL(8,4) ;

  set weight=0.0;

  IF(v_quote_type='discount' )then 
  
select b.prod_weight/100 into weight from obp_oth_quote_model b where b.prodbcatg_id=v_product_big_type
  and b.product_id='4910111';
  ELSEIF (v_quote_type='survey')THEN

   select b.prod_weight/100 into weight from obp_oth_quote_model b where b.prodbcatg_id=v_product_big_type
  and b.product_id='4910112';

  ELSE
 set weight=1.0;
  END if;

  RETURN weight;
END;

