create view view_obp_product_images_offline as select `p`.`material_code`                            AS `material_code`,
                                                      concat(replace(`f`.`file_abs_route`, '/mnt/nfs/',
                                                                     'http://192.168.2.247:10000/')) AS `path`,
                                                      ''                                             AS `sort`,
                                                      ''                                             AS `isPrimary`
                                               from (((`tower`.`obp_supplier_product_info` `p`
                                                   join `tower`.`obp_file` `f`) join `tower`.`obp_file_rel` `r`) join `tower`.`obp_supplier_product_base_info` `q`)
                                               where ((`p`.`id` = `r`.`rel_id`) and (`r`.`id` = `f`.`id`) and
                                                      (`p`.`product_base_info_code` = `q`.`product_base_info_code`) and
                                                      (`q`.`status` = '3') and (`p`.`status` = '1') and exists(select 1
                                                                                                               from `tower`.`obp_supplier_access_agreement` `ac`
                                                                                                               where ((`p`.`supplier_id` = `ac`.`supplier_id`) and
                                                                                                                      (`p`.`product_big_type` = `ac`.`prod_bctg`) and
                                                                                                                      (`ac`.`state` = '1'))))
                                               union select `a`.`material_code`                            AS `material_code`,
                                                            concat(replace(`b`.`file_abs_route`, '/mnt/nfs/',
                                                                           'http://192.168.2.247:10000/')) AS `path`,
                                                            ''                                             AS `sort`,
                                                            ''                                             AS `isPrimary`
                                                     from (((`tower`.`obp_tower_product_info` `a`
                                                         join `tower`.`obp_file` `b`) join `tower`.`obp_file_rel` `c`) join `tower`.`obp_tower_product_base_info` `d`)
                                                     where ((`a`.`id` = `c`.`rel_id`) and (`b`.`id` = `c`.`id`) and
                                                            (`a`.`product_base_info_code` = `d`.`product_base_info_code`) and
                                                            (`d`.`status` = '3') and exists(select 1
                                                                                            from `tower`.`obp_supplier_access_agreement` `ac`
                                                                                            where ((`a`.`supplier_id` = `ac`.`supplier_id`) and
                                                                                                   (`a`.`product_big_type` = `ac`.`prod_bctg`) and
                                                                                                   (`ac`.`state` = '1'))))
                                               order by `material_code`;

