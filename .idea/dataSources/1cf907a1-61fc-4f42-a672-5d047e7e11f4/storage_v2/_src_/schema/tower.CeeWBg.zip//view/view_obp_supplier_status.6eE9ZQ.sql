create view view_obp_supplier_status as
  select `b`.`supplier_code` AS `supplier_code`,
         `b`.`org_code`      AS `org_code`,
         `b`.`org_name`      AS `org_name`,
         `b`.`status`        AS `status`
  from `tower`.`obp_supplier_base_info` `b`
  where (`b`.`LEVEL` <> '2');

