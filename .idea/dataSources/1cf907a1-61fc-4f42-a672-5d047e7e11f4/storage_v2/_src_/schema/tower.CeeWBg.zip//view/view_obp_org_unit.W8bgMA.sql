create view view_obp_org_unit as select `a`.`ORGCODE` AS `code`, '总部' AS `name`
                                 from `tower`.`org_organization` `a`
                                 where (`a`.`ORGLEVEL` = 1)
                                 union all select `b`.`ORGCODE` AS `code`, `d`.`name` AS `name`
                                           from (`tower`.`org_organization` `b`
                                               join `tower`.`obp_province` `d`)
                                           where ((`b`.`ORGLEVEL` = 2) and (`b`.`AREA` = `d`.`code`))
                                 union all select `c`.`orgcode` AS `code`, `c`.`orgname` AS `name`
                                           from `tower`.`obp_city_org` `c`;

