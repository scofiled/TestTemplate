create view view_obp_citych_rpt_taskinfo as
  select `a`.`prod_bcatg`                                                              AS `prod_bcatg`,
         `c`.`name`                                                                    AS `prod_bname`,
         `a`.`province_code`                                                           AS `province_code`,
         `d`.`name`                                                                    AS `prov_name`,
         `a`.`city_code`                                                               AS `city_code`,
         `a`.`city_name`                                                               AS `city_name`,
         `a`.`city_batch`                                                              AS `city_batch`,
         if((count(distinct `b`.`area_code`) < 1), 1, count(distinct `b`.`area_code`)) AS `area_cnt`,
         `a`.`selection_start_time`                                                    AS `selection_start_time`,
         `a`.`selection_end_time`                                                      AS `selection_end_time`,
         `a`.`task_id`                                                                 AS `task_id`,
         `a`.`prov_task_id`                                                            AS `prov_task_id`,
         `a`.`task_type`                                                               AS `task_type`
  from (((`tower`.`obp_ch_city_task` `a`
      join `tower`.`obp_citych_score_result` `b`) join `tower`.`obp_prd_type` `c`) join `tower`.`obp_province` `d`)
  where ((`a`.`task_id` = `b`.`task_id`) and (`a`.`prod_bcatg` = `c`.`id`) and (`a`.`province_code` = `d`.`code`) and
         (`a`.`task_state` in ('400', '500')))
  group by `a`.`task_id`;

