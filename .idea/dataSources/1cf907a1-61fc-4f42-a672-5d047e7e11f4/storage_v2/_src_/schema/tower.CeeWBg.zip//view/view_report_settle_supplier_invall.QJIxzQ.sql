create view view_report_settle_supplier_invall as
  select `s`.`prdcodes`                         AS `prdcodes`,
         `s`.`prdnames`                         AS `prdnames`,
         `s`.`SupplyCode`                       AS `SupplyCode`,
         `s`.`SupplyName`                       AS `SupplyName`,
         sum(`s`.`TaxAmount`)                   AS `amount`,
         date_format(`s`.`create_time`, '%Y%m') AS `months`
  from `tower`.`obp_settlement` `s`
  where ((`s`.`prdcodes` <> '1') and (`s`.`prdcodes` <> '2') and (`s`.`status` <> '4') and (`s`.`status` <> '5') and
         (`s`.`status` <> '6'))
  group by `s`.`prdcodes`, `s`.`SupplyCode`, date_format(`s`.`create_time`, '%Y%m');

