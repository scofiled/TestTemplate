create function json_extract(details text, required_field varchar(255))
  returns text
  BEGIN	
	SET details = SUBSTRING_INDEX( details, "{", - 1 );
	SET details = SUBSTRING_INDEX( details, "}", 1 );
	RETURN TRIM(
		BOTH '"' 
		FROM
			SUBSTRING_INDEX(
				SUBSTRING_INDEX(
					SUBSTRING_INDEX(
						CONCAT( '"":"",', details ),
						CONCAT( '"', SUBSTRING_INDEX( required_field, '$.', - 1 ), '":' ),
						- 1 
					),
					',"',
					1 
				),
				':',
				- 1 
			) 
		);
END;

