create view view_obp_citysupplier_offline as
  select if(isnull(`f`.`product_id`), '99', substr(`f`.`product_id`, 1, 2)) AS `prd_type`,
         `p`.`prov_code`                                                    AS `prov_code`,
         `p`.`city_code`                                                    AS `city_code`,
         `p`.`supplier_code`                                                AS `supplier_code`,
         `p`.`supplier_name`                                                AS `supplier_name`,
         `p`.`contract_code`                                                AS `contract_code`,
         `p`.`contract_name`                                                AS `contract_name`,
         `p`.`material_code`                                                AS `material_code`,
         `p`.`material_name`                                                AS `material_name`,
         `p`.`amount`                                                       AS `price`,
         `p`.`tax_rate`                                                     AS `tax_rate`,
         `p`.`tax`                                                          AS `tax`,
         `p`.`tax_amount`                                                   AS `tax_amount`,
         `r`.`ORGCODE`                                                      AS `org_code`
  from (((`tower`.`obp_pur_product_info_offline` `p`
      join `tower`.`obp_pur_supplier_base_info_offline` `b`) join `tower`.`obp_org_area_rel` `r`) left join `tower`.`obp_prd_material_rel` `f` on ((
    (`p`.`material_code` = `f`.`material_code`) and (`f`.`sys_code` = ''))))
  where ((`p`.`status` = '1') and (`b`.`MDMWLDW_TYBZ` = '0') and (`p`.`supplier_code` = `b`.`MDMWLDW_WLDWBH`) and
         (`p`.`city_code` = `r`.`AREACODE`));

