create view view_obp_city_choose_type_new as
  select distinct `a`.`province_code`                                                 AS `province_code`,
                  `a`.`city_code`                                                     AS `city_code`,
                  `a`.`scheme_id`                                                     AS `scheme_id`,
                  if((isnull(`a`.`country_code`) or (`a`.`country_code` = '')), 2, 1) AS `flag`
  from `tower`.`view_obp_auto_provider_new` `a`;

