create view view_obp_virtual_all as select `m`.`id`            AS `id`,
                                           `m`.`supplier_code` AS `supplier_code`,
                                           `m`.`org_code`      AS `org_code`,
                                           `m`.`org_name`      AS `org_name`,
                                           `m`.`taxes_num`     AS `taxes_num`,
                                           `m`.`LEVEL`         AS `level`,
                                           `m`.`status`        AS `status`
                                    from `tower`.`obp_supplier_base_info` `m`
                                    union all select `n`.`id`            AS `id`,
                                                     `n`.`supplier_code` AS `supplier_code`,
                                                     `n`.`org_code`      AS `org_code`,
                                                     `n`.`org_name`      AS `org_name`,
                                                     ''                  AS `taxes_num`,
                                                     '1'                 AS `level`,
                                                     `n`.`status`        AS `status`
                                              from `tower`.`obp_virtual_supplier_base_info` `n`;

