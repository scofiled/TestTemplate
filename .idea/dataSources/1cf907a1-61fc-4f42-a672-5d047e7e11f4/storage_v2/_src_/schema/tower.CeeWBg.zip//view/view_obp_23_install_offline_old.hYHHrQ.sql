create view view_obp_23_install_offline_old as
  select `view_obp_23_install_offline`.`province_code`    AS `province_code`,
         `view_obp_23_install_offline`.`protype_code`     AS `protype_code`,
         `view_obp_23_install_offline`.`supplier_code`    AS `supplier_code`,
         `view_obp_23_install_offline`.`Install_fee_rate` AS `Install_fee_rate`,
         `view_obp_23_install_offline`.`Install_min_fee`  AS `Install_min_fee`
  from `tower`.`view_obp_23_install_offline`;

