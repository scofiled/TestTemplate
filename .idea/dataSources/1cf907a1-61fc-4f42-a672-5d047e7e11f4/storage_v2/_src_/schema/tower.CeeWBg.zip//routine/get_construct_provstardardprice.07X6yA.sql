create function get_construct_provstardardprice(v_prov_code varchar(64), v_stardardprice decimal(16, 2),
                                                v_safetyfee decimal(16, 2))
  returns decimal(16, 2)
  BEGIN

DECLARE stardardprice DECIMAL (16, 2);


set stardardprice = v_stardardprice ;

RETURN stardardprice;


END;

