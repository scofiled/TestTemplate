create view obp_cer_all_rules_view as
  select `a`.`prod_bcatg`       AS `prod_bcatg`,
         `c`.`id`               AS `id`,
         `a`.`root_catg_id`     AS `root_catg_id`,
         `a`.`root_catg_name`   AS `root_catg_name`,
         `b`.`catg_id`          AS `catg_id`,
         `b`.`catg_name`        AS `catg_name`,
         `c`.`rule_id`          AS `rule_id`,
         `c`.`rule_name`        AS `rule_name`,
         `c`.`is_use`           AS `is_use`,
         `c`.`value_type`       AS `value_type`,
         `c`.`is_display`       AS `is_display`,
         `c`.`is_upload`        AS `is_upload`,
         `c`.`is_form`          AS `is_form`,
         `c`.`relate_form`      AS `relate_form`,
         `c`.`upload_name`      AS `upload_name`,
         `c`.`rule_score_range` AS `rule_score_range`,
         `c`.`is_must`          AS `is_must`
  from ((`tower`.`obp_cer_rule_rootcatg` `a`
      join `tower`.`obp_cer_rule_catg` `b`) join `tower`.`obp_cer_rule` `c`)
  where ((`a`.`root_catg_id` = `b`.`root_catg_id`) and (`b`.`catg_id` = `c`.`catg_id`));

