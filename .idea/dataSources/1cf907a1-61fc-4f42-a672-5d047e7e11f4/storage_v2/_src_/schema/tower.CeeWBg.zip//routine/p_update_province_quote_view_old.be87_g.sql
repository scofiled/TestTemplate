create procedure p_update_province_quote_view_old(IN prodBcatg varchar(5), IN plan_code varchar(50), OUT flag int)
  BEGIN
START TRANSACTION;

DELETE a.* from obp_oth_supplier_quote_use_prov a where a.quote_id=plan_code
and a.prodbcatg_id=prodBcatg;

INSERT into obp_oth_supplier_quote_use_prov
SELECT * from obp_oth_supplier_quote_prov a where a.quote_id=plan_code
and a.prodbcatg_id=prodBcatg;

DELETE a.* from obp_product_score_result a where a.quote_id=plan_code
and a.product_btype=prodBcatg;
INSERT into obp_product_score_result(	supplier_id,
	product_btype,
	province_code,
	product_total_price,
	best_price,
	product_score,
	product_level,
	create_time,
	col1,
	col2,
	col3,
	col4,
	city_code,
        quote_id)
SELECT 	supplier_id,
	product_btype,
	province_code,
	product_total_price,
	best_price,
	product_score,
	product_level,
	create_time,
	col1,
	col2,
	col3,
	col4,
	city_code,
        quote_id from obp_product_score_result_temp a where a.quote_id=plan_code
and a.product_btype=prodBcatg;


COMMIT;
set flag=1;

END;

