create view view_obp_prd_offline as
  select `b`.`supplier_id` AS `supplier_id`, `b`.`scheme_id` AS `scheme_id`, `b`.`base_code` AS `base_code`
  from `tower`.`obp_supplier_prod_base_info` `b`
  where (`b`.`process_inst_status` = 'A9');

