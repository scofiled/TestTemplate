create view view_obp_prd_assession as
  select `a`.`product_big_type` AS `protype_code`, `a`.`supplier_code` AS `supplier_code`, `a`.`col1` AS `assession`
  from `tower`.`obp_prd_base_info` `a`
  where (`a`.`product_big_type` = 54);

