create view view_obp_supplier_quote_product_id as
  select distinct `a`.`supplier_id`  AS `supplier_id`,
                  `a`.`prodbcatg_id` AS `prodbcatg_id`,
                  `a`.`product_id`   AS `product_id`
  from `tower`.`obp_oth_supplier_quote_prov` `a`
  where (`a`.`status` = '1');

