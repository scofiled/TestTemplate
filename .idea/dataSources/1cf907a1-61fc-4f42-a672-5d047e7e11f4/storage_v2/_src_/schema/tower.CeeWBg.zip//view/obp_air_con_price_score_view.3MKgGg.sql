create view obp_air_con_price_score_view as
  select `b`.`prodbcatg_id`                                   AS `prodbcatg_id`,
         `a`.`quote_id`                                       AS `quote_id`,
         `c`.`supplier_id`                                    AS `supplier_id`,
         `b`.`product_id`                                     AS `product_id`,
         `e`.`is_comp`                                        AS `is_comp`,
         (case `e`.`is_comp`
            when '1' then `b`.`product_id`
            when '0' then `h`.`comp_id` end)                  AS `comp_id`,
         `b`.`prod_num`                                       AS `prod_num`,
         `b`.`prod_weight`                                    AS `prod_weight`,
         `b`.`model_weight`                                   AS `model_weight`,
         `c`.`includ_tax_price`                               AS `includ_tax_price`,
         (ifnull(`b`.`prod_num`, 0) * `c`.`includ_tax_price`) AS `product_tax_price`
  from ((((((`tower`.`obp_oth_quote_rule` `a`
      join `tower`.`obp_oth_quote_model` `b`) join `tower`.`obp_oth_supplier_quote` `c`) join `tower`.`obp_prd_min_type` `e`) join `tower`.`obp_prd_min_info` `f`) join `tower`.`obp_prd_base_info` `g`) left join `tower`.`obp_comp_prd_rel` `h` on ((
    `h`.`product_id` = `b`.`product_id`)))
  where ((`a`.`prodbcatg_id` = '38') and (`a`.`status` = '2') and (`a`.`quote_id` = `b`.`quote_id`) and
         (`a`.`prodbcatg_id` = `b`.`prodbcatg_id`) and (`b`.`is_score` = '1') and (`c`.`quote_id` = `a`.`quote_id`) and
         (`c`.`prodbcatg_id` = `a`.`prodbcatg_id`) and (`c`.`status` = '1') and
         (`c`.`product_id` = `b`.`product_id`) and (`e`.`id` = `b`.`product_id`) and (`e`.`is_use` = '1') and
         (`f`.`supplier_id` = `c`.`supplier_id`) and (`f`.`product_big_type` = `a`.`prodbcatg_id`) and
         (`f`.`product_specification_id` = `b`.`product_id`) and (`f`.`status` = '1') and
         (`g`.`product_base_info_code` = `f`.`product_base_info_code`) and (`g`.`supplier_id` = `f`.`supplier_id`) and
         (`g`.`base_info_status` = '3'));

