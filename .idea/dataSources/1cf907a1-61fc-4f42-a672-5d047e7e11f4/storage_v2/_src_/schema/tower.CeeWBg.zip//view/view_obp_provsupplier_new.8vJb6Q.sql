create view view_obp_provsupplier_new as
  select `sb`.`supplier_code` AS `supplier_code`,
         `b`.`scheme_id`      AS `scheme_id`,
         `a`.`prov_code`      AS `prov_code`,
         `a`.`city_code`      AS `city_code`,
         1                    AS `sort`
  from `tower`.`obp_supplier_prod_base_info` `b`
         join `tower`.`obp_city_choose_config` `c`
         join `tower`.`obp_supplier_base_info` `sb`
         join `tower`.`obp_supplier_prod_factory` `f`
         join `tower`.`obp_supplier_prod_factory_area` `a`
  where ((`b`.`process_inst_status` = 'A9') and (`c`.`scheme_id` = `b`.`scheme_id`) and (`c`.`is_choose` = '0') and
         (`c`.`state` = '1') and (`b`.`supplier_id` = `sb`.`id`) and (`f`.`supplier_id` = `b`.`supplier_id`) and
         (`f`.`scheme_id` = `b`.`scheme_id`) and (`f`.`base_code` = `f`.`base_code`) and (`f`.`state` = '1') and
         (`a`.`supplier_id` = `f`.`supplier_id`) and (`a`.`scheme_id` = `a`.`scheme_id`) and
         (`a`.`base_code` = `f`.`base_code`) and (`a`.`factory_id` = `f`.`id`) and (`a`.`state` = '1') and
         exists(select 1
                from `tower`.`obp_supplier_access_agreement` `saa`
                where ((`saa`.`supplier_id` = `b`.`supplier_id`) and (`saa`.`scheme_id` = `b`.`scheme_id`) and
                       (`saa`.`state` = '1'))));

