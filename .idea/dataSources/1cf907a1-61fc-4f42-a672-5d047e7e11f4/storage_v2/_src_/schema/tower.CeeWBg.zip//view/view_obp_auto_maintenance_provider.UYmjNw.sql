create view view_obp_auto_maintenance_provider as
  select `a`.`province_code` AS `province_code`,
         `a`.`city_code`     AS `city_code`,
         `a`.`prod_bcatg`    AS `protype_code`,
         `c`.`supplier_code` AS `supplier_code`,
         '1'                 AS `is_checked`,
         `b`.`short_sort`    AS `sort`,
         `a`.`task_state`    AS `STATUS`
  from (`tower`.`obp_citych_access_record` `b`
      join (`tower`.`obp_ch_city_task` `a`
      join `tower`.`obp_supplier_base_info` `c`))
  where ((`b`.`ch_supplier_id` = `c`.`id`) and (`a`.`task_id` = `b`.`task_id`) and (`a`.`task_state` = '400') and
         (`b`.`short_sort` = '1'));

