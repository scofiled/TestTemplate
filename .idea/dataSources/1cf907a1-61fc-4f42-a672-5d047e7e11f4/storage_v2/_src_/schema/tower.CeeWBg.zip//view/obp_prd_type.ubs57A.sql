create view obp_prd_type as
  select `a`.`id`             AS `id`,
         `a`.`code`           AS `code`,
         `a`.`name`           AS `name`,
         `a`.`sort_no`        AS `sort_no`,
         `a`.`is_use`         AS `is_use`,
         `a`.`col1`           AS `col1`,
         `a`.`col2`           AS `col2`,
         `a`.`col3`           AS `col3`,
         `a`.`col4`           AS `col4`,
         `a`.`col5`           AS `col5`,
         `a`.`goods_type`     AS `goods_type`,
         `a`.`is_prov`        AS `is_prov`,
         `a`.`is_electricity` AS `is_electricity`
  from `tower`.`obp_prd_type_new` `a`
  where (`a`.`is_electricity` = '1');

