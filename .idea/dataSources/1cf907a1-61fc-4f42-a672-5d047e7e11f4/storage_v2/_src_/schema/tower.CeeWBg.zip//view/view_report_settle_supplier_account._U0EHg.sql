create view view_report_settle_supplier_account as
  select `d`.`prd_codes`       AS `prdcodes`,
         `d`.`prd_names`       AS `prdnames`,
         `d`.`supplier_code`   AS `supplycode`,
         `d`.`supplier_name`   AS `suppliername`,
         sum(`d`.`tax_amount`) AS `amount`
  from (`tower`.`obp_settle_account` `a`
      join `tower`.`obp_settle_account_detail` `d`)
  where ((`a`.`account_code` = `d`.`account_code`) and (`a`.`process_inst_status` = '1') and (`d`.`status` = '11'))
  group by `d`.`prd_codes`, `d`.`supplier_code`;

