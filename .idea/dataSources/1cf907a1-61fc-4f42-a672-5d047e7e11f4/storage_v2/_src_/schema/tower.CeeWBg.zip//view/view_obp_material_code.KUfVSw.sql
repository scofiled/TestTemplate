create view view_obp_material_code as
  select `p`.`code`                                 AS `big_code`,
         `p`.`name`                                 AS `big_name`,
         `s`.`code`                                 AS `sub_code`,
         `s`.`name`                                 AS `sub_name`,
         `m`.`code`                                 AS `min_code`,
         `m`.`name`                                 AS `min_name`,
         concat(`p`.`code`, `s`.`code`, `m`.`code`) AS `spec`,
         `m`.`is_electricity`                       AS `is_electricity`,
         `p`.`col4`                                 AS `col4`,
         `m`.`is_use`                               AS `is_use`,
         `m`.`col5`                                 AS `update_time`
  from ((`tower`.`obp_prd_type_new` `p`
      join `tower`.`obp_prd_sub_type_new` `s`) join `tower`.`obp_prd_min_type_new` `m`)
  where ((`m`.`parent_code` = `s`.`id`) and (`s`.`parent_code` = `p`.`id`));

