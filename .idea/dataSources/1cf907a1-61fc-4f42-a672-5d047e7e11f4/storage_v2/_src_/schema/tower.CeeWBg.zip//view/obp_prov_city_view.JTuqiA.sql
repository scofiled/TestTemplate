create view obp_prov_city_view as select `p`.`code` AS `code`, `p`.`name` AS `name`, 2 AS `flag`
                                  from `tower`.`obp_province` `p`
                                  union all select `c`.`code` AS `code`, `c`.`name` AS `name`, 3 AS `flag`
                                            from `tower`.`obp_city` `c`;

