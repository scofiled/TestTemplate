create function get_quote_model_type(v_product_id varchar(64))
  returns varchar(10)
  BEGIN

  DECLARE type VARCHAR(10) ;


  IF(v_product_id='4910111' )then 
  set type='discount';
  ELSEIF (v_product_id='4910112')THEN
	
 set type='survey';
  ELSE
		 set type='';
  END if;

  RETURN type;
END;

