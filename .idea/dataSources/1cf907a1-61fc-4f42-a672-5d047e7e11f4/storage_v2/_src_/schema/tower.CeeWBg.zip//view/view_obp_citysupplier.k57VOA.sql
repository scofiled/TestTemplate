create view view_obp_citysupplier as select `tower`.`obp_ch_result_online_use`.`city_code`     AS `city_code`,
                                            `tower`.`obp_ch_result_online_use`.`protype_code`  AS `protype_code`,
                                            `tower`.`obp_ch_result_online_use`.`supplier_code` AS `supplier_code`,
                                            `tower`.`obp_ch_result_online_use`.`supplier_sort` AS `supplier_sort`,
                                            `tower`.`obp_ch_result_online_use`.`total_score`   AS `total_score`
                                     from `tower`.`obp_ch_result_online_use`
                                     union all select `a`.`city_code`     AS `city_code`,
                                                      `a`.`prod_bcatg`    AS `protype_code`,
                                                      `c`.`supplier_code` AS `supplier_code`,
                                                      `b`.`total_sort`    AS `total_sort`,
                                                      `b`.`total_score`   AS `total_score`
                                               from ((`tower`.`obp_ch_city_task` `a`
                                                   join `tower`.`obp_citych_access_record` `b`) join `tower`.`obp_supplier_base_info` `c`)
                                               where ((`a`.`task_id` = `b`.`task_id`) and (`a`.`task_state` = '400') and
                                                      (`a`.`prod_bcatg` like '8%') and
                                                      (`b`.`ch_supplier_id` = `c`.`id`) and (`b`.`is_inshort` = '1'));

