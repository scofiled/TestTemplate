create procedure p_update_construct_quote_view(IN prodBcatg varchar(5), IN provCode varchar(10), OUT flag int)
  BEGIN

START TRANSACTION;
DELETE a.* from obp_oth_construct_quote_use a where a.prov_code=provCode
and a.prodbcatg_id=prodBcatg;
INSERT into obp_oth_construct_quote_use
SELECT * from obp_oth_construct_quote a where a.prov_code=provCode
and a.prodbcatg_id=prodBcatg;
DELETE a.* from obp_oth_construct_product_quote_use a where a.prov_code=provCode
and a.prodbcatg_id=prodBcatg;
INSERT into obp_oth_construct_product_quote_use
SELECT * from obp_oth_construct_product_quote a where a.prov_code=provCode
and a.prodbcatg_id=prodBcatg;
DELETE a.* from obp_cer_score_inst a where a.province_code=provCode
and a.prod_bcatg=prodBcatg;
INSERT into obp_cer_score_inst
SELECT * from obp_cer_score_inst_temp a where a.province_code=provCode
and a.prod_bcatg=prodBcatg;
DELETE a.* from obp_product_score_result a where a.province_code=provCode
and a.product_btype=prodBcatg;
INSERT into obp_product_score_result(	supplier_id,
	product_btype,
	province_code,
	product_total_price,
	best_price,
	product_score,
	product_level,
	create_time,
	col1,
	col2,
	col3,
	col4,
	city_code)
SELECT 	supplier_id,
	product_btype,
	province_code,
	product_total_price,
	best_price,
	product_score,
	product_level,
	create_time,
	col1,
	col2,
	col3,
	col4,
	city_code from obp_product_score_result_temp a where a.province_code=provCode
and a.product_btype=prodBcatg;

COMMIT;
set flag=1;
END;

