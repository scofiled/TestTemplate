create view view_obp_supplier_all_new as select `a`.`supplier_code`                       AS `supplier_code`,
                                                `a`.`scheme_id`                           AS `scheme_id`,
                                                concat(left(`a`.`province_code`, 5), '1') AS `province_code`,
                                                `a`.`city_code`                           AS `city_code`
                                         from `tower`.`view_obp_protypeprice` `a`
                                         union all select `b`.`supplier_code`                   AS `supplier_code`,
                                                          `b`.`scheme_id`                       AS `scheme_id`,
                                                          concat(left(`b`.`prov_code`, 5), '1') AS `province_code`,
                                                          `b`.`city_code`                       AS `city_code`
                                                   from `tower`.`view_obp_provsupplier_new_new` `b`;

