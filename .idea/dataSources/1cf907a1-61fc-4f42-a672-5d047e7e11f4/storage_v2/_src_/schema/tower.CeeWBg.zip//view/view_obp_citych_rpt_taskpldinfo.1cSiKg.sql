create view view_obp_citych_rpt_taskpldinfo as
  select `a`.`task_id`                                                              AS `task_id`,
         avg(`a`.`total_score`)                                                     AS `avg_check_totalscore`,
         `b`.`avg_total_score`                                                      AS `avg_total_score`,
         ((avg(`a`.`total_score`) - `b`.`avg_total_score`) / `b`.`avg_total_score`) AS `pld`
  from `tower`.`view_obp_citych_rpt_taskcheckinfo` `a`
         join `tower`.`view_obp_citych_rpt_taskscoreinfo` `b`
  where (`a`.`task_id` = `b`.`task_id`)
  group by `a`.`task_id`;

