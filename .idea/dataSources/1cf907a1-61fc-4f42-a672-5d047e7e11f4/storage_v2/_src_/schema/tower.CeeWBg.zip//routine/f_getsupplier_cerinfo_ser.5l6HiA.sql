create function f_getsupplier_cerinfo_ser(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                          v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  
  set cer_info_temp='';
	set cer_info_html='';

SELECT '<br>服务要素：' into cer_info_temp;
 set cer_info_html=CONCAT(cer_info_html,REPLACE(cer_info_temp,',',''));
	 set cer_info_temp='';

    select GROUP_CONCAT('<br>',q.rule_name,':',q.rule_value)into cer_info_temp from  (
   select e.rule_name,e.value_type,(CASE when( e.value_type='0B' or e.value_type='0E')then a.rule_value
   when  (e.value_type='0A' )
		THEN (SELECT M.rule_value_desc FROM obp_cer_rule_value M WHERE  M.rule_id=E.rule_id AND M.rule_value=A.rule_value )
   end ) AS rule_value


	from obp_cer_score_inst_info a  ,obp_cer_rule e
	where 

	 a.rule_id = e.rule_id 
   and a.com_id=v_base_info_code
	and a.supplier_id=v_supplier_id
	and a.prod_bcatg=v_product_big_type
	and e.column_1='1')q;


   set cer_info_html=CONCAT(cer_info_html,REPLACE(cer_info_temp,',',''));
	 set cer_info_temp='';


  RETURN cer_info_html;
END;

