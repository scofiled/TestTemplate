create view view_obp_cable_fee_offline_old as
  select `view_obp_cable_fee_offline`.`supplier_code` AS `supplier_code`,
         `view_obp_cable_fee_offline`.`from_addr`     AS `from_addr`,
         `view_obp_cable_fee_offline`.`to_addr`       AS `to_addr`,
         `view_obp_cable_fee_offline`.`fee_rate`      AS `fee_rate`,
         `view_obp_cable_fee_offline`.`protype_code`  AS `protype_code`
  from `tower`.`view_obp_cable_fee_offline`;

