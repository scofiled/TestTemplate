create view view_obp_supplier_prd_index_offline as
  select `a`.`supplier_code`                                                         AS `supplier_code`,
         `b`.`scheme_id`                                                             AS `protype_code`,
         `f_getsupplier_cerinfo_all_new`(`a`.`id`, `b`.`scheme_id`, `b`.`base_code`) AS `info`
  from (`tower`.`view_obp_prd_offline` `b`
      join `tower`.`obp_supplier_base_info` `a`)
  where (`a`.`id` = `b`.`supplier_id`);

