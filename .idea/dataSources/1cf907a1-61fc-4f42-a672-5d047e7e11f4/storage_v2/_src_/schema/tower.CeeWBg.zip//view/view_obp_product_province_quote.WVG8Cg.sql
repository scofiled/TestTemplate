create view view_obp_product_province_quote as
  select `a`.`product_specification_name`                                                                       AS `NAME`,
         ''                                                                                                     AS `goods_no`,
         `b`.`supplier_code`                                                                                    AS `supplier_code`,
         ''                                                                                                     AS `sell_price`,
         ''                                                                                                     AS `market_price`,
         `a`.`product_describe`                                                                                 AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `a`.`metering_unit`)))                                                        AS `unit_name`,
         `c`.`generic_brand`                                                                                    AS `brand_name`,
         ''                                                                                                     AS `spec_array`,
         ''                                                                                                     AS `catagory_id`,
         ''                                                                                                     AS `latest`,
         ''                                                                                                     AS `bargainPrice`,
         ''                                                                                                     AS `recommend`,
         ''                                                                                                     AS `hot`,
         `a`.`material_code`                                                                                    AS `material_code`,
         `a`.`supplier_product_code`                                                                            AS `supplier_product_code`,
         (select `q`.`rule_value`
          from `tower`.`view_obp_supplier_ghzq_value` `q`
          where ((`q`.`com_id` = `c`.`product_base_info_code`) and
                 (`q`.`supplier_id` = `c`.`supplier_id`)))                                                      AS `stock_cycle`,
         '1'                                                                                                    AS `minbuy_num`,
         '1'                                                                                                    AS `pack_num`,
         ''                                                                                                     AS `prd_model`,
         ''                                                                                                     AS `goodsType`,
         ''                                                                                                     AS `mainSku`,
         ''                                                                                                     AS `versionName`,
         if(((`a`.`product_weight` = 0) or isnull(`a`.`product_weight`)), 0,
            `a`.`product_weight`)                                                                               AS `weight`,
         (select `d`.`code`
          from `tower`.`obp_prd_min_type_new` `d`
          where (`d`.`id` = `a`.`product_specification_id`))                                                    AS `prd_param`,
         ''                                                                                                     AS `wareQD`,
         ''                                                                                                     AS `company_price`,
         ''                                                                                                     AS `tax_price`,
         (select `d`.`quote_tax`
          from `tower`.`obp_prd_min_type_new` `d`
          where (`d`.`id` = `a`.`product_specification_id`))                                                    AS `tax_rate`,
         `c`.`max_supply_capacity`                                                                              AS `max_supply_capacity`,
         ''                                                                                                     AS `alert_supply_capacity`,
         ''                                                                                                     AS `extreme_supply_capacity`,
         ''                                                                                                     AS `install_rate`,
         ''                                                                                                     AS `use_install_rate`,
         '0'                                                                                                    AS `use_freight_rate`,
         ''                                                                                                     AS `freight_price`,
         '0'                                                                                                    AS `Price_star`,
         '0'                                                                                                    AS `Price_mark`,
         `f`.`Service_star`                                                                                     AS `Service_star`,
         `f`.`Service_mark`                                                                                     AS `Service_mark`,
         `f`.`Quality_star`                                                                                     AS `Quality_star`,
         `f`.`Quality_mark`                                                                                     AS `Quality_mark`,
         `d`.`application_no`                                                                                   AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type_new` `l`
          where (`l`.`id` = `c`.`product_big_type_code`))                                                       AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type_new` `l`
              join `tower`.`obp_prd_min_type_new` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `a`.`product_specification_id`)))                                                  AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type_new` `m`
          where (`m`.`id` = `a`.`product_specification_id`))                                                    AS `Small_code`,
         ''                                                                                                     AS `debug_service_fee`,
         ''                                                                                                     AS `guide_service_fee`,
         ''                                                                                                     AS `height`
  from `tower`.`obp_prd_min_info` `a`
         join `tower`.`obp_supplier_base_info` `b`
         join `tower`.`obp_prd_base_info` `c`
         join `tower`.`obp_supplier_access_agreement` `d`
         join `tower`.`view_obp_supplier_quote_product_id` `e`
         join `tower`.`view_obp_cer_score_inst_prov_column` `f`
  where ((`a`.`supplier_id` = `b`.`id`) and (`c`.`supplier_id` = `a`.`supplier_id`) and
         (`c`.`product_big_type_code` = `a`.`product_big_type`) and
         (`c`.`product_base_info_code` = `a`.`product_base_info_code`) and (`a`.`supplier_id` = `d`.`supplier_id`) and
         (`a`.`product_big_type` = `d`.`prod_bctg`) and (`d`.`state` = '1') and
         (`a`.`supplier_id` = `e`.`supplier_id`) and (`a`.`product_big_type` = `e`.`prodbcatg_id`) and
         (`a`.`product_specification_id` = `e`.`product_id`) and (`a`.`supplier_id` = `f`.`supplier_id`) and
         (`a`.`product_base_info_code` = `f`.`com_id`) and (`f`.`inst_status` = '10A') and
         (`c`.`base_info_status` = '3') and (`a`.`product_big_type` = 'A0') and (`a`.`status` = '1'));

