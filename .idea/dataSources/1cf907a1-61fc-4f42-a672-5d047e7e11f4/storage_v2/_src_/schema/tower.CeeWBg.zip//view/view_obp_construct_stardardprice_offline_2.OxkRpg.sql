create view view_obp_construct_stardardprice_offline_2 as
  select `a`.`prov_code`                                                               AS `prov_code`,
         `a`.`prodbcatg_id`                                                            AS `prd_type_code`,
         `b`.`product_id`                                                              AS `prd_min_code`,
         `get_construct_provstardardprice`(`a`.`prov_code`, ifnull(`b`.`standard_price`, 0),
                                           ifnull(`b`.`safety_fee`, 0))                AS `standard_price`,
         `b`.`content`                                                                 AS `content`,
         `get_construct_safetyfee`(`a`.`prov_code`, 1.11, ifnull(`b`.`safety_fee`, 0)) AS `safety_fee`
  from (`tower`.`obp_oth_construct_quotemodel` `b`
      join `tower`.`obp_construction_cer_plan` `a`)
  where (`a`.`circle_id` = `b`.`quote_id`);

