create view view_obp_ticket_info as
  select `t`.`ticketCode`          AS `ticketCode`,
         `t`.`InvoiceHead`         AS `InvoiceHead`,
         `t`.`InvoiceContent`      AS `InvoiceContent`,
         `t`.`billToer`            AS `billToer`,
         `t`.`billToContact`       AS `billToContact`,
         `t`.`billToProvince`      AS `billToProvince`,
         `t`.`billToCity`          AS `billToCity`,
         `t`.`billToCounty`        AS `billToCounty`,
         `t`.`billToTown`          AS `billToTown`,
         `t`.`billToAddress`       AS `billToAddress`,
         `t`.`isTaxPay`            AS `isTaxPay`,
         `t`.`mergOrg`             AS `mergOrg`,
         `t`.`mergOrgName`         AS `mergOrgName`,
         `t`.`NationalTaxTaxpayer` AS `NationalTaxTaxpayer`
  from `tower`.`obp_settle_ticket_information` `t`
  where (`t`.`goods_type` = '1');

