create view view_obp_product_46_47_offline as
  select `a`.`product_specification_name`                                                                          AS `NAME`,
         ''                                                                                                        AS `goods_no`,
         `b`.`supplier_code`                                                                                       AS `supplier_code`,
         `e`.`standard_price`                                                                                      AS `standard_price`,
         concat(ifnull((select `b`.`content`
                        from `tower`.`obp_comp_desc` `b`
                        where (`a`.`product_specification_id` = `b`.`comp_id`)), ''),
                `a`.`product_describe`)                                                                            AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `a`.`metering_unit`)))                                                           AS `unit_name`,
         `c`.`generic_brand`                                                                                       AS `brand_name`,
         ''                                                                                                        AS `spec_array`,
         `a`.`material_code`                                                                                       AS `material_code`,
         ''                                                                                                        AS `tax_price`,
         (select `t`.`col2`
          from `tower`.`obp_tax` `t`
          where (`t`.`tax_rate` = cast(`c`.`added_value_tax_rate` as signed)))                                     AS `tax_rate`,
         `f`.`service_star`                                                                                        AS `Service_star`,
         `f`.`service_score`                                                                                       AS `Service_mark`,
         `f`.`qua_star`                                                                                            AS `Quality_star`,
         `f`.`qua_score`                                                                                           AS `Quality_mark`,
         `d`.`application_no`                                                                                      AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type` `l`
          where (`l`.`id` = `c`.`product_big_type_code`))                                                          AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type` `l`
              join `tower`.`obp_prd_min_type` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `a`.`product_specification_id`)))                                                     AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type` `m`
          where (`m`.`id` = `a`.`product_specification_id`))                                                       AS `Small_code`
  from (((((`tower`.`obp_prd_min_info` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_prd_base_info` `c`) join `tower`.`obp_supplier_access_agreement` `d`) join `tower`.`obp_oth_quote_model` `e`) join `tower`.`obp_cer_score_inst` `f`)
  where ((`a`.`supplier_id` = `b`.`id`) and (`c`.`supplier_id` = `a`.`supplier_id`) and
         (`c`.`product_big_type_code` = `a`.`product_big_type`) and
         (`c`.`product_base_info_code` = `a`.`product_base_info_code`) and (`a`.`supplier_id` = `d`.`supplier_id`) and
         (`a`.`product_big_type` = `d`.`prod_bctg`) and (`d`.`state` = '1') and
         (`a`.`product_big_type` = `e`.`prodbcatg_id`) and (`a`.`product_specification_id` = `e`.`product_id`) and
         (`a`.`supplier_id` = `f`.`supplier_id`) and (`a`.`product_base_info_code` = `f`.`com_id`) and
         (`f`.`inst_status` = '10A') and (`c`.`base_info_status` = '3') and
         (`a`.`product_big_type` in (46, 47, 48, 49)) and (`a`.`status` = '1'));

