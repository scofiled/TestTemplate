create view view_obp_transportfee_58_offline_old as
  select `view_obp_transportfee_58_offline`.`supplier_code` AS `supplier_code`,
         `view_obp_transportfee_58_offline`.`from_addr`     AS `from_addr`,
         `view_obp_transportfee_58_offline`.`to_addr`       AS `to_addr`,
         `view_obp_transportfee_58_offline`.`transport_fee` AS `transport_fee`,
         `view_obp_transportfee_58_offline`.`mileage`       AS `mileage`,
         `view_obp_transportfee_58_offline`.`protype_code`  AS `protype_code`
  from `tower`.`view_obp_transportfee_58_offline`;

