create view view_obp_tower_installfee_offline_old as
  select `view_obp_tower_installfee_offline`.`province_code`    AS `province_code`,
         `view_obp_tower_installfee_offline`.`protype_code`     AS `protype_code`,
         `view_obp_tower_installfee_offline`.`supplier_code`    AS `supplier_code`,
         `view_obp_tower_installfee_offline`.`Install_fee_rate` AS `Install_fee_rate`
  from `tower`.`view_obp_tower_installfee_offline`;

