create view view_obp_supplier_base_all as select `b`.`id`                                        AS `id`,
                                                 `b`.`owner`                                     AS `owner`,
                                                 '9'                                             AS `operate_type`,
                                                 `b`.`supplier_code`                             AS `supplier_code`,
                                                 `b`.`org_code`                                  AS `org_code`,
                                                 `b`.`org_name`                                  AS `org_name`,
                                                 `b`.`org_short_called`                          AS `org_short_called`,
                                                 (case
                                                    when ((`b`.`org_type` = '0201') or (`b`.`org_type` = '01') or
                                                          (`b`.`org_type` = '020104')) then '01'
                                                    when ((`b`.`org_type` = '0202') or (`b`.`org_type` = '02'))
                                                            then '02'
                                                    when ((`b`.`org_type` = '0203') or (`b`.`org_type` = '03'))
                                                            then '03'
                                                    when ((`b`.`org_type` = '0204') or (`b`.`org_type` = '04'))
                                                            then '04'
                                                    when ((`b`.`org_type` = '0206') or (`b`.`org_type` = '06'))
                                                            then '06'
                                                    else '05' end)                               AS `org_type`,
                                                 `b`.`country_code`                              AS `country_code`,
                                                 `b`.`region_code`                               AS `region_code`,
                                                 `b`.`province_code`                             AS `province_code`,
                                                 `b`.`city_code`                                 AS `city_code`,
                                                 `b`.`legal_person`                              AS `legal_person`,
                                                 `b`.`pay_taxes_type`                            AS `pay_taxes_type`,
                                                 `b`.`taxes_num`                                 AS `taxes_num`,
                                                 `b`.`id_number`                                 AS `id_number`,
                                                 `b`.`relevance_type`                            AS `relevance_type`,
                                                 `b`.`elevance_org`                              AS `elevance_org`,
                                                 `b`.`address`                                   AS `address`,
                                                 `b`.`supplier_Fax`                              AS `supplier_Fax`,
                                                 `b`.`contacter_Tel`                             AS `contacter_Tel`,
                                                 `b`.`supplier_email`                            AS `supplier_email`,
                                                 `b`.`post_code`                                 AS `post_code`,
                                                 `b`.`web_address`                               AS `web_address`,
                                                 `b`.`is_listed_company`                         AS `is_listed_company`,
                                                 concat('1', `b`.`status`)                       AS `status`,
                                                 `b`.`supplier_rank`                             AS `supplier_rank`,
                                                 `b`.`create_time`                               AS `create_time`,
                                                 `b`.`creater_id`                                AS `creater_id`,
                                                 `b`.`update_time`                               AS `update_time`,
                                                 `b`.`update_man_id`                             AS `update_man_id`,
                                                 `b`.`register_location`                         AS `register_location`,
                                                 `b`.`register_location_code`                    AS `register_location_code`,
                                                 `b`.`remark`                                    AS `remark`,
                                                 `b`.`registered_no`                             AS `registered_no`,
                                                 `b`.`register_money`                            AS `register_money`,
                                                 `b`.`production_equipment_num`                  AS `production_equipment_num`,
                                                 `b`.`test_equipment_num`                        AS `test_equipment_num`,
                                                 `b`.`production_workshop_area`                  AS `production_workshop_area`,
                                                 `b`.`production_warehouse_area`                 AS `production_warehouse_area`,
                                                 `b`.`check_opinion`                             AS `check_opinion`,
                                                 `b`.`his_status`                                AS `his_status`,
                                                 `b`.`cap_user_his_status`                       AS `cap_user_his_status`,
                                                 `b`.`detail_descript`                           AS `detail_descript`,
                                                 '1'                                             AS `is_online`,
                                                 `b`.`type`                                      AS `type`,
                                                 (select `cu`.`USER_NAME`
                                                  from `tower`.`cap_user` `cu`
                                                  where (`b`.`creater_id` = `cu`.`OPERATOR_ID`)) AS `creater_name`,
                                                 ''                                              AS `workItemName`,
                                                 ''                                              AS `partiName`,
                                                 `b`.`bank_maintence_state`                      AS `bank_maintence_state`,
                                                 `b`.`supplier_accounts_type`                    AS `supplier_accounts_type`,
                                                 `b`.`audit_state`                               AS `audit_state`,
                                                 `b`.`LEVEL`                                     AS `level`
                                          from `tower`.`obp_supplier_base_info` `b`
                                          union all select `b`.`id`                                        AS `id`,
                                                           ''                                              AS `owner`,
                                                           `b`.`operate_type`                              AS `operate_type`,
                                                           `b`.`supplier_code`                             AS `supplier_code`,
                                                           `b`.`org_code`                                  AS `org_code`,
                                                           `b`.`org_name`                                  AS `org_name`,
                                                           ''                                              AS `org_short_called`,
                                                           (case
                                                              when ((`b`.`org_type` = '0201') or
                                                                    (`b`.`org_type` = '01') or
                                                                    (`b`.`org_type` = '020104')) then '01'
                                                              when ((`b`.`org_type` = '0202') or (`b`.`org_type` = '02'))
                                                                      then '02'
                                                              when ((`b`.`org_type` = '0203') or (`b`.`org_type` = '03'))
                                                                      then '03'
                                                              when ((`b`.`org_type` = '0204') or (`b`.`org_type` = '04'))
                                                                      then '04'
                                                              when ((`b`.`org_type` = '0206') or (`b`.`org_type` = '06'))
                                                                      then '06'
                                                              else '05' end)                               AS `org_type`,
                                                           ''                                              AS `country_code`,
                                                           ''                                              AS `region_code`,
                                                           ''                                              AS `province_code`,
                                                           ''                                              AS `city_code`,
                                                           ''                                              AS `legal_person`,
                                                           ''                                              AS `pay_taxes_type`,
                                                           ''                                              AS `taxes_num`,
                                                           ''                                              AS `id_number`,
                                                           ''                                              AS `relevance_type`,
                                                           ''                                              AS `elevance_org`,
                                                           ''                                              AS `address`,
                                                           ''                                              AS `supplier_Fax`,
                                                           ''                                              AS `contacter_Tel`,
                                                           ''                                              AS `supplier_email`,
                                                           ''                                              AS `post_code`,
                                                           ''                                              AS `web_address`,
                                                           ''                                              AS `is_listed_company`,
                                                           concat('0', `b`.`check_process_status`)         AS `status`,
                                                           ''                                              AS `supplier_rank`,
                                                           `b`.`create_time`                               AS `create_time`,
                                                           `b`.`creater_id`                                AS `creater_id`,
                                                           `b`.`update_time`                               AS `update_time`,
                                                           ''                                              AS `update_man_id`,
                                                           ''                                              AS `register_location`,
                                                           ''                                              AS `register_location_code`,
                                                           `b`.`remark`                                    AS `remark`,
                                                           ''                                              AS `registered_no`,
                                                           ''                                              AS `register_money`,
                                                           ''                                              AS `production_equipment_num`,
                                                           ''                                              AS `test_equipment_num`,
                                                           ''                                              AS `production_workshop_area`,
                                                           ''                                              AS `production_warehouse_area`,
                                                           `b`.`check_opinion`                             AS `check_opinion`,
                                                           ''                                              AS `his_status`,
                                                           ''                                              AS `cap_user_his_status`,
                                                           ''                                              AS `detail_descript`,
                                                           '0'                                             AS `is_online`,
                                                           `b`.`supplier_type`                             AS `type`,
                                                           (select `cu`.`USER_NAME`
                                                            from `tower`.`cap_user` `cu`
                                                            where (`b`.`creater_id` = `cu`.`OPERATOR_ID`)) AS `creater_name`,
                                                           (select `wwi`.`workitem_name`
                                                            from `tower`.`obp_workitem_detail_info` `wwi`
                                                            where (`wwi`.`process_inst_id` = `b`.`process_id`)
                                                            order by `wwi`.`workitem_id` desc
                                                            limit 0,1)                                     AS `workItemName`,
                                                           (select `wwi`.`emp_name`
                                                            from `tower`.`obp_workitem_detail_info` `wwi`
                                                            where (`wwi`.`process_inst_id` = `b`.`process_id`)
                                                            order by `wwi`.`workitem_id` desc
                                                            limit 0,1)                                     AS `partiName`,
                                                           ''                                              AS `bank_maintence_state`,
                                                           `b`.`supplier_accounts_type`                    AS `supplier_accounts_type`,
                                                           'ING'                                           AS `audit_state`,
                                                           ''                                              AS `level`
                                                    from `tower`.`obp_pur_supplier_base_info` `b`
                                                    where (`b`.`check_process_status` <> '1');

