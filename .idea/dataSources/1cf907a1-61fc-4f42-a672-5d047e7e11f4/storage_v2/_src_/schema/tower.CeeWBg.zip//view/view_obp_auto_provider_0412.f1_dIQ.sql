create view view_obp_auto_provider_0412 as select `a`.`province_code` AS `province_code`,
                                                  `a`.`city_code`     AS `city_code`,
                                                  `a`.`area_code`     AS `country_code`,
                                                  `a`.`prod_bcatg`    AS `protype_code`,
                                                  `b`.`supplier_code` AS `supplier_code`,
                                                  `a`.`is_checked`    AS `is_checked`,
                                                  `a`.`sort`          AS `sort`,
                                                  `a`.`state`         AS `STATUS`,
                                                  `a`.`task_id`       AS `rel_id`
                                           from (`tower`.`obp_citych_score_result_online` `a`
                                               join `tower`.`obp_supplier_base_info` `b`)
                                           where ((`a`.`ch_supplier_id` = `b`.`id`) and ((`a`.`prod_bcatg` not in
                                                                                          ('12', '20', '21', '22', '24', '32', '33', '34', '38', '61', '65', '68')) or
                                                                                         ((`a`.`prod_bcatg` in
                                                                                           ('12', '20', '21', '22', '24', '32', '33', '34', '38', '61', '65', '68')) and
                                                                                          (`a`.`area_code` is not null))))
                                           union all select `a`.`province_code` AS `province_code`,
                                                            `a`.`city_code`     AS `city_code`,
                                                            `c`.`code`          AS `country_code`,
                                                            `a`.`prod_bcatg`    AS `protype_code`,
                                                            `b`.`supplier_code` AS `supplier_code`,
                                                            `a`.`is_checked`    AS `is_checked`,
                                                            `a`.`sort`          AS `sort`,
                                                            `a`.`state`         AS `STATUS`,
                                                            `a`.`task_id`       AS `rel_id`
                                                     from ((`tower`.`obp_citych_score_result_online` `a`
                                                         join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_mana_area` `c`)
                                                     where ((`a`.`ch_supplier_id` = `b`.`id`) and
                                                            (`a`.`city_code` = `c`.`p_code`) and (`a`.`prod_bcatg` in
                                                                                                  ('12', '20', '21', '22', '24', '32', '33', '34', '38', '61', '65', '68')) and
                                                            isnull(`a`.`area_code`) and (`c`.`status` = '1'));

