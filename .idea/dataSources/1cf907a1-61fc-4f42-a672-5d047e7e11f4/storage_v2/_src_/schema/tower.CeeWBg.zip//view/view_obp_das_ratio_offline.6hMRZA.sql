create view view_obp_das_ratio_offline as
  select `a`.`prodbcatg_id`  AS `prd_type_code`,
         `a`.`scheme_id`     AS `scheme_id`,
         `a`.`province_code` AS `province_code`,
         `a`.`city_code`     AS `city_code`,
         `a`.`price_ratio`   AS `discount`
  from `tower`.`obp_das_quote_city_ratio` `a`;

