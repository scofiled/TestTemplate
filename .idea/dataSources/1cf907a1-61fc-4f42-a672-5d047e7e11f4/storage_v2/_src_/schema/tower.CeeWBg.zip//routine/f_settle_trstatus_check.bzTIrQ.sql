create function f_settle_trstatus_check(rd_status varchar(1), r_proc_inst_status varchar(1))
  returns varchar(1)
  BEGIN
DECLARE v_value VARCHAR(1);

IF (rd_status = '1' AND (r_proc_inst_status = '1' OR r_proc_inst_status='2')) THEN
	SET v_value = '1';
ELSEIF (rd_status = '2' AND (r_proc_inst_status = '1' OR r_proc_inst_status='2')) THEN
	SET v_value = '2';
ELSE
	SET v_value = '0';
END IF;

RETURN v_value;   
END;

