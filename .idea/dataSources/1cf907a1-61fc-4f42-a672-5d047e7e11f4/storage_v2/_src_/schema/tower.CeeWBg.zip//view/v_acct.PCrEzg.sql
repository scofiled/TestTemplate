create view v_acct as
  select `e`.`USERID`     AS `USER_ID`,
         `e`.`USERID`     AS `LOGIN_NAME`,
         `e`.`EMPNAME`    AS `USER_NAME`,
         `eo`.`ORGID`     AS `ORG_ID`,
         (case `u`.`STATUS`
            when '1' then '1'
            else '0' end) AS `STATUS`,
         `e`.`OEMAIL`     AS `EMAIL`,
         `e`.`MOBILENO`   AS `MOBILE`
  from ((`tower`.`org_employee` `e`
      join `tower`.`org_emporg` `eo`) join `tower`.`cap_user` `u`)
  where ((`e`.`EMPID` = `eo`.`EMPID`) and (`e`.`USERID` = `u`.`USER_ID`));

