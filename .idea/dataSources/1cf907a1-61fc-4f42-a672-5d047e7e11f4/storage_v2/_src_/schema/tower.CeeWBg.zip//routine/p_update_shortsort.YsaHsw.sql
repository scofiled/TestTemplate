create procedure p_update_shortsort(IN v_task_id varchar(64))
  BEGIN
	#Routine body goes here...
DECLARE rmcnt INT;

set rmcnt=0;
SELECT
	COUNT(1) into rmcnt
FROM
obp_city_task_person b
WHERE
b.task_id=v_task_id;
END;

