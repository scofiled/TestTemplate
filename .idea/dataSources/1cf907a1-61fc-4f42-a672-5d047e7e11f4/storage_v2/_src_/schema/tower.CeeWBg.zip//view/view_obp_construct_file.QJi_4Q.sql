create view view_obp_construct_file as
  select `a`.`file_name`                                                                AS `file_name`,
         concat(replace(`a`.`file_abs_route`, '/mnt/nfs/', 'http://www.tower.com.cn/')) AS `path`,
         `a`.`rel_id`                                                                   AS `rel_id`,
         `a`.`id`                                                                       AS `id`
  from `tower`.`obp_ch_decision_file` `a`
  where (`a`.`status` = '1');

