create view view_pur_header as
  select `h`.`id`                   AS `id`,
         `h`.`sys_code`             AS `sys_code`,
         `h`.`purchase_list_code`   AS `purchase_list_code`,
         `h`.`project_code`         AS `project_code`,
         `h`.`project_name`         AS `project_name`,
         `h`.`project_manager`      AS `project_manager`,
         `h`.`purchase_list_amount` AS `purchase_list_amount`,
         `h`.`site_code`            AS `site_code`,
         `h`.`site_name`            AS `site_name`,
         `h`.`is_changed`           AS `is_changed`,
         `h`.`user_id`              AS `user_id`,
         `h`.`user_name`            AS `user_name`,
         `h`.`remark`               AS `remark`,
         `h`.`status`               AS `status`,
         `h`.`rcvtime`              AS `rcvtime`,
         `h`.`col1`                 AS `col1`,
         `h`.`col2`                 AS `col2`,
         `h`.`col3`                 AS `col3`,
         `h`.`col4`                 AS `col4`,
         `h`.`col5`                 AS `col5`
  from `tower`.`obp_pur_header` `h`;

