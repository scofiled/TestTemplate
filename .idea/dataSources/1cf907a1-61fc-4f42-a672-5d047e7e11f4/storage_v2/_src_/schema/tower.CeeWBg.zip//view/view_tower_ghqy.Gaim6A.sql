create view view_tower_ghqy as
  select `a`.`supplier_id`                                       AS `supplier_id`,
         `c`.`org_name`                                          AS `supplier_name`,
         `a`.`product_big_type`                                  AS `product_big_type`,
         `a`.`product_base_info_code`                            AS `access_code`,
         group_concat(`a`.`supply_provinces_id` separator ',')   AS `factory_provcodes`,
         group_concat(`a`.`supply_provinces_name` separator ',') AS `factory_provnames`,
         `b`.`supply_province_id`                                AS `supply_provcodes`,
         `b`.`supply_provinces_name`                             AS `supply_provnames`
  from ((`tower`.`obp_tw_supplier_factory_info` `a`
      join `tower`.`obp_tower_product_base_info` `b`) join `tower`.`obp_supplier_base_info` `c`)
  where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and (`a`.`supplier_id` = `b`.`supplier_id`) and
         (`a`.`supplier_id` = `c`.`id`) and (`a`.`product_big_type` = `b`.`product_big_type`) and (`b`.`status` = '3'))
  group by `a`.`supplier_id`, `c`.`org_name`, `a`.`product_big_type`, `a`.`product_base_info_code`,
           `b`.`supply_province_id`, `b`.`supply_provinces_name`
  order by `a`.`supplier_id`, `a`.`product_base_info_code`;

