create view view_settle_check_jyreport as
  select `r`.`OrderCode`                         AS `OrderCode`,
         `r`.`MaterialCode`                      AS `MaterialCode`,
         `r`.`batchLineId`                       AS `batchLineId`,
         `c`.`create_time`                       AS `checkStartTime`,
         `d`.`SettleStatus`                      AS `settleStatus`,
         `d`.`PayRate`                           AS `PayRate`,
         `d`.`status`                            AS `checkStatus`,
         (case `c`.`process_inst_status`
            when '2' then '1'
            else `c`.`process_inst_status` end)  AS `checkProcStatus`,
         `c`.`process_submit_time`               AS `checkProcTime`,
         `rd`.`status`                           AS `rmCheckStatus`,
         (case `rm`.`process_inst_status`
            when '2' then '1'
            else `rm`.`process_inst_status` end) AS `rmCheckProcStatus`,
         `rm`.`process_submit_time`              AS `rmCheckProcTime`,
         `s`.`sent_time`                         AS `accTime`,
         `p`.`gs_pay_time`                       AS `payTime`
  from (((((((`tower`.`obp_settle_check` `c` left join `tower`.`obp_settle_check_detail` `d` on ((`c`.`CheckCode` =
                                                                                                  `d`.`CheckCode`))) left join `tower`.`obp_settle_check_rm_detail` `rd` on ((
    (`d`.`Receivingid` = `rd`.`Receivingid`) and (`d`.`ProjectStatus` = `rd`.`ProjectStatus`) and
    (`d`.`SettleStatus` = `rd`.`SettleStatus`)))) left join `tower`.`obp_settle_check_rm` `rm` on ((`rd`.`CheckRMCode` =
                                                                                                    `rm`.`CheckRMCode`))) left join `tower`.`obp_settle_receiving` `r` on ((
    `d`.`Receivingid` = `r`.`id`))) left join `tower`.`obp_settlement_detail` `md` on ((
    (`md`.`Receivingid` = `d`.`Receivingid`) and (`d`.`ProjectStatus` = `md`.`ProjectStatus`) and
    (`d`.`SettleStatus` = `md`.`SettleStatus`)))) left join `tower`.`obp_settlement` `s` on ((`md`.`settlementCode` =
                                                                                              `s`.`SettlementCode`))) left join `tower`.`obp_settle_gs_payresult` `p` on ((
    `s`.`SettlementCode` = `p`.`settlement_code`)));

