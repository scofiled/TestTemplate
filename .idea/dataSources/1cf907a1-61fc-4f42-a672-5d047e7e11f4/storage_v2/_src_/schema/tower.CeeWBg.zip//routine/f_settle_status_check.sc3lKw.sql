create function f_settle_status_check(cd_status varchar(1), rd_status varchar(1))
  returns varchar(1)
  BEGIN
DECLARE v_value VARCHAR(1);

IF (cd_status = '1' AND (rd_status = '1' OR rd_status = '0' OR rd_status is NULL)) THEN
	SET v_value = '1';
ELSEIF cd_status = '0' THEN
	SET v_value = '1';
ELSE
	SET v_value = '0';
END IF;

RETURN v_value;   
END;

