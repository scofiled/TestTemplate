create function currvalSor(orgSorSeq varchar(50))
  returns int
  begin        
    declare value integer;         
    set value = 0;         
    select current_val into value  from seqMysql where seq_name = 'orgSorSeq';   
   return value;   
end;

