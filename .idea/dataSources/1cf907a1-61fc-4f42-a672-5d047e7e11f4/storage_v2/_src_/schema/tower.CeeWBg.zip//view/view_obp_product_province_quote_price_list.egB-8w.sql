create view view_obp_product_province_quote_price_list as
  select `a`.`prodbcatg_id`                    AS `prodbcatg_id`,
         `a`.`product_id`                      AS `product_id`,
         `b`.`supplier_code`                   AS `supplier_code`,
         `a`.`product_price`                   AS `product_price`,
         `a`.`tax_rate`                        AS `tax_rate`,
         `a`.`includ_tax_price`                AS `includ_tax_price`,
         `a`.`quote_area`                      AS `quote_area`,
         `a`.`area_code`                       AS `area_code`,
         ifnull(`c`.`p_area`, `a`.`area_code`) AS `province_code`
  from ((`tower`.`obp_oth_supplier_quote_prov` `a`
      join `tower`.`obp_supplier_base_info` `b`) left join `tower`.`view_org_area` `c` on ((`a`.`area_code` =
                                                                                            `c`.`c_orgcode`)))
  where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = '1'));

