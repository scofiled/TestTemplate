create procedure p_update_supplier_quote_view(IN prodBcatg varchar(5), IN taskType varchar(5), OUT flag int)
  BEGIN

DECLARE is_end INT DEFAULT 0;


DECLARE task_id INT DEFAULT 0;

DECLARE v_delete_sql VARCHAR (2560) DEFAULT '';

DECLARE v_insert_sql VARCHAR (2560) DEFAULT '';

DECLARE c_update_task CURSOR FOR SELECT
	a.id,
	a.delete_sql,
	a.insert_sql
FROM
	obp_quote_audit_task a
WHERE
	a.type = taskType
AND a.prodBcatg LIKE CONCAT(
	'%',
	prodBcatg,
	'%'
)
ORDER BY
	a.step;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET is_end = 1;

DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
 set flag=task_id;
SELECT CONCAT(flag, '--SQLEXCEPTION');
END;

SET flag=-1;
SET @prodBcatg = prodBcatg;

START TRANSACTION;

OPEN c_update_task;



REPEAT

 set flag=flag+1;
	FETCH c_update_task INTO task_id,v_delete_sql,v_insert_sql;
	 IF (is_end<>1) then  
	SELECT task_id;
  set flag=task_id;
	IF (v_delete_sql <> ''AND v_delete_sql IS NOT NULL) THEN

	SET @sqlstr = v_delete_sql;
	select @sqlstr;
	PREPARE stmt FROM @sqlstr;

	EXECUTE stmt USING @prodBcatg;

	DEALLOCATE PREPARE stmt;

	END IF;

	IF (v_insert_sql <> '' AND v_insert_sql IS NOT NULL) THEN

	SET @sqlstr = v_insert_sql;
	select @sqlstr;
	PREPARE stmt FROM 	@sqlstr;

	EXECUTE stmt USING @prodBcatg;

	DEALLOCATE PREPARE stmt;

	END IF;

END IF;
 UNTIL is_end=1 END REPEAT;
	

CLOSE c_update_task;

COMMIT;
IF(flag>0)then
SET flag = 999;
END IF;
END;

