create view wfbiz_caleparti_view as
  select `a`.`PARTICALEUUID` AS `PARTICALEUUID`,
         `a`.`PARTITYPE`     AS `PARTITYPE`,
         `a`.`PARTIID`       AS `PARTIID`,
         `a`.`PARTINAME`     AS `PARTINAME`,
         `a`.`CALENDARUUID`  AS `CALENDARUUID`,
         `a`.`CALETYPE`      AS `CALETYPE`,
         `a`.`UPTTIME`       AS `UPTTIME`,
         `b`.`tenant_id`     AS `tenant_id`,
         `b`.`CALENDARNAME`  AS `CALENDARNAME`
  from (`tower`.`wfbiz_caleparti_relation` `a`
      join `tower`.`wfbiz_calendar_info` `b`)
  where (`a`.`CALENDARUUID` = `b`.`CALENDARUUID`);

