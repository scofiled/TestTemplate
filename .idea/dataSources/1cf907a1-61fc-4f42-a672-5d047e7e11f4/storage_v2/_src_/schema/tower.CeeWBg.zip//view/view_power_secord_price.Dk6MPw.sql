create view view_power_secord_price as
  select distinct `d`.`product_price` AS `product_price`, `b`.`product_id` AS `product_id`
  from (`tower`.`obp_oth_supplier_quote` `d`
      join `tower`.`obp_oth_quote_model` `b`)
  where ((`d`.`product_id` = `b`.`product_id`) and (`d`.`prodbcatg_id` = `b`.`prodbcatg_id`) and
         (`d`.`quote_id` = `b`.`quote_id`) and (`d`.`status` = '1'))
  order by `b`.`product_id`, `d`.`product_price` desc;

