create function f_getsupplier_cerinfo_das_zizhi(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                                v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);

  set cer_info_html='';
set cer_info_temp='';
SELECT '<br>相关资质：<br>' into cer_info_temp;
 set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';
select CONCAT('工程勘察专业类工程测量(通信测量)资质等级：',a.grade,' 证书编号：', a.cer_code,'  有效日期：' ,a.cer_date,'<br>')  
into cer_info_temp from obp_design_supervisor_aptitude a 
where a.product_base_info_code=v_base_info_code and a.product_big_type=v_product_big_type
and a.cer_type='comMeasure' ;
set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';  



 select CONCAT('电子通信广电行业资质(有线专业)等级：',a.grade,' 证书编号：', a.cer_code,'  有效日期：' ,a.cer_date,'<br>')  
into cer_info_temp from obp_design_supervisor_aptitude a 
where a.product_base_info_code=v_base_info_code and a.product_big_type=v_product_big_type
and a.cer_type='wire' ;
set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';  



 select CONCAT('电子通信广电行业资质(无线专业)等级：',a.grade,' 证书编号：', a.cer_code,'  有效日期：', a.cer_date,'<br>')  
into cer_info_temp from obp_design_supervisor_aptitude a 
where a.product_base_info_code=v_base_info_code and a.product_big_type=v_product_big_type
and a.cer_type='wireless' ;
set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';  



 select CONCAT('电子通信广电行业资质(铁塔专业)等级：',a.grade,' 证书编号：', a.cer_code,'  有效日期：' ,a.cer_date,'<br>')  
into cer_info_temp from obp_design_supervisor_aptitude a 
where a.product_base_info_code=v_base_info_code and a.product_big_type=v_product_big_type
and a.cer_type='TD' ;
set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';  



 select CONCAT('建筑行业(建筑工程)专业等级：',a.grade,' 证书编号：', a.cer_code,'  有效日期：' ,a.cer_date,'<br>')  
into cer_info_temp from obp_design_supervisor_aptitude a 
where a.product_base_info_code=v_base_info_code and a.product_big_type=v_product_big_type
and a.cer_type='TDRoom' ;
set cer_info_html=CONCAT(cer_info_html,IFNULL(cer_info_temp,''));
	 set cer_info_temp='';  


  RETURN cer_info_html;
END;

