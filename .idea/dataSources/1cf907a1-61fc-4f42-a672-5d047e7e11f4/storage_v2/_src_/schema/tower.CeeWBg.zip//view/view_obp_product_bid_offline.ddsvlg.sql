create view view_obp_product_bid_offline as
  select `b`.`product_specification_name`                                                                          AS `NAME`,
         ''                                                                                                        AS `goods_no`,
         `b`.`supplier_code`                                                                                       AS `supplier_code`,
         `c`.`no_added_tax_price`                                                                                  AS `sell_price`,
         `c`.`tax_price`                                                                                           AS `market_price`,
         `b`.`product_describe`                                                                                    AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `b`.`metering_unit`)))                                                           AS `unit_name`,
         `a`.`generic_brand`                                                                                       AS `brand_name`,
         ''                                                                                                        AS `spec_array`,
         ''                                                                                                        AS `catagory_id`,
         ''                                                                                                        AS `latest`,
         ''                                                                                                        AS `bargainPrice`,
         ''                                                                                                        AS `recommend`,
         ''                                                                                                        AS `hot`,
         `b`.`material_code`                                                                                       AS `material_code`,
         ''                                                                                                        AS `stock_cycle`,
         '1'                                                                                                       AS `minbuy_num`,
         '1'                                                                                                       AS `pack_num`,
         ''                                                                                                        AS `prd_model`,
         ''                                                                                                        AS `goodsType`,
         ''                                                                                                        AS `mainSku`,
         ''                                                                                                        AS `versionName`,
         '-1'                                                                                                      AS `weight`,
         (select `t`.`code`
          from `tower`.`obp_prd_min_type` `t`
          where (`t`.`id` = `b`.`product_specification_id`))                                                       AS `prd_param`,
         ''                                                                                                        AS `wareQD`,
         `c`.`tax_price`                                                                                           AS `company_price`,
         `c`.`added_tax_kuan`                                                                                      AS `tax_price`,
         (select `t`.`col2`
          from `tower`.`obp_tax` `t`
          where (`t`.`tax_rate` = cast(`a`.`added_value_tax_rate` as signed)))                                     AS `tax_rate`,
         ifnull(`a`.`max_supply_capacity`, -(1))                                                                   AS `max_supply_capacity`,
         ''                                                                                                        AS `alert_supply_capacity`,
         ''                                                                                                        AS `extreme_supply_capacity`,
         '-1'                                                                                                      AS `install_rate`,
         '-1'                                                                                                      AS `use_install_rate`,
         '-1'                                                                                                      AS `use_freight_rate`,
         '-1'                                                                                                      AS `freight_price`,
         '-1'                                                                                                      AS `Price_star`,
         '-1'                                                                                                      AS `Price_mark`,
         '-1'                                                                                                      AS `Service_star`,
         '-1'                                                                                                      AS `Service_mark`,
         '-1'                                                                                                      AS `Quality_star`,
         '-1'                                                                                                      AS `Quality_mark`,
         `d`.`application_no`                                                                                      AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type` `l`
          where (`l`.`id` = `a`.`product_big_type`))                                                               AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type` `l`
              join `tower`.`obp_prd_min_type` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `b`.`product_specification_id`)))                                                     AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type` `m`
          where (`m`.`id` = `b`.`product_specification_id`))                                                       AS `Small_code`
  from (((`tower`.`obp_prd_base_info` `a`
      join `tower`.`obp_prd_min_info` `b`) join `tower`.`obp_printer_product_quote` `c`) join `tower`.`obp_supplier_access_agreement` `d`)
  where ((`a`.`product_big_type` = '98') and (`a`.`product_big_type` = `b`.`product_big_type`) and
         (`a`.`base_info_status` = '3') and (`a`.`supplier_id` = `b`.`supplier_id`) and
         (`a`.`product_base_info_code` = `b`.`product_base_info_code`) and (`b`.`status` = '1') and
         (`a`.`product_big_type` = `c`.`product_big_type`) and (`a`.`supplier_id` = `c`.`supplier_id`) and
         (`c`.`product_id` = `b`.`product_specification_id`) and (`a`.`supplier_id` = `d`.`supplier_id`) and
         (`a`.`product_big_type` = `d`.`prod_bctg`) and (`d`.`state` = '1') and (`c`.`status` = '0'));

