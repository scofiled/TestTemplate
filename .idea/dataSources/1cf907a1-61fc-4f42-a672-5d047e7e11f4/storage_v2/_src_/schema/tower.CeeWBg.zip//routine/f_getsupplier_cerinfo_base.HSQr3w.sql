create function f_getsupplier_cerinfo_base(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                           v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN

  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  
  set cer_info_temp='';
	set cer_info_html='';

  SELECT CONCAT('<p>','基础信息','</p>','<br>'
                ,'公司名称: ',a.org_name,'<br>'
								,'注册地址所属省份: ',(select b.`name` from obp_province b where b.code=a.province_code),'<br>'								 ,'注册地址所属地市: ',(select c.`name` from obp_city c where c.code=a.city_code),'<br>'
								,'注册资金(万元)：',register_money,'<br>'
								,'公司固话: ',a.contacter_Tel,'<br>'
                ) 
  into cer_info_temp

 from obp_supplier_base_info a
  
  where a.id=v_supplier_id ;

   set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	 set cer_info_temp='';




  RETURN cer_info_html;
END;

