create view view_obp_provsupplier as select `a`.`supplier_code`    AS `supplier_code`,
                                            `p`.`code`             AS `prov_code`,
                                            `b`.`product_big_type` AS `protype_code`,
                                            1                      AS `sort`
                                     from ((`tower`.`obp_prd_base_info` `b`
                                         join `tower`.`obp_supplier_base_info` `a`) join `tower`.`obp_province` `p`)
                                     where ((`b`.`product_big_type` in ('97', '98')) and
                                            (`b`.`supplier_code` = `a`.`supplier_code`) and (`a`.`status` = '1') and
                                            (find_in_set(`p`.`code`, `b`.`supply_province_id`) > 0) and exists(select 1
                                                                                                               from `tower`.`obp_supplier_access_agreement` `ag`
                                                                                                               where ((`a`.`id` = `ag`.`supplier_id`) and
                                                                                                                      (`ag`.`prod_bctg` = `b`.`product_big_type`) and
                                                                                                                      (`ag`.`state` = '1'))))
                                     union all select distinct `a`.`supplier_code`    AS `supplier_code`,
                                                               `p`.`code`             AS `prov_code`,
                                                               `b`.`product_big_type` AS `protype_code`,
                                                               1                      AS `sort`
                                               from (((`tower`.`obp_prd_base_info` `b`
                                                   join `tower`.`obp_supplier_base_info` `a`) join `tower`.`obp_province` `p`) join `tower`.`obp_product_supply_province` `c`)
                                               where ((`b`.`product_big_type` in ('56', '64', '54', '67')) and
                                                      (`b`.`supplier_id` = `a`.`id`) and (`a`.`status` = '1') and
                                                      (`b`.`product_base_info_code` = `c`.`product_base_info_code`) and
                                                      (`p`.`code` = `c`.`supply_province`) and exists(select 1
                                                                                                      from `tower`.`obp_supplier_access_agreement` `ag`
                                                                                                      where ((`a`.`id` = `ag`.`supplier_id`) and
                                                                                                             (`ag`.`prod_bctg` = `b`.`product_big_type`) and
                                                                                                             (`ag`.`state` = '1'))))
                                     union all select distinct `a`.`supplier_code` AS `supplier_code`,
                                                               `b`.`province_code` AS `prov_code`,
                                                               `b`.`product_btype` AS `protype_code`,
                                                               (`b`.`col4` + 0)    AS `sort`
                                               from (`tower`.`obp_supplier_base_info` `a`
                                                   join `tower`.`obp_product_score_result` `b`)
                                               where ((`b`.`product_btype` = '58') and
                                                      (`b`.`supplier_id` = `a`.`id`) and exists(select 1
                                                                                                from `tower`.`obp_supplier_access_agreement` `ag`
                                                                                                where ((`a`.`id` = `ag`.`supplier_id`) and
                                                                                                       (`ag`.`prod_bctg` = `b`.`product_btype`) and
                                                                                                       (`ag`.`state` = '1'))))
                                     union all select distinct `a`.`supplier_code`    AS `supplier_code`,
                                                               `p`.`code`             AS `prov_code`,
                                                               `b`.`product_big_type` AS `protype_code`,
                                                               1                      AS `sort`
                                               from (((`tower`.`obp_prd_base_info` `b`
                                                   join `tower`.`obp_supplier_base_info` `a`) join `tower`.`obp_province` `p`) join `tower`.`obp_product_supply_province` `c`)
                                               where ((`b`.`product_big_type` = '62') and
                                                      (`b`.`supplier_id` = `a`.`id`) and (`b`.`supplier_id` in (
                                                   'ff8080815cd04745015cd3fc632b21ff',
                                                   'ff8080814fd357d0014fe31a6def0607',
                                                   'ff8080815df068b9015e04062b4f22b5',
                                                   'ff8080816109341a01612c8f3e4931d2',
                                                   'ff8080814e89e765014e9389d7700823',
                                                   'ff808081570a6da501570ce03a036d1c',
                                                   'ff8080814fd357d0014fe3159d410604')) and (`a`.`status` = '1') and
                                                      (`b`.`product_base_info_code` = `c`.`product_base_info_code`) and
                                                      (`p`.`code` = `c`.`supply_province`) and exists(select 1
                                                                                                      from `tower`.`obp_supplier_access_agreement` `ag`
                                                                                                      where ((`a`.`id` = `ag`.`supplier_id`) and
                                                                                                             (`ag`.`prod_bctg` = `b`.`product_big_type`) and
                                                                                                             (`ag`.`state` = '1'))));

