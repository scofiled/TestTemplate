create function f_getsupplier_cerinfo_38_53(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                            v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN
   
  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
	set cer_info_html='';
	SET cer_info_temp = '';
    SELECT CONCAT('<p>','综合信息','</p>','<br>'
                ,'创新专栏: ',IFNULL(z.cxzl,''),'<br>'

								,'基本保证产能(个)/30天: ',z.jbcn,'<br>'
								,'基本保证产能可上浮比例(%): ',z.cnbl,'<br>'
								,'产能(30天)上限比例(%): ',z.sxbl,'<br>'
								,'选择供应区域: ',z.ghqy,'<br>'
                ) 
  into cer_info_temp FROM 
(SELECT a.innovate_column as cxzl,

a.base_capacity AS jbcn,
a.upper_rate as cnbl,
a.max_supply_capacity as sxbl,
(select GROUP_CONCAT(p.supply_provinces_name) from obp_prd_factory_info p where p.product_base_info_code=a.product_base_info_code)
as ghqy
 FROM obp_prd_base_info  a 
WHERE 
a.product_big_type =v_product_big_type
AND a.product_base_info_code = v_base_info_code )z;

  set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	SET cer_info_temp = '';

  RETURN cer_info_html;
END;

