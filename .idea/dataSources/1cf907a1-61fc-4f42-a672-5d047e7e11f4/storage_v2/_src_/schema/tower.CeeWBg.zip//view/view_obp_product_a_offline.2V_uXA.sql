create view view_obp_product_a_offline as
  select `a`.`product_specification_name`                                                                          AS `NAME`,
         ''                                                                                                        AS `goods_no`,
         `b`.`supplier_code`                                                                                       AS `supplier_code`,
         0                                                                                                         AS `sell_price`,
         0                                                                                                         AS `market_price`,
         `a`.`product_describe`                                                                                    AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `a`.`metering_unit`)))                                                           AS `unit_name`,
         `c`.`generic_brand`                                                                                       AS `brand_name`,
         ''                                                                                                        AS `spec_array`,
         ''                                                                                                        AS `catagory_id`,
         ''                                                                                                        AS `latest`,
         ''                                                                                                        AS `bargainPrice`,
         ''                                                                                                        AS `recommend`,
         ''                                                                                                        AS `hot`,
         `a`.`material_code`                                                                                       AS `material_code`,
         `a`.`supplier_product_code`                                                                               AS `supplier_product_code`,
         ''                                                                                                        AS `stock_cycle`,
         -(1)                                                                                                      AS `minbuy_num`,
         -(1)                                                                                                      AS `pack_num`,
         ''                                                                                                        AS `prd_model`,
         ''                                                                                                        AS `goodsType`,
         ''                                                                                                        AS `mainSku`,
         ''                                                                                                        AS `versionName`,
         if(((`a`.`product_weight` = 0) or isnull(`a`.`product_weight`)), 0,
            `a`.`product_weight`)                                                                                  AS `weight`,
         (select `d`.`code`
          from `tower`.`obp_prd_min_type` `d`
          where (`d`.`id` = `a`.`product_specification_id`))                                                       AS `prd_param`,
         ''                                                                                                        AS `wareQD`,
         ''                                                                                                        AS `company_price`,
         ''                                                                                                        AS `tax_price`,
         (select `t`.`col2`
          from `tower`.`obp_tax` `t`
          where (`t`.`tax_rate` = cast(`c`.`added_value_tax_rate` as signed)))                                     AS `tax_rate`,
         `c`.`max_supply_capacity`                                                                                 AS `max_supply_capacity`,
         ''                                                                                                        AS `alert_supply_capacity`,
         ''                                                                                                        AS `extreme_supply_capacity`,
         ''                                                                                                        AS `install_rate`,
         ''                                                                                                        AS `use_install_rate`,
         ''                                                                                                        AS `use_freight_rate`,
         ''                                                                                                        AS `freight_price`,
         -(1)                                                                                                      AS `Price_star`,
         '-1'                                                                                                      AS `Price_mark`,
         '-1'                                                                                                      AS `Service_star`,
         '-1'                                                                                                      AS `Service_mark`,
         '-1'                                                                                                      AS `Quality_star`,
         '-1'                                                                                                      AS `Quality_mark`,
         '-1'                                                                                                      AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type` `l`
          where (`l`.`id` = `c`.`product_big_type_code`))                                                          AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type` `l`
              join `tower`.`obp_prd_min_type` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `a`.`product_specification_id`)))                                                     AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type` `m`
          where (`m`.`id` = `a`.`product_specification_id`))                                                       AS `Small_code`,
         NULL                                                                                                      AS `debug_service_fee`,
         NULL                                                                                                      AS `guide_service_fee`
  from ((`tower`.`obp_prd_min_info_new` `a`
      join `tower`.`view_obp_virtual_all` `b`) join `tower`.`obp_prd_base_info` `c`)
  where ((`a`.`supplier_id` = `b`.`id`) and (`c`.`supplier_id` = `a`.`supplier_id`) and
         (`c`.`product_big_type_code` = `a`.`product_big_type`) and
         (`c`.`product_base_info_code` = `a`.`product_base_info_code`) and (`c`.`base_info_status` = '3') and
         (`c`.`product_big_type_code` like 'A%') and (`a`.`status` = '1'));

