create view view_obp_cable_fee_fsds_offline_new as select `b`.`supplier_code` AS `supplier_code`,
                                                          `a`.`from_addr`     AS `from_addr`,
                                                          `a`.`to_addr`       AS `to_addr`,
                                                          `a`.`freight_rate`  AS `fee_rate`,
                                                          `c`.`prodbcatg_id`  AS `protype_code`,
                                                          `c`.`scheme_id`     AS `scheme_id`
                                                   from `tower`.`obp_trans_dispri` `a`
                                                          join `tower`.`obp_supplier_base_info` `b`
                                                          join `tower`.`view_obp_quote_rule` `c`
                                                          join `tower`.`obp_prod_aut_scheme` `s`
                                                   where ((`a`.`quote_id` = `c`.`quote_id`) and
                                                          (`a`.`supplier_id` = `b`.`id`) and
                                                          (`c`.`scheme_id` = `s`.`id`) and
                                                          (`s`.`org_code` <> '100001') and
                                                          (`s`.`aut_type` = 'PRODUCT') and (`a`.`to_addr` not in (
                                                       '110000',
                                                       '120000',
                                                       '310000',
                                                       '500000')))
                                                   union select `b`.`supplier_code` AS `supplier_code`,
                                                                `a`.`from_addr`     AS `from_addr`,
                                                                `d`.`code`          AS `to_addr`,
                                                                `a`.`freight_rate`  AS `fee_rate`,
                                                                `c`.`prodbcatg_id`  AS `protype_code`,
                                                                `c`.`scheme_id`     AS `scheme_id`
                                                         from `tower`.`obp_trans_dispri` `a`
                                                                join `tower`.`obp_supplier_base_info` `b`
                                                                join `tower`.`view_obp_quote_rule` `c`
                                                                join `tower`.`obp_city` `d`
                                                                join `tower`.`obp_prod_aut_scheme` `s`
                                                         where ((`a`.`quote_id` = `c`.`quote_id`) and
                                                                (`a`.`supplier_id` = `b`.`id`) and
                                                                (`a`.`to_addr` = `d`.`p_code`) and
                                                                (`c`.`scheme_id` = `s`.`id`) and
                                                                (`s`.`org_code` <> '100001') and
                                                                (`s`.`aut_type` = 'PRODUCT') and (`a`.`to_addr` in (
                                                             '110000',
                                                             '120000',
                                                             '310000',
                                                             '500000')));

