create view view_report_settle_tower_rmcheck as
  select `c`.`prdcodes`                         AS `prdcodes`,
         `c`.`prdnames`                         AS `prdnames`,
         (case `t`.`isTaxPay`
            when '1' then `t`.`ticketCode`
            when '0' then `t`.`mergOrg` end)    AS `orgcodes`,
         sum(`d`.`PayAmount`)                   AS `amount`,
         date_format(`c`.`create_time`, '%Y%m') AS `months`
  from ((`tower`.`obp_settle_check_rm` `c`
      join `tower`.`obp_settle_check_rm_detail` `d`) join `tower`.`obp_settle_ticket_information` `t`)
  where ((`c`.`prdcodes` <> '1') and (`c`.`prdcodes` <> '2') and ((`c`.`status` = '2') or (`c`.`status` = '3')) and
         ((`c`.`process_inst_status` = '1') or (`c`.`process_inst_status` = '2')) and
         (`c`.`CheckRMCode` = `d`.`CheckRMCode`) and (`c`.`OrgCode` = `t`.`ticketCode`) and (`t`.`goods_type` = '2'))
  group by `c`.`prdcodes`, (case `t`.`isTaxPay`
                              when '1' then `t`.`ticketCode`
                              when '0' then `t`.`mergOrg` end), date_format(`c`.`create_time`, '%Y%m');

