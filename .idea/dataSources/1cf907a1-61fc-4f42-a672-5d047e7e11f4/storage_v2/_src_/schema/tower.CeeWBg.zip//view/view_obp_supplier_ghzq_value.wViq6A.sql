create view view_obp_supplier_ghzq_value as
  select `b`.`com_id`                  AS `com_id`,
         `b`.`supplier_id`             AS `supplier_id`,
         `b`.`rule_id`                 AS `rule_id`,
         (case `a`.`value_type`
            when '0A' then `c`.`rule_value_desc`
            else `b`.`rule_value` end) AS `rule_value`
  from ((`tower`.`obp_cer_rule` `a`
      join `tower`.`obp_cer_score_inst_info` `b` on ((`a`.`rule_id` =
                                                      `b`.`rule_id`))) left join `tower`.`obp_cer_rule_value` `c` on ((
    (`a`.`rule_id` = `c`.`rule_id`) and (`b`.`rule_value` = `c`.`rule_value`))))
  where (`a`.`column_2` = 1);

