create view view_obp_supplier_prod_certificate_validity as
  select `sb`.`id`                  AS `id`,
         `sb`.`supplier_code`       AS `supplier_code`,
         `sb`.`org_name`            AS `org_name`,
         `b`.`scheme_id`            AS `scheme_id`,
         `c`.`certificate_name`     AS `certificate_name`,
         `c`.`certificate_code`     AS `certificate_code`,
         `c`.`certificate_validity` AS `certificate_validity`
  from `tower`.`obp_supplier_prod_base_info` `b`
         join `tower`.`obp_supplier_prod_certificate` `c`
         join `tower`.`obp_supplier_base_info` `sb`
         join `tower`.`obp_prod_aut_certificate` `ac`
  where ((`b`.`process_inst_status` <> 'S0') and (`c`.`scheme_id` = `b`.`scheme_id`) and
         (`c`.`supplier_id` = `b`.`supplier_id`) and (`c`.`base_code` = `b`.`base_code`) and
         (`b`.`supplier_id` = `sb`.`id`) and (curdate() > `c`.`certificate_validity`) and
         (`ac`.`scheme_id` = `c`.`scheme_id`) and (`ac`.`id` = `c`.`certificate_id`) and
         (`c`.`certificate_validity` = '1') and (`c`.`state` = '1'));

