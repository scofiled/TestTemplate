create view view_obp_citych_rpt_taskcheckinfo as
  select `a`.`task_id`        AS `task_id`,
         `c`.`area_code`      AS `area_code`,
         `c`.`ch_supplier_id` AS `ch_supplier_id`,
         `b`.`total_score`    AS `total_score`,
         `b`.`total_sort`     AS `total_sort`,
         `b`.`qua_score`      AS `qua_score`,
         `b`.`service_score`  AS `service_score`,
         `b`.`price_score`    AS `price_score`
  from ((`tower`.`obp_ch_city_task` `a`
      join `tower`.`obp_citych_access_record` `b`) join `tower`.`obp_citych_score_result` `c`)
  where ((`a`.`task_id` = `b`.`task_id`) and (`a`.`task_id` = `c`.`task_id`) and
         (`b`.`ch_supplier_id` = `c`.`ch_supplier_id`) and (`c`.`is_in` = '1'));

