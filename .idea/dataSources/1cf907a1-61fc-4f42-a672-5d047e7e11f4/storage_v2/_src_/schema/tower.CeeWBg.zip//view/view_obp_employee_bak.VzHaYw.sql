create view view_obp_employee_bak as
  select `view_obp_employee`.`uid`             AS `uid`,
         `view_obp_employee`.`cn`              AS `cn`,
         `view_obp_employee`.`cumail`          AS `cumail`,
         `view_obp_employee`.`ou`              AS `ou`,
         `view_obp_employee`.`OrgFullName`     AS `OrgFullName`,
         `view_obp_employee`.`site`            AS `site`,
         `view_obp_employee`.`cuCompanyNumber` AS `cuCompanyNumber`
  from `tower`.`view_obp_employee`;

