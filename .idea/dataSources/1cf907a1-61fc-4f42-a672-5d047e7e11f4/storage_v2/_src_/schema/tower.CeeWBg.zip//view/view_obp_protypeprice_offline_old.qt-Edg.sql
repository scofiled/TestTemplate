create view view_obp_protypeprice_offline_old as
  select `view_obp_protypeprice_offline`.`province_code` AS `province_code`,
         `view_obp_protypeprice_offline`.`protype_code`  AS `protype_code`,
         `view_obp_protypeprice_offline`.`supplier_code` AS `supplier_code`,
         `view_obp_protypeprice_offline`.`Price_mark`    AS `Price_mark`,
         `view_obp_protypeprice_offline`.`Price_star`    AS `Price_star`,
         `view_obp_protypeprice_offline`.`Service_mark`  AS `Service_mark`,
         `view_obp_protypeprice_offline`.`Service_star`  AS `Service_star`,
         `view_obp_protypeprice_offline`.`Quality_mark`  AS `Quality_mark`,
         `view_obp_protypeprice_offline`.`Quality_star`  AS `Quality_star`
  from `tower`.`view_obp_protypeprice_offline`;

