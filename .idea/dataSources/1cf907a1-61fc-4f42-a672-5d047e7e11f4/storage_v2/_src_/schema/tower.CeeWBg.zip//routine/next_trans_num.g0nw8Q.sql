create function next_trans_num(seq_name varchar(256))
  returns int
  begin
 UPDATE obp_sequence SET value=last_insert_id(value+next) WHERE name=seq_name;
 RETURN last_insert_id();
end;

