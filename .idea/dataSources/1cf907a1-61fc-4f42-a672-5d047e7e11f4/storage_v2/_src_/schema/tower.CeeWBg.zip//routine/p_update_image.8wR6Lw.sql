create procedure p_update_image()
  BEGIN
	#Routine body goes here...
INSERT INTO view_obp_product_images(`material_code`, `path`, `sort`, `isPrimary`)
 select `material_code`, `path`, 1, `isPrimary` from view_obp_oth_product_images_offline a
where not EXISTS (

select 1 from view_obp_product_images b where a.material_code=b.material_code
);

INSERT INTO view_obp_product_images(`material_code`, `path`, `sort`, `isPrimary`)
 select `material_code`, `path`, 1, `isPrimary` from view_obp_product_images_offline a
where not EXISTS (

select 1 from view_obp_product_images b where a.material_code=b.material_code
);


INSERT INTO view_obp_product_images(`material_code`, `path`, `sort`, `isPrimary`)
 select `material_code`, `path`, 1, `isPrimary` from view_obp_product_images_a_offline a
where not EXISTS (

select 1 from view_obp_product_images b where a.material_code=b.material_code
);

END;

