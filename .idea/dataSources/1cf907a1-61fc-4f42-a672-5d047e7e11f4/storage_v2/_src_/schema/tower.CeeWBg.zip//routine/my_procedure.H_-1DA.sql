create procedure my_procedure()
  begin -- 开始存储过程  
declare flowid2 varchar(100); -- 自定义变量1 
declare aaa int DEFAULT 12;
DECLARE done INT DEFAULT FALSE; -- 自定义控制游标循环变量,默认false  
  
DECLARE My_Cursor CURSOR FOR (select workItemID as cc from towerbak.temp_oa_un_02 ); -- 定义游标并输入结果集  
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 绑定控制变量到游标,游标循环结束自动转true  
  
OPEN My_Cursor; -- 打开游标  
  myLoop: LOOP -- 开始循环体,myLoop为自定义循环名,结束循环时用到  
    FETCH My_Cursor into flowid2; -- 将游标当前读取行的数据顺序赋予自定义变量12  
    select flowid2;
    IF done THEN -- 判断是否继续循环  
      LEAVE myLoop; -- 结束循环  
    END IF;  
    -- 自己要做的事情,在 sql 中直接使用自定义变量即可  
   insert into towerbak.oa_import   select  
        DISTINCT
	    'CHNTAP' 							as syscode,
	  	b.workItemID 	  	    		    as flowid,
	 	IFNULL(b.processInstName,b.catalogName)          
											as workflowname, 
	    COALESCE(b.catalogName,b.processInstName,b.catalogName)        			    
	    									as requestname ,
	    b.workItemName 		   				as nodename,
	    CONCAT('?workitemID=',b.workItemID) 					    			as pcurl,
	    '' 					    			as appurl,
	    IFNULL((select g.EMPCODE from WFProcessInst d,org_employee g 
						where 
							d.processInstID=b.processInstID
						and g.EMPID=(case when d.creator='sysadmin' || d.creator like 'S%' ||d.creator like 's%' then null else d.creator end )
            and d.creator not like 'S%'
            and d.creator not like 's%'
	                  ),'topSysadmin')         
										    as creator,
		  (select DATE_FORMAT(d.createTime,'%Y-%m-%d %H:%i:%s') from WFProcessInst d
							where 
				d.processInstID=b.processInstID
				)
		                        as createdatetime,
		  DATE_FORMAT(b.createTime,'%Y-%m-%d %H:%i:%s') 	        
											as receivedatetime,
         case when a.participantType='role' then 
					 (case when e.PARTY_TYPE='emp' 
										THEN (select f.EMPCODE from org_employee f where f.empid=e.PARTY_ID)
									else e.PARTY_ID
						end
						)
			else 
					c.EMPCODE    
			end  							as receiver
	from 
		 WFWorkItem b
	left join wfwiparticipant a
		on b.workItemID=a.workItemID
   left join org_employee c
		on (a.participantID=c.EMPID)
   left join cap_partyauth e
		on (a.participantID=e.ROLE_ID)
   where 
		  b.workItemID = flowid2;
  
    COMMIT; -- 提交事务  
  END LOOP myLoop; -- 结束自定义循环体  
  CLOSE My_Cursor; -- 关闭游标  
END;

