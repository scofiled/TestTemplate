create view la_temp_old as select `a`.`prov_code`        AS `prov_code`,
                                  `a`.`city_code`        AS `city_code`,
                                  `a`.`product_id`       AS `prd_min_code`,
                                  `a`.`prodbcatg_id`     AS `prd_type_code`,
                                  `b`.`supplier_code`    AS `supplier_code`,
                                  (`a`.`discount` / 100) AS `discount`,
                                  `c`.`application_no`   AS `contractCode`
                           from (((`tower`.`obp_oth_construct_product_quote` `a`
                               join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_supplier_access_agreement` `c`) join `tower`.`view_org_area` `d`)
                           where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`prodbcatg_id` = `c`.`prod_bctg`) and
                                  (`a`.`supplier_id` = `c`.`supplier_id`) and (`a`.`prov_code` = `d`.`p_area`) and
                                  (`d`.`c_orgcode` = `c`.`org_code`) and (`d`.`orgLevel` = 2) and
                                  (`c`.`state` = '1') and (`a`.`status` = '1'))
                           union all select `a`.`prov_code`        AS `prov_code`,
                                            `a`.`city_code`        AS `city_code`,
                                            `a`.`product_id`       AS `prd_min_code`,
                                            `a`.`prodbcatg_id`     AS `prd_type_code`,
                                            `b`.`supplier_code`    AS `supplier_code`,
                                            (`a`.`discount` / 100) AS `discount`,
                                            `c`.`application_no`   AS `contractCode`
                                     from (((`tower`.`obp_oth_construct_product_quote` `a`
                                         join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_supplier_access_agreement` `c`) join `tower`.`view_org_area` `d`)
                                     where ((`a`.`supplier_id` = `b`.`id`) and
                                            (`a`.`prodbcatg_id` = `c`.`prod_bctg`) and
                                            (`a`.`supplier_id` = `c`.`supplier_id`) and
                                            (`a`.`city_code` = `c`.`org_code`) and
                                            (`d`.`c_orgcode` = `c`.`org_code`) and (`d`.`orgLevel` = 3) and
                                            (`c`.`state` = '1') and (`a`.`status` = '1'));

