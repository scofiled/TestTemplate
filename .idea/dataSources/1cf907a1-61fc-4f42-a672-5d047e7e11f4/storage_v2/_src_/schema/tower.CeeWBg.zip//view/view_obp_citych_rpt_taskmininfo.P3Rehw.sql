create view view_obp_citych_rpt_taskmininfo as
  select `a`.`task_id` AS `task_id`, count(1) AS `min_cnt`
  from `tower`.`view_obp_citych_rpt_taskcheckinfo` `a`
         join `tower`.`view_obp_citych_rpt_taskscoreinfo` `b`
  where ((`a`.`task_id` = `b`.`task_id`) and (`a`.`total_score` = `b`.`min_total_score`) and
         (`a`.`price_score` = `b`.`min_price_score`) and (`b`.`min_price_score` <> `b`.`max_price_score`) and
         (`b`.`min_price_score` < 100))
  group by `a`.`task_id`;

