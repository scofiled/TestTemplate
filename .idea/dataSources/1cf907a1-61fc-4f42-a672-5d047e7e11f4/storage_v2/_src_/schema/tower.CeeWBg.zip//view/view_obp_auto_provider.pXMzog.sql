create view view_obp_auto_provider as
  select `a`.`province_code` AS `province_code`,
         `a`.`city_code`     AS `city_code`,
         `a`.`area_code`     AS `country_code`,
         `a`.`prod_bcatg`    AS `protype_code`,
         `b`.`supplier_code` AS `supplier_code`,
         `a`.`is_checked`    AS `is_checked`,
         `a`.`sort`          AS `sort`,
         `a`.`state`         AS `STATUS`,
         `a`.`task_id`       AS `rel_id`,
         `a`.`city_name`     AS `city_name`,
         `c`.`name`          AS `country_name`
  from (((`tower`.`obp_citych_score_result_online` `a`
      join `tower`.`obp_supplier_base_info` `b`) left join `tower`.`obp_mana_area` `c` on ((`a`.`area_code` =
                                                                                            `c`.`code`))) left join `tower`.`obp_choose_config` `d` on ((
    (`a`.`city_code` = `d`.`city_org_code`) and (`a`.`prod_bcatg` = `d`.`prd_codes`))))
  where ((`a`.`ch_supplier_id` = `b`.`id`) and (`d`.`choose_type` = '2'));

