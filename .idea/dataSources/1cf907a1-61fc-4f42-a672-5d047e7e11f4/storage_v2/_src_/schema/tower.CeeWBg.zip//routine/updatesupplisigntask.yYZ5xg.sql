create procedure updateSuppliSignTask()
  BEGIN
		update obp_collect_supplier_sign set `status` = '2' where NOW() BETWEEN start_time and end_time;
		update obp_collect_supplier_sign set `status` = '3' where unix_timestamp(end_time) < unix_timestamp(NOW());
END;

