create function get_quote_model_product(v_type varchar(64))
  returns varchar(10)
  BEGIN

  DECLARE type VARCHAR(10) ;


  IF(v_type='discount' )then 
  set type='4910111';
  ELSEIF (v_type='survey')THEN
	
 set type='4910112';
  ELSE
		 set type='';
  END if;

  RETURN type;
END;

