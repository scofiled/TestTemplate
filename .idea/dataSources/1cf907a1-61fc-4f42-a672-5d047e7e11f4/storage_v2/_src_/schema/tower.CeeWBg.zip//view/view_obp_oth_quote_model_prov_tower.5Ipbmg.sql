create view view_obp_oth_quote_model_prov_tower as select `a`.`prodbcatg_id` AS `prodbcatg_id`,
                                                          `a`.`quote_id`     AS `quote_id`,
                                                          `a`.`product_num`  AS `product_num`,
                                                          `a`.`prod_weight`  AS `prod_weight`,
                                                          `a`.`product_id`   AS `product_id`,
                                                          `a`.`prov_code`    AS `prov_code`,
                                                          `b`.`non_weight`   AS `weight`,
                                                          `a`.`type`         AS `type`
                                                   from (`tower`.`obp_oth_quote_model_prov` `a`
                                                       join `tower`.`obp_non_standard_prd_weight` `b`)
                                                   where ((`a`.`type` = '2') and
                                                          (`a`.`prov_code` = `b`.`province_code`) and
                                                          (`a`.`product_id` = `b`.`product_scatg_id`))
                                                   union all select `a`.`prodbcatg_id` AS `prodbcatg_id`,
                                                                    `a`.`quote_id`     AS `quote_id`,
                                                                    `a`.`product_num`  AS `product_num`,
                                                                    `a`.`prod_weight`  AS `prod_weight`,
                                                                    `a`.`product_id`   AS `product_id`,
                                                                    `a`.`prov_code`    AS `prov_code`,
                                                                    `b`.`tower_weight` AS `weight`,
                                                                    `a`.`type`         AS `type`
                                                             from (`tower`.`obp_oth_quote_model_prov` `a`
                                                                 join `tower`.`obp_tower_weight` `b`)
                                                             where ((`a`.`type` = '1') and
                                                                    (`a`.`product_id` = `b`.`prd_spec_id`));

