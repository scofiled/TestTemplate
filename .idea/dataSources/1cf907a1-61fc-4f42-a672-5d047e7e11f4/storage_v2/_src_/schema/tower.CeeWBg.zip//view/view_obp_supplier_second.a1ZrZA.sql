create view view_obp_supplier_second as
  select distinct `e`.`USER_ID`                                           AS `user_id`,
                  `a`.`org_code`                                          AS `org_code`,
                  `a`.`org_name`                                          AS `org_name`,
                  `b`.`link_name`                                         AS `NAME`,
                  `a`.`contacter_Tel`                                     AS `contacter_Tel`,
                  `b`.`link_phone`                                        AS `phone`,
                  `a`.`remark`                                            AS `remark`,
                  `a`.`supplier_email`                                    AS `supplier_email`,
                  `a`.`address`                                           AS `address`,
                  ''                                                      AS `bankName`,
                  ''                                                      AS `bankUser`,
                  ''                                                      AS `bankNo`,
                  ''                                                      AS `lead_time`,
                  `a`.`supplier_code`                                     AS `supplier_code`,
                  `a`.`pay_taxes_type`                                    AS `pay_taxes_type`,
                  `a`.`taxes_num`                                         AS `taxes_num`,
                  `a`.`status`                                            AS `STATUS`,
                  `a`.`province_code`                                     AS `province_code`,
                  `a`.`city_code`                                         AS `city_code`,
                  concat(
                    'http://www.tower.com.cn/default/supplier/obpSupplierBaseInfo/ObpSupplierBaseInfoDetails1.jsp?userid=',
                    `a`.`supplier_code`, '&orgcode=', `a`.`org_code`, '') AS `Provider_url`,
                  `a`.`LEVEL`                                             AS `level`,
                  ''                                                      AS `parent_supplier_code`
  from (((`tower`.`obp_supplier_base_info` `a`
      join `tower`.`obp_cap_user_extend` `c`) join `tower`.`cap_user` `e`) left join `tower`.`obp_supplier_linkman_info` `b` on ((
    (`b`.`supplier_id` = `a`.`id`) and (`b`.`status` = '1'))))
  where ((`a`.`status` in ('1', '2')) and (`a`.`LEVEL` = 2) and (`a`.`id` = `c`.`supplier_id`) and
         (`c`.`operator_id` = `e`.`OPERATOR_ID`) and (not(exists(select 1
                                                                 from (`tower`.`obp_supplier_access_agreement` `d`
                                                                     join `tower`.`obp_supplier_base_info` `g`)
                                                                 where ((`a`.`p_supplier_id` = `g`.`id`) and
                                                                        (`g`.`id` = `d`.`supplier_id`) and
                                                                        (`d`.`prod_bctg` in ('46',
                                                                                             '47',
                                                                                             '48',
                                                                                             '49',
                                                                                             '56',
                                                                                             '98')))))));

