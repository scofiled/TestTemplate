create procedure p_use_last_supplier_quote(IN prodBcatg varchar(5), IN supplier_id varchar(32))
  BEGIN

DECLARE is_end INT DEFAULT 0;


DECLARE task_id INT DEFAULT 0;

DECLARE v_delete_sql VARCHAR (2560) DEFAULT '';

DECLARE v_insert_sql VARCHAR (2560) DEFAULT '';

DECLARE c_update_task CURSOR FOR SELECT
	a.id,
	a.delete_sql,
	a.insert_sql
FROM
	obp_quote_audit_task a
WHERE
	a.type = 'L'
AND a.prodBcatg LIKE CONCAT(
	'%',
	prodBcatg,
	'%'
)
ORDER BY
	a.step;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET is_end = 1;

DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SELECT '4232';
	ROLLBACK;

END;


SET @prodBcatg = prodBcatg;
SET @supplier_id = supplier_id;

START TRANSACTION;

OPEN c_update_task;



REPEAT

 
	FETCH c_update_task INTO task_id,v_delete_sql,v_insert_sql;
	 IF (is_end<>1) then  
	SELECT task_id;

	IF (v_delete_sql <> ''AND v_delete_sql IS NOT NULL) THEN

	SET @sqlstr = v_delete_sql;

	PREPARE stmt FROM @sqlstr;

	EXECUTE stmt USING @prodBcatg,@supplier_id;

	DEALLOCATE PREPARE stmt;

	END IF;

	IF (v_insert_sql <> '' AND v_insert_sql IS NOT NULL) THEN

	SET @sqlstr = v_insert_sql;
	
	PREPARE stmt FROM 	@sqlstr;

	EXECUTE stmt USING @prodBcatg,@supplier_id;


	DEALLOCATE PREPARE stmt;

	END IF;

END IF;
 UNTIL is_end=1 END REPEAT;
	

CLOSE c_update_task;

COMMIT;

END;

