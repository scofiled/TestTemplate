create view view_obp_cabinet_fee_32_37_offline as
  select `a`.`province_code` AS `province_code`,
         `a`.`prodbcatg_id`  AS `protype_code`,
         `b`.`supplier_code` AS `supplier_code`,
         `a`.`freight_rate`  AS `freight_fee_rate`
  from (((`tower`.`obp_oth_quote_prov_freight` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_oth_quote_rule` `d`)
  where ((`a`.`province_code` = `c`.`code`) and (`a`.`supplier_id` = `b`.`id`) and (`a`.`quote_id` = `d`.`quote_id`) and
         (`d`.`status` = 2) and (`a`.`status` = '1') and
         (`a`.`prodbcatg_id` in (32, 33, 34, 35, 36, 37, 51, 38, 53, 21, 22, 57, '68')));

