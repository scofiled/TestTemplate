create view view_obp_prd_quote_model as select `a`.`quote_id`     AS `quote_id`,
                                               `a`.`prodbcatg_id` AS `prodbcatg_id`,
                                               `a`.`product_id`   AS `product_id`,
                                               `a`.`prod_weight`  AS `prod_weight`,
                                               `a`.`is_score`     AS `is_score`,
                                               `a`.`prod_num`     AS `product_num`,
                                               `a`.`type`         AS `type`
                                        from `tower`.`obp_oth_quote_model` `a`
                                        union all select `a`.`quote_id`             AS `quote_id`,
                                                         `b`.`product_id`           AS `prodbcatg_id`,
                                                         `a`.`product_scatg_id`     AS `product_id`,
                                                         `a`.`product_scatg_weight` AS `prod_weight`,
                                                         `a`.`col3`                 AS `is_score`,
                                                         1                          AS `product_num`,
                                                         '1'                        AS `type`
                                                  from (`tower`.`obp_tower_quote_model` `a`
                                                      join `tower`.`obp_parity_model` `b`)
                                                  where (`a`.`quote_id` = `b`.`id`)
                                        union all select `a`.`cabinet_id`     AS `quote_id`,
                                                         `b`.`product_id`     AS `prodbcatg_id`,
                                                         `a`.`product_id`     AS `product_id`,
                                                         `a`.`weight`         AS `prod_weight`,
                                                         `a`.`col1`           AS `is_score`,
                                                         `a`.`cabinet_number` AS `product_num`,
                                                         '1'                  AS `type`
                                                  from (`tower`.`obp_cabinet_model` `a`
                                                      join `tower`.`obp_parity_model` `b`)
                                                  where (`a`.`cabinet_id` = `b`.`id`);

