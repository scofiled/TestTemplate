create view view_obp_product_8_offline as
  select `d`.`name`                                                                                                AS `NAME`,
         ''                                                                                                        AS `goods_no`,
         `c`.`supplier_code`                                                                                       AS `supplier_code`,
         NULL                                                                                                      AS `standard_price`,
         concat(ifnull((select `b`.`content`
                        from `tower`.`obp_comp_desc` `b`
                        where (`a`.`product_specification_id` = `b`.`comp_id`)), ''),
                `a`.`product_describe`)                                                                            AS `content`,
         (select `en`.`DICTNAME`
          from `tower`.`eos_dict_entry` `en`
          where ((`en`.`DICTTYPEID` = 'OBP_MEASURE_UNIT') and
                 (`en`.`DICTID` = `a`.`metering_unit`)))                                                           AS `unit_name`,
         `b`.`generic_brand`                                                                                       AS `brand_name`,
         ''                                                                                                        AS `spec_array`,
         `a`.`material_code`                                                                                       AS `material_code`,
         ''                                                                                                        AS `tax_price`,
         (select `t`.`col2`
          from `tower`.`obp_tax` `t`
          where (`t`.`tax_rate` = cast(`b`.`added_value_tax_rate` as signed)))                                     AS `tax_rate`,
         NULL                                                                                                      AS `Service_star`,
         NULL                                                                                                      AS `Service_mark`,
         NULL                                                                                                      AS `Quality_star`,
         NULL                                                                                                      AS `Quality_mark`,
         NULL                                                                                                      AS `ContractCode`,
         (select `l`.`code`
          from `tower`.`obp_prd_type` `l`
          where (`l`.`id` = `b`.`product_big_type`))                                                               AS `protype_code`,
         (select `l`.`code`
          from (`tower`.`obp_prd_sub_type` `l`
              join `tower`.`obp_prd_min_type` `m`)
          where ((`m`.`parent_code` = `l`.`id`) and
                 (`m`.`id` = `a`.`product_specification_id`)))                                                     AS `Medium_code`,
         (select `m`.`code`
          from `tower`.`obp_prd_min_type` `m`
          where (`m`.`id` = `a`.`product_specification_id`))                                                       AS `Small_code`
  from (((`tower`.`obp_prd_min_info` `a`
      join `tower`.`obp_prd_base_info` `b`) join `tower`.`obp_supplier_base_info` `c`) join `tower`.`obp_prd_min_type` `d`)
  where ((`a`.`product_base_info_code` = `b`.`product_base_info_code`) and (`b`.`product_big_type` like '8%') and
         (`b`.`supplier_id` = `c`.`id`) and (`a`.`product_specification_id` = `d`.`id`));

