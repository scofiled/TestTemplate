create view view_obp_batteryex_ratio_offline as
  select `b`.`supplier_code` AS `supplier_code`,
         '01'                AS `fee_type`,
         `a`.`prodbcatg_id`  AS `protype_code`,
         `a`.`province_code` AS `province_code`,
         `a`.`fee_rate`      AS `fee_rate`
  from (`tower`.`obp_oth_ba_exchange_price` `a`
      join `tower`.`obp_supplier_base_info` `b`)
  where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = '1') and (`a`.`prodbcatg_id` in (30, 31, 55)));

