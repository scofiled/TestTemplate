create view view_obp_auto_maintenance_provider_new as select `a`.`province_code` AS `province_code`,
                                                             `a`.`org_code`      AS `city_code`,
                                                             `a`.`scheme_id`     AS `scheme_id`,
                                                             `c`.`supplier_code` AS `supplier_code`,
                                                             '1'                 AS `is_checked`,
                                                             `b`.`short_sort`    AS `sort`,
                                                             `a`.`task_state`    AS `STATUS`
                                                      from (`tower`.`obp_citych_access_record` `b`
                                                          join (`tower`.`obp_city_choose_task` `a`
                                                          join `tower`.`obp_supplier_base_info` `c`))
                                                      where ((`b`.`ch_supplier_id` = `c`.`id`) and
                                                             (`a`.`task_id` = `b`.`task_id`) and
                                                             (`a`.`task_state` = '400') and (`b`.`short_sort` = '1'))
                                                      union all select `f`.`province_code` AS `province_code`,
                                                                       `f`.`org_code`      AS `city_code`,
                                                                       `f`.`scheme_id`     AS `scheme_id`,
                                                                       `g`.`supplier_code` AS `supplier_code`,
                                                                       '1'                 AS `is_checked`,
                                                                       '1'                 AS `sort`,
                                                                       `f`.`task_state`    AS `STATUS`
                                                                from `tower`.`obp_ch_city_plan` `d`
                                                                       join `tower`.`obp_city_choose_task` `e`
                                                                       join `tower`.`obp_city_choose_result_online` `f`
                                                                       join `tower`.`obp_supplier_base_info` `g`
                                                                where ((`d`.`purchase_mode` = '0') and
                                                                       (`d`.`task_id` = `e`.`plan_id`) and
                                                                       (`e`.`task_state` = '400') and
                                                                       (`e`.`task_id` = `f`.`task_id`) and
                                                                       (`e`.`task_state` = `f`.`task_state`) and
                                                                       (`f`.`supplier_id` = `g`.`id`) and
                                                                       (`f`.`is_checked` = '1'))
                                                                group by `f`.`province_code`, `f`.`scheme_id`,
                                                                         `f`.`org_code`, `f`.`supplier_id`;

