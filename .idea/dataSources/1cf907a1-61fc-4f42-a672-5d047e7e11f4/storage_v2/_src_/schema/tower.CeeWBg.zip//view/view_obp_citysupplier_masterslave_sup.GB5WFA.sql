create view view_obp_citysupplier_masterslave_sup as
  select `a`.`supplier_code` AS `master_supplier_code`,
         `a`.`org_name`      AS `master_supplier_name`,
         `d`.`prod_bctg`     AS `protype_code`,
         `d`.`city_code`     AS `city_code`,
         `d`.`province_code` AS `province_code`,
         `c`.`supplier_code` AS `slave_supplier_code`,
         `c`.`org_name`      AS `slave_supplier_name`,
         `b`.`type`          AS `type`
  from (((`tower`.`obp_supplier_base_info` `a`
      join `tower`.`obp_sup_distributors_relation` `b`) join `tower`.`obp_supplier_base_info` `c`) join `tower`.`obp_sup_second_account_permission` `d`)
  where ((`a`.`id` = `b`.`p_supplier_id`) and (`c`.`id` = `b`.`distributors_supplier_id`) and (`b`.`status` = '1') and
         (`b`.`id` = `d`.`distributors_relation_id`) and (`d`.`status` = '00A'));

