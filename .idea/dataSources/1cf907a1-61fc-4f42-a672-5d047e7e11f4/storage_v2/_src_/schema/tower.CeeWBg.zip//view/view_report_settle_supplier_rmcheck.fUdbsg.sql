create view view_report_settle_supplier_rmcheck as
  select `c`.`prdcodes`                         AS `prdcodes`,
         `c`.`prdnames`                         AS `prdnames`,
         `c`.`SupplyCode`                       AS `SupplyCode`,
         `c`.`SupplyName`                       AS `SupplyName`,
         sum(`d`.`PayAmount`)                   AS `amount`,
         date_format(`c`.`create_time`, '%Y%m') AS `months`
  from (`tower`.`obp_settle_check_rm` `c`
      join `tower`.`obp_settle_check_rm_detail` `d`)
  where ((`c`.`prdcodes` <> '1') and (`c`.`prdcodes` <> '2') and ((`c`.`status` = '2') or (`c`.`status` = '3')) and
         ((`c`.`process_inst_status` = '1') or (`c`.`process_inst_status` = '2')) and
         (`c`.`CheckRMCode` = `d`.`CheckRMCode`))
  group by `c`.`prdcodes`, `c`.`SupplyCode`, date_format(`c`.`create_time`, '%Y%m');

