create view view_obp_city_choose_type as select distinct `a`.`province_code` AS `province_code`,
                                                         `a`.`city_code`     AS `city_code`,
                                                         `a`.`protype_code`  AS `protype_code`,
                                                         if((isnull(`a`.`country_code`) or (`a`.`country_code` = '')),
                                                            2, 1)            AS `flag`
                                         from `tower`.`view_obp_auto_provider` `a`
                                         union all select `d`.`p_area`        AS `province_code`,
                                                          `b`.`city_org_code` AS `city_code`,
                                                          `a`.`prd_codes`     AS `protype_code`,
                                                          `a`.`choose_type`   AS `flag`
                                                   from (((`tower`.`obp_choose_supplier_scheme` `a`
                                                       join `tower`.`obp_choose_area` `b` on ((`a`.`id` =
                                                                                               `b`.`scheme_id`))) join `tower`.`obp_choose_config` `c` on ((
                                                     (`b`.`city_org_code` = `c`.`city_org_code`) and (`a`.`prd_codes` =
                                                                                                      `c`.`prd_codes`)))) join `tower`.`view_org_area` `d` on ((
                                                     `b`.`prov_org_code` = `d`.`c_orgcode`)))
                                                   where ((`c`.`choose_type` = '1') and (`a`.`state` = '9') and
                                                          (`b`.`state` = '9'));

