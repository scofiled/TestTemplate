create procedure wfTransfer_upgrades_liangbing1(IN startDate varchar(32), IN endDate varchar(32))
  BEGIN
	declare total int(32) default 0;
	declare number int(32) default 0;
	declare size int(32) default 10000;
	declare start1 int(32) default 0;
	declare pageIndex int(32) default 0;
	declare msg text;
	declare v_desc varchar(512);
	select count(*) into total 
		FROM
			(
			SELECT
				m.`processInstID`,
				m.`processInstName`,
				m.`processDefName`,
				m.`activityInstID`,
				m.`activityInstName`,
				m.`activityDefID`,
				m.`workItemID`,
				m.`workItemName`,
				m.participant,
				IFNULL( d.EMPID, m.participant ) AS empid,
					d.EMPCODE,
					d.EMPNAME,
					d.ORGID,
					d.ORGNAME,
					d.ORGCODE,
						m.`currentState`,
					m.`createTime`,
					m.endTime,
			CASE
			
			WHEN d.empid IS NULL THEN
			1 ELSE 0 
			END AS is_supplier 		
			FROM
				wfworkitem m
				LEFT JOIN (
				SELECT
					a.EMPID ,
					a.EMPCODE,
					a.EMPNAME,
					c.ORGID,
					c.ORGNAME,
					c.ORGCODE 
				FROM
					org_employee a,
					org_emporg b,
					org_organization c 
				WHERE
					a.empid = b.EMPID 
					AND b.orgid = c.ORGID 
				) d ON m.participant = d.EMPID 
                where m.workItemID = '4306098'
			GROUP BY
				m.workItemID  
			) w
		LEFT JOIN obp_workitem_execinfo f ON w.workitemid = f.workitem_id 
		where w.workItemID = '4306098';
	select total;
	set number = floor(total/size);
	if total%size!=0 then 
	set number = number+1;
	select number;
	end if;
	while start1 < number do
	begin
		declare flag INT DEFAULT 0;
		declare sqlExce INT DEFAULT 0;
		declare _processInstID decimal(20,0);
		declare _processInstName varchar(256);
		declare _processDefName varchar(256);
		declare _activityInstID decimal(20,0);
		declare _activityInstName varchar(256);
		declare _activityDefID varchar(64);	
		declare _workItemID decimal(20,0);
		declare _workItemName varchar(256);
		declare _orgname varchar(64);
		declare _orgid  decimal(10,0);
		declare _orgcode varchar(32);
		declare _empname  varchar(50);
		declare _empid varchar(256);
		declare _empcode varchar(30); 
		declare _currentState decimal(2,0);
		declare _createTime datetime;
		declare _endTime datetime;
		declare _result_flag varchar(30);
		declare _result_name varchar(50);
		declare _work_result  varchar(512);
		declare _is_supplier varchar(2);
		declare _parentProcessInstID decimal(20,0);
		#取出的要转移的字段
		declare youbiao1 cursor for SELECT
			w.`processInstID`,
			w.`processInstName`,
			w.`processDefName`,
			w.`activityInstID`,
			w.`activityInstName`,
			w.`activityDefID`,
			w.`workItemID`,
			w.`workItemName`,
			w.`ORGNAME`,
			w.`ORGID`,
			w.`ORGCODE`,
			w.`EMPNAME`,
			w.`empid`,
			w.`EMPCODE`,
			w.`currentState`,
			w.`createTime`,
			w.`endTime`,
			f.`RESULT_FLAG`,
			f.`RESULT_NAME`,
			f.`WORK_RESULT`,
			w.`is_supplier`

		FROM
			(
			SELECT
				m.`processInstID`,
				m.`processInstName`,
				m.`processDefName`,
				m.`activityInstID`,
				m.`activityInstName`,
				m.`activityDefID`,
				m.`workItemID`,
				m.`workItemName`,
				m.participant AS `empid1`,
				IFNULL( d.EMPID, m.participant ) AS `empid`,
				d.empid as `empid2`,
					d.EMPCODE,
					d.EMPNAME,
					d.ORGID,
					d.ORGNAME,
					d.ORGCODE,
						m.`currentState`,
					m.`createTime`,
					m.endTime,
			CASE
			
			WHEN d.empid IS NULL THEN
			1 ELSE 0 
			END AS is_supplier 		
			FROM
				wfworkitem m
				LEFT JOIN (
				SELECT
					a.EMPID ,
					a.EMPCODE,
					a.EMPNAME,
					c.ORGID,
					c.ORGNAME,
					c.ORGCODE 
				FROM
					org_employee a,
					org_emporg b,
					org_organization c 
				WHERE
					a.empid = b.EMPID 
					AND b.orgid = c.ORGID 
				) d ON m.participant = d.EMPID 
                where m.workItemID = '4306098'
			GROUP BY
				m.workItemID  
			) w
		LEFT JOIN obp_workitem_execinfo f ON w.workitemid = f.workitem_id  
			where w.workItemID = '4306098'; 
		
		#定义退出loop循环条件
		 declare continue handler for not found set flag = 1; 
		 #sql异常条件
		 declare continue handler for sqlexception 
			begin get diagnostics condition 1  msg = message_text;set sqlExce = -10;
			end;
		 open youbiao1;
		 ci: loop
			 start transaction;
			 fetch youbiao1 into 
			 _processInstID, 
			 _processInstName,
			 _processDefName, 
			 _activityInstID, 
			 _activityInstName, 
			 _activityDefID, 	
			 _workItemID, 
			 _workItemName, 
			 _orgname, 
			 _orgid, 
			 _orgcode,
			 _empname,  
			 _empid, 
			 _empcode,
			 _currentState, 
			 _createTime, 
			 _endTime, 
			 _result_flag, 
			 _result_name, 
			_work_result,  
			 _is_supplier; 
			 if flag =1 then leave ci;
			 end if;
			 select parentProcID into _parentProcessInstID from wfprocessinst where processInstID 			= _processInstID;
			 set flag = 0;

			set v_desc = CONCAT('_empid: ', _empid);
			 insert into wf_log_liangbing values(0, _empid, _orgname);
			 commit;
			 insert into wf_log_liangbing values(1, _workItemName, _orgid);
			 commit;
			 insert into wf_log_liangbing values(2, _workItemName, v_desc);
			 commit;
			 insert into wf_log_liangbing values(3, _workItemName, _empid);
			 commit;
			 insert into wf_log_liangbing values(4, _workItemName, _empcode);
			 commit;
			 insert into wf_log_liangbing values(5, _workItemName, _empname);
			 commit;
			 insert into wf_log_liangbing values(6, _workItemName, _currentState);
			 commit;

			 #循环落入目的表
			 INSERT into obp_workitem_detail_info (
			 id,
			 process_inst_id, 
			 process_inst_name,
			 process_def_name, 
			 activity_inst_id, 
			 activity_inst_name, 
			 activity_def_id, 	
			 workitem_id, 
			 workItem_name, 
			 org_id, 
			 org_code,
			 org_name,  
			 emp_id, 
			 emp_code,
			 emp_name, 
			 current_state, 
			 parent_process_inst_id,
			 result_flag, 
			 result_name, 
			 work_result,
			 create_time, 
			 update_time,
			 if_valid, 
			 is_supplier,
			 col5
			 ) values(
			 replace(uuid(),'-',''),
			 _processInstID, 
			 _processInstName,
			 _processDefName, 
			 _activityInstID, 
			 _activityInstName, 
			 _activityDefID, 	
			 _workItemID, 
			 _workItemName, 
			 _orgid, 
			 _orgcode,
			 _orgname,  
			 _empid, 
			 _empcode,
			 _empname, 
			 _currentState,
			 _parentProcessInstID, 
			 _result_flag, 
			 _result_name, 
			 _work_result,
			 _createTime, 
			 _endTime, 
			'1', 
			 _is_supplier,
			 '20200410流程迁移从wfworkitem转移数据'
			 );
			 #如果落数据时遇到异常落日志表 
			 if sqlExce =-10 then
			 ROLLBACK;
			 insert into lcqy_wfworkitem_remove_log values(	_workItemID, 
				 _workItemName, msg);
			set sqlExce =0; 
			 end if;
			 commit;
			end loop;

		close youbiao1;
		end;
			#每完成一次循环做一个标记
		##insert into a values(start1,CONCAT(pageIndex,'插入成功'));
		set start1 = start1+1;
		set pageIndex =pageIndex+size;
		select pageIndex;	 
	end while;
	select number;
	END;

