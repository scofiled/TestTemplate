create view obp_org_children as
  select `g`.`ORGID`   AS `g_orgid`,
         `g`.`ORGCODE` AS `g_orgcode`,
         `f`.`ORGID`   AS `f_orgid`,
         `f`.`ORGCODE` AS `f_orgcode`,
         `o`.`ORGID`   AS `orgid`,
         `o`.`ORGCODE` AS `orgcode`
  from ((`tower`.`org_organization` `g` left join `tower`.`org_organization` `f` on (((`f`.`ORGDEGREE` = '0') and
                                                                                      (`f`.`PARENTORGID` =
                                                                                       `g`.`ORGID`)))) left join `tower`.`org_organization` `o` on ((
    (`o`.`ORGDEGREE` = '0') and (`o`.`PARENTORGID` = `f`.`ORGID`))))
  where (`g`.`ORGDEGREE` <> 0);

