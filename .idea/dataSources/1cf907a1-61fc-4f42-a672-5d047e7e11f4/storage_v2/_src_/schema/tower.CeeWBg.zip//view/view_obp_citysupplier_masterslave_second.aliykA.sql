create view view_obp_citysupplier_masterslave_second as
  select `c`.`supplier_code` AS `master_supplier_code`,
         `c`.`org_name`      AS `master_supplier_name`,
         `a`.`prod_bctg`     AS `protype_code`,
         `e`.`code`          AS `city_code`,
         `d`.`code`          AS `province_code`,
         `b`.`supplier_code` AS `slave_supplier_code`,
         `b`.`org_name`      AS `slave_supplier_name`,
         `b`.`LEVEL`         AS `type`
  from ((((`tower`.`obp_sup_second_user_permission` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_supplier_base_info` `c`) join `tower`.`obp_province` `d`) join `tower`.`obp_city` `e`)
  where ((`a`.`sub_supplier_id` = `b`.`id`) and (`b`.`p_supplier_id` = `c`.`id`) and (`a`.`status` = '00A') and
         (`e`.`p_code` = `d`.`code`) and (`a`.`province_code` = `d`.`code`));

