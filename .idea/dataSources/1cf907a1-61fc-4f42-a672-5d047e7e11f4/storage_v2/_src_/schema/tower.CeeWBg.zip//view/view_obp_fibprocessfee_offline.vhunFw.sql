create view view_obp_fibprocessfee_offline as
  select `a`.`supplier_code` AS `supplier_code`,
         `c`.`pms_type`      AS `product_type`,
         `b`.`product_spec`  AS `product_spec`,
         `b`.`protype_code`  AS `protype_code`,
         `b`.`scheme_id`     AS `scheme_id`,
         `b`.`process_fee`   AS `process_fee`
  from ((`tower`.`obp_fibprocessfee_use` `b`
      join `tower`.`obp_supplier_base_info` `a`) join `tower`.`obp_oth_fib_type_rel` `c`)
  where ((`b`.`STATUS` = '1') and (`a`.`id` = `b`.`supplier_id`) and (`b`.`product_type` = `c`.`quote_type`));

