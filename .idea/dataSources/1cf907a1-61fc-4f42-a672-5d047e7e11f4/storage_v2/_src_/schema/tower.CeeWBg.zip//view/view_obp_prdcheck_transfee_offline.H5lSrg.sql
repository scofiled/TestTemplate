create view view_obp_prdcheck_transfee_offline as
  select `a`.`province_code`  AS `province_code`,
         `a`.`prodbcatg_id`   AS `protype_code`,
         `b`.`supplier_code`  AS `provider_code`,
         `a`.`prodsubcatg_id` AS `prd_type_code`,
         `a`.`freight`        AS `freight_fee`
  from (((`tower`.`obp_oth_quote_prov_freight` `a`
      join `tower`.`obp_supplier_base_info` `b`) join `tower`.`obp_province` `c`) join `tower`.`obp_oth_quote_rule` `d`)
  where ((`a`.`province_code` = `c`.`code`) and (`a`.`supplier_id` = `b`.`id`) and (`a`.`quote_id` = `d`.`quote_id`) and
         (`d`.`status` = 2) and (`a`.`status` = '1') and (`a`.`prodbcatg_id` = 56));

