create procedure p_update_construct_product()
  BEGIN
	#Routine body goes here...
INSERT INTO view_obp_das_product (
	NAME,
	goods_no,
	supplier_code,
	standard_price,
	content,
	unit_name,
	brand_name,
	spec_array,
	material_code,
	tax_price,
	tax_rate,
	Service_star,
	Service_mark,
	Quality_star,
	Quality_mark,
	ContractCode,
	protype_code,
	Medium_code,
	Small_code
) SELECT
		d. NAME AS NAME,
		'' AS goods_no,
		c.supplier_code AS supplier_code,
		NULL AS standard_price,
		concat(
			ifnull(
				(
					SELECT
						b.content
					FROM
						obp_comp_desc b
					WHERE
						(
							a.product_specification_id = b.comp_id
						)
				),
				''
			),
			a.product_describe
		) AS content,
		(
			SELECT
				en.DICTNAME
			FROM
				eos_dict_entry en
			WHERE
				(
					(
						en.DICTTYPEID = 'OBP_MEASURE_UNIT'
					)
					AND (en.DICTID = a.metering_unit)
				)
		) AS unit_name,
		b.generic_brand AS brand_name,
		'' AS spec_array,
		a.material_code AS material_code,
		'' AS tax_price,
		(
			SELECT
				t.col2
			FROM
				obp_tax t
			WHERE
				(
					t.tax_rate = cast(
						b.added_value_tax_rate AS signed
					)
				)
		) AS tax_rate,
		-1 AS Service_star,
		-1  AS Service_mark,
		-1  AS Quality_star,
		-1  AS Quality_mark,
		-1  AS ContractCode,
		(
			SELECT
				l. CODE
			FROM
				obp_prd_type l
			WHERE
				(l.id = b.product_big_type)
		) AS protype_code,
		(
			SELECT
				l. CODE
			FROM
				(
					obp_prd_sub_type l
					JOIN obp_prd_min_type m
				)
			WHERE
				(
					(m.parent_code = l.id)
					AND (
						m.id = a.product_specification_id
					)
				)
		) AS Medium_code,
		(
			SELECT
				m. CODE
			FROM
				obp_prd_min_type m
			WHERE
				(
					m.id = a.product_specification_id
				)
		) AS Small_code
	FROM
		(
			(
				(
					obp_prd_min_info a
					JOIN obp_prd_base_info b
				)
				JOIN obp_supplier_base_info c
			)
			JOIN obp_prd_min_type d
		)
	WHERE
		(
			(
				a.product_base_info_code = b.product_base_info_code
			)
			AND (b.product_big_type LIKE '8%')
			AND (b.supplier_id = c.id)
			AND (
				a.product_specification_id = d.id
			)
			AND EXISTS (
				SELECT
					1
				FROM
					obp_supplier_access_agreement k
				WHERE
					k.state = '1'
				AND b.supplier_id = k.supplier_id
				AND b.product_big_type = k.prod_bctg
			)
and not EXISTS (
 select 1 from view_obp_das_product q where a.material_code=q.material_code
	)
		);
INSERT INTO view_obp_product_images(`material_code`, `path`, `sort`, `isPrimary`)
SELECT

        a.material_code AS material_code,
        concat(
        'http://192.168.2.247:10000/files/imagescommon/',
        a.product_specification_id,'.jpg'
    ) AS `path`,
    1 AS `sort`,
    '' AS `isPrimary`
    FROM
        (
            (
                (
                    obp_prd_min_info a
                    JOIN obp_prd_base_info b
                )
                JOIN obp_supplier_base_info c
            )
            JOIN obp_prd_min_type d
        )
    WHERE
        (
            (
                a.product_base_info_code = b.product_base_info_code
            )
            AND (b.product_big_type LIKE '8%')
            AND (b.supplier_id = c.id)
            AND (
                a.product_specification_id = d.id
            )
            AND EXISTS (
                SELECT
                    1
                FROM
                    obp_supplier_access_agreement k
                WHERE
                    k.state = '1'
                AND b.supplier_id = k.supplier_id
                AND b.product_big_type = k.prod_bctg
            )and not EXISTS (

select 1 from view_obp_product_images f where a.material_code=f.material_code
)
        );

END;

