create view v_acct_role as select `e`.`EMPCODE` AS `USER_ID`, `r`.`ROLE_CODE` AS `ROLE_ID`
                           from ((`tower`.`cap_partyauth` `p`
                               join `tower`.`cap_role` `r`) join `tower`.`org_employee` `e`)
                           where ((`p`.`ROLE_TYPE` = 'role') and (`p`.`PARTY_TYPE` = 'emp') and
                                  (`p`.`ROLE_ID` = `r`.`ROLE_ID`) and (`p`.`PARTY_ID` = `e`.`EMPID`))
                           union all select `u`.`USER_ID` AS `USER_ID`, `r`.`ROLE_CODE` AS `ROLE_ID`
                                     from ((`tower`.`cap_partyauth` `p`
                                         join `tower`.`cap_role` `r`) join `tower`.`cap_user` `u`)
                                     where ((`p`.`ROLE_TYPE` = 'role') and (`p`.`PARTY_TYPE` = 'user') and
                                            (`p`.`ROLE_ID` = `r`.`ROLE_ID`) and (`p`.`PARTY_ID` = `u`.`USER_ID`) and
                                            (not(exists(select 1
                                                        from `tower`.`obp_cap_user_extend` `e`
                                                        where (`u`.`OPERATOR_ID` = `e`.`operator_id`)))));

