create view view_obp_das_discount_offline as select `b`.`supplier_code`          AS `provider_code`,
                                                    `a`.`prodbcatg_id`           AS `prd_type_code`,
                                                    `a`.`province_code`          AS `province_code`,
                                                    (1 - (`a`.`discount` / 100)) AS `discount`,
                                                    `a`.`prodbcatg_id`           AS `prd_min_code`
                                             from (`tower`.`obp_das_supplier_quote` `a`
                                                 join `tower`.`obp_supplier_base_info` `b`)
                                             where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = 1) and
                                                    (`a`.`prodbcatg_id` in (46, 47, 48)))
                                             union all select `b`.`supplier_code`                   AS `provider_code`,
                                                              `a`.`prodbcatg_id`                    AS `prd_type_code`,
                                                              `a`.`province_code`                   AS `province_code`,
                                                              (1 - (`a`.`discount` / 100))          AS `discount`,
                                                              `get_quote_model_product`('discount') AS `prd_min_code`
                                                       from (`tower`.`obp_das_supplier_quote` `a`
                                                           join `tower`.`obp_supplier_base_info` `b`)
                                                       where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = 1) and
                                                              (`a`.`prodbcatg_id` = 49))
                                             union all select `b`.`supplier_code`                 AS `provider_code`,
                                                              `a`.`prodbcatg_id`                  AS `prd_type_code`,
                                                              `a`.`province_code`                 AS `province_code`,
                                                              (1 - (`a`.`survey` / 100))          AS `discount`,
                                                              `get_quote_model_product`('survey') AS `prd_min_code`
                                                       from (`tower`.`obp_das_supplier_quote` `a`
                                                           join `tower`.`obp_supplier_base_info` `b`)
                                                       where ((`a`.`supplier_id` = `b`.`id`) and (`a`.`status` = 1) and
                                                              (`a`.`prodbcatg_id` = 49));

