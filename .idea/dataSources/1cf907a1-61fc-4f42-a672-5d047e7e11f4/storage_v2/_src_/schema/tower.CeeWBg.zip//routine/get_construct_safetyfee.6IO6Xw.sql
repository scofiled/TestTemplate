create function get_construct_safetyfee(v_prov_code varchar(64), v_taxrate decimal(16, 2), v_safetyfee decimal(16, 2))
  returns decimal(16, 2)
  BEGIN

DECLARE safetyfee DECIMAL (16, 2);


set safetyfee = v_safetyfee ;


RETURN safetyfee;


END;

