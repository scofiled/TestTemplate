create view view_obp_citysupplier_masterslave as
  select `a`.`master_supplier_code` AS `master_supplier_code`,
         `a`.`master_supplier_name` AS `master_supplier_name`,
         `a`.`protype_code`         AS `protype_code`,
         `a`.`province_code`        AS `province_code`,
         `qq`.`city_code`           AS `city_code`,
         `a`.`slave_supplier_code`  AS `slave_supplier_code`,
         `a`.`slave_supplier_name`  AS `slave_supplier_name`,
         `a`.`type`                 AS `type`
  from `tower`.`view_obp_citysupplier_masterslave_city` `a`
         join `tower`.`view_obp_city_all` `qq`
  where (`a`.`province_code` = `qq`.`province_code`);

