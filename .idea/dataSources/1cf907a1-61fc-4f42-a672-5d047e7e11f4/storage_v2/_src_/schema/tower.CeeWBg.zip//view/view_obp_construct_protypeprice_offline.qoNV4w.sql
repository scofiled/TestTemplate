create view view_obp_construct_protypeprice_offline as
  select `a`.`province_code` AS `province_code`,
         `a`.`product_btype` AS `protype_code`,
         `b`.`supplier_code` AS `supplier_code`,
         `a`.`product_score` AS `Price_mark`,
         `a`.`product_level` AS `Price_star`,
         `c`.`service_score` AS `Service_mark`,
         `c`.`service_star`  AS `Service_star`,
         `c`.`qua_score`     AS `Quality_mark`,
         `c`.`qua_star`      AS `Quality_star`,
         `a`.`city_code`     AS `city_code`
  from ((`tower`.`obp_product_score_result` `a`
      join `tower`.`obp_supplier_base_info` `b` on ((`a`.`supplier_id` =
                                                     `b`.`id`))) left join `tower`.`obp_cer_score_inst` `c` on ((
    (`b`.`id` = `c`.`supplier_id`) and (`a`.`product_btype` = `c`.`prod_bcatg`) and
    (`a`.`province_code` = `c`.`province_code`))))
  where (`a`.`product_btype` like '8%');

