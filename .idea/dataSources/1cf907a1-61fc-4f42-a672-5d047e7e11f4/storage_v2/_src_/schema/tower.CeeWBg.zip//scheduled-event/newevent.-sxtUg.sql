create definer = obp@`%` event NewEvent
  on schedule
    every '1' DAY
      starts '2018-11-15 23:59:59'
  enable
do
  UPDATE obp_sequence SET value=0 WHERE name='trans_no';

