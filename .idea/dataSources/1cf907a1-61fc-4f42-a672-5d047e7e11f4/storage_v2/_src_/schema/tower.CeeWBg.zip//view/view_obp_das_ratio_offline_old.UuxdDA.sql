create view view_obp_das_ratio_offline_old as
  select `view_obp_das_ratio_offline`.`prd_type_code` AS `prd_type_code`,
         `view_obp_das_ratio_offline`.`province_code` AS `province_code`,
         `view_obp_das_ratio_offline`.`city_code`     AS `city_code`,
         `view_obp_das_ratio_offline`.`discount`      AS `discount`
  from `tower`.`view_obp_das_ratio_offline`;

