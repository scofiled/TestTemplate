create procedure wfTransfer_liangbing(IN startDate varchar(32), IN endDate varchar(32))
  BEGIN
	DECLARE total INT(32) DEFAULT 0;
	DECLARE number INT(32) DEFAULT 0;
	DECLARE size INT(32) DEFAULT 10000;
	DECLARE start1 INT(32) DEFAULT 0;
	DECLARE pageIndex INT(32) DEFAULT 0;
	DECLARE msg TEXT;
	SELECT COUNT(*) INTO total 
	FROM
		wfworkitem w
		LEFT JOIN (
	SELECT
		a.EMPID,
		a.EMPCODE,
		a.EMPNAME,
		c.ORGID,
		c.ORGNAME,
		c.ORGCODE 
	FROM
		org_employee a,
		org_emporg b,
		org_organization c 
	WHERE
		a.empid = b.EMPID 
		AND b.orgid = c.ORGID 
		) d ON w.participant = d.EMPID
		LEFT JOIN obp_workitem_execinfo  f ON w.workitemid = f.workitem_id 
		WHERE w.createTime >= startDate AND w.createTime<endDate;
	SELECT total;
	SET number = FLOOR(total/size);
	IF total%size!=0 THEN 
	SET number = number+1;
	SELECT number;
	END IF;
	WHILE start1 < number DO
	BEGIN
		DECLARE flag INT DEFAULT 0;
		DECLARE sqlExce INT DEFAULT 0;
		DECLARE _processInstID DECIMAL(20,0);
		DECLARE _processInstName VARCHAR(256);
		DECLARE _processDefName VARCHAR(256);
		DECLARE _activityInstID DECIMAL(20,0);
		DECLARE _activityInstName VARCHAR(256);
		DECLARE _activityDefID VARCHAR(64);	
		DECLARE _workItemID DECIMAL(20,0);
		DECLARE _workItemName VARCHAR(256);
		DECLARE _orgname VARCHAR(64);
		DECLARE _orgid  DECIMAL(10,0);
		DECLARE _orgcode VARCHAR(32);
		DECLARE _empname  VARCHAR(50);
		DECLARE _empid DECIMAL(10,0);
		DECLARE _empcode VARCHAR(30); 
		DECLARE _currentState DECIMAL(2,0);
		DECLARE _createTime DATETIME;
		DECLARE _endTime DATETIME;
		DECLARE _result_flag VARCHAR(30);
		DECLARE _result_name VARCHAR(50);
		DECLARE _work_result  VARCHAR(512);
		DECLARE _is_supplier VARCHAR(2);
		DECLARE _parentProcessInstID DECIMAL(20,0);
		#取出的要转移的字段
		DECLARE youbiao1 CURSOR FOR SELECT
			w.`processInstID`,
			w.`processInstName`,
			w.`processDefName`,
			w.`activityInstID`,
			w.`activityInstName`,
			w.`activityDefID`,
			w.`workItemID`,
			w.`workItemName`,
			d.ORGNAME,
			d.ORGID,
			d.ORGCODE,
			d.EMPNAME,
			IFNULL(d.empid,w.participant) AS empid,
			d.EMPCODE,
			w.`currentState`,
			w.`createTime`,
			w.endTime,
			f.RESULT_FLAG,
			f.RESULT_NAME,
			f.WORK_RESULT,
			CASE  WHEN d.empid IS NULL  THEN 1 ELSE 0 END AS is_supplier
	FROM
		wfworkitem w
		LEFT JOIN (
	SELECT
		a.EMPID,
		a.EMPCODE,
		a.EMPNAME,
		c.ORGID,
		c.ORGNAME,
		c.ORGCODE 
	FROM
		org_employee a,
		org_emporg b,
		org_organization c 
	WHERE
		a.empid = b.EMPID 
		AND b.orgid = c.ORGID 
		) d ON w.participant = d.EMPID
		LEFT JOIN obp_workitem_execinfo  f ON w.workitemid = f.workitem_id 
		WHERE w.createTime >= startDate AND w.createTime<endDate LIMIT pageIndex,size; 
		
		#定义退出loop循环条件
		 DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1; 
		 #sql异常条件
		 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION 
			BEGIN get diagnostics CONDITION 1  msg = message_text;SET sqlExce = -10;
			END;
		 OPEN youbiao1;
		 ci: LOOP
			 START TRANSACTION;
			 FETCH youbiao1 INTO 
			 _processInstID, 
			 _processInstName,
			 _processDefName, 
			 _activityInstID, 
			 _activityInstName, 
			 _activityDefID, 	
			 _workItemID, 
			 _workItemName, 
			 _orgname, 
			 _orgid, 
			 _orgcode,
			 _empname,  
			 _empid, 
			 _empcode,
			 _currentState, 
			 _createTime, 
			 _endTime, 
			 _result_flag, 
			 _result_name, 
			_work_result,  
			 _is_supplier; 
			 IF flag =1 THEN LEAVE ci;
			 END IF;
			 SELECT parentProcID INTO _parentProcessInstID FROM wfprocessinst WHERE processInstID 			= _processInstID;
			 SET flag = 0;
			 #循环落入目的表
			 INSERT INTO obp_workitem_detail_info (
			 id,
			 process_inst_id, 
			 process_inst_name,
			 process_def_name, 
			 activity_inst_id, 
			 activity_inst_name, 
			 activity_def_id, 	
			 workitem_id, 
			 workItem_name, 
			 org_id, 
			 org_code,
			 org_name,  
			 emp_id, 
			 emp_code,
			 emp_name, 
			 current_state, 
			 parent_process_inst_id,
			 result_flag, 
			 result_name, 
			 work_result,
			 create_time, 
			 update_time,
			 if_valid, 
			 is_supplier
			 ) VALUES(
			 REPLACE(UUID(),'-',''),
			 _processInstID, 
			 _processInstName,
			 _processDefName, 
			 _activityInstID, 
			 _activityInstName, 
			 _activityDefID, 	
			 _workItemID, 
			 _workItemName, 
			 _orgid, 
			 _orgcode,
			 _orgname,  
			 _empid, 
			 _empcode,
			 _empname, 
			 _currentState,
			 _parentProcessInstID, 
			 _result_flag, 
			 _result_name, 
			 _work_result,
			 _createTime, 
			 _endTime, 
			'1', 
			 _is_supplier
			 );
			 #如果落数据时遇到异常落日志表 
			 IF sqlExce =-10 THEN
			 ROLLBACK;
			 INSERT INTO lcqy_wfworkitem_remove_log VALUES(	_workItemID, 
				 _workItemName, msg);
			SET sqlExce =0; 
			 END IF;
			 COMMIT;
			END LOOP;

		CLOSE youbiao1;
		END;
			#每完成一次循环做一个标记
		##insert into a values(start1,CONCAT(pageIndex,'插入成功'));
		SET start1 = start1+1;
		SET pageIndex =pageIndex+size;
		SELECT pageIndex;	 
	END WHILE;
	SELECT number;
END;

