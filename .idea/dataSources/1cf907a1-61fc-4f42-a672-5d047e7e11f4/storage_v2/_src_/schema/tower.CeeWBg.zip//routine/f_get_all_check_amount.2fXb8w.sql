create function f_get_all_check_amount(v_orgCode varchar(64), v_prdcodes varchar(64), v_supplier_code varchar(64),
                                       v_ifcdb   varchar(32))
  returns decimal(20, 2)
  BEGIN
DECLARE payamount2 DECIMAL (20,2);
DECLARE orgCode varchar(64);
DECLARE prdcodes varchar(64);
DECLARE supplier_code varchar(64);
DECLARE ifcdb varchar(64);

SET payamount2=0.0;
SET orgCode=v_orgCode;
SET ifcdb=v_ifcdb;
SET prdcodes=v_prdcodes;
SET supplier_code=v_supplier_code;

IF ifcdb = '0' THEN
select sum(PayAmount) into payamount2 from (
SELECT 
 DISTINCT d.Receivingid,d.ProjectStatus,d.PayAmount
FROM
	obp_settle_check c,
	obp_settle_check_detail d
where c.CheckCode=d.checkCode
and c.OrgCode=orgCode and c.prdcodes=prdcodes and c.SupplyCode= supplier_code and c.ifcdb='0')m;
ELSE 
select sum(PayAmount) into payamount2 from (
SELECT 
 DISTINCT d.Receivingid,d.ProjectStatus,d.PayAmount
FROM
	obp_settle_check c,
	obp_settle_check_detail d
where c.CheckCode=d.checkCode
and c.OrgCode=orgCode and c.prdcodes=prdcodes and c.SupplyCode= supplier_code and c.ifcdb<>'0')m;
END IF;
return payamount2;
END;

