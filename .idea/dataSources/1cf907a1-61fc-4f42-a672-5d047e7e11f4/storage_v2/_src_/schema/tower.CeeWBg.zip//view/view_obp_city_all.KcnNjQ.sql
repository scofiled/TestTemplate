create view view_obp_city_all as select `c`.`province_code` AS `province_code`, `c`.`orgcode` AS `city_code`
                                 from `tower`.`obp_city_org` `c`
                                 union select `q`.`p_code` AS `province_code`, `q`.`code` AS `city_code`
                                       from `tower`.`obp_city` `q`;

