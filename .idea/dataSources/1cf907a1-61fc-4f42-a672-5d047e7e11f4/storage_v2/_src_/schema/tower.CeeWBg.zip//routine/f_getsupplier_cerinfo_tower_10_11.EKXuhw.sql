create function f_getsupplier_cerinfo_tower_10_11(v_supplier_id    varchar(64), v_product_big_type varchar(5),
                                                  v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN
   
  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
	set cer_info_html='';
	SET cer_info_temp = '';

  SELECT CONCAT('<p>','综合信息','</p>','<br>'
								,'销售业绩总额(万元): ',a.sales_performance_total,'<br>'
								,'选择供应区域: ',a.supply_provinces_name,'<br>'
								,'广播通信铁塔及桅杆产品生产许可证证书编号:',a.communication_licence_num,'证书截止日期：',DATE_FORMAT(a.communication_licence_deadline,'%Y-%m-%d'),'<br>'
								,'钢结构三级承包资质证书编号:',a.contractor_qualification_num,'证书截止日期：',DATE_FORMAT(a.contractor_qualification_deadline,'%Y-%m-%d'),'<br>'
								,'安全生产许可证证书编号:',a.production_licence_num,'证书截止日期：',DATE_FORMAT(a.licence_deadline,'%Y-%m-%d'),'<br>'
                ) 
  into cer_info_temp

 FROM obp_tower_product_base_info  a  WHERE
 a.product_big_type =v_product_big_type
AND a.product_base_info_code = v_base_info_code ;


  set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
	SET cer_info_temp = '';

  RETURN cer_info_html;
END;

