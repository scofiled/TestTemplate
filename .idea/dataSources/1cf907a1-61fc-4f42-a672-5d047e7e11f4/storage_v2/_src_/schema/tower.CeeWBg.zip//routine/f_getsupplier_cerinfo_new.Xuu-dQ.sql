create function f_getsupplier_cerinfo_new(v_supplier_id    varchar(64), v_product_big_type varchar(32),
                                          v_base_info_code varchar(32))
  returns varchar(10240)
  BEGIN
  DECLARE cer_info_html VARCHAR (10240);

  DECLARE cer_info_temp VARCHAR (10240);
  set cer_info_html='';
  SET cer_info_temp = '';

  SELECT CONCAT('<p>','综合信息','</p>','<br>'
                ,'选择供应区域: ',b.supply_area_name
                ,REPLACE(GROUP_CONCAT(' <br>',c.certificate_name,'证书编号:',c.certificate_code,'证书截止日期：',DATE_FORMAT(c.certificate_validity,'%Y-%m-%d')),',','')
                ,'<br>') 
  into cer_info_temp
FROM obp_supplier_prod_base_info b 
LEFT JOIN obp_supplier_prod_certificate c 
ON c.supplier_id=c.supplier_id AND b.scheme_id=c.scheme_id AND b.base_code=c.base_code
WHERE b.scheme_id=v_product_big_type
AND b.base_code=v_base_info_code
GROUP BY b.supplier_id,b.scheme_id,b.base_code;

  set cer_info_html=CONCAT(cer_info_html,cer_info_temp);
  SET cer_info_temp = '';

  RETURN cer_info_html;
END;

